import express from 'express';
import http from 'http';
import path from 'path';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import { apiRouter } from './server/routes.js';
import { realtimeServer } from './server/ws.js';
import { initMongoDB } from './server/db.js';

const PORT = 3000;

async function startServer() {
  const app = express();
  const server = http.createServer(app);

  // Cross-origin and JSON body parser
  app.use(cors());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Initialize DB (MongoDB Atlas if URI provided, else persistent local JSON store)
  await initMongoDB();

  // Attach Realtime WebSocket server on /ws
  realtimeServer.init(server);

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'BLUEJO API',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    });
  });

  // Mount BLUEJO REST APIs
  app.use('/api', apiRouter);

  // 404 handler for unmatched /api/* routes so they return JSON, never HTML
  app.all('/api/*', (req, res) => {
    res.status(404).json({ success: false, error: `API endpoint ${req.method} ${req.path} not found` });
  });

  // Error handling middleware for /api routes to prevent HTML 500 error pages
  app.use('/api', (err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('API Error:', err);
    res.status(err.status || 500).json({
      success: false,
      error: err.message || 'Internal Server Error'
    });
  });

  // Serve public static assets (logos, favicons, static images)
  app.use(express.static(path.join(process.cwd(), 'public')));

  // Vite middleware for development vs static build in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[BLUEJO] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[BLUEJO] Fatal server startup error:', err);
});
