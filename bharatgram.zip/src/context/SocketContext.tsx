import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { useAuth } from './AuthContext';
import { Message, NotificationItem } from '../types';

interface SocketContextType {
  onlineUsers: Set<string>;
  lastMessage: Message | null;
  lastNotification: NotificationItem | null;
  isSocketConnected: boolean;
  sendMessageToSocket: (payload: any) => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const { user, token, refreshMe } = useAuth();
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [lastMessage, setLastMessage] = useState<Message | null>(null);
  const [lastNotification, setLastNotification] = useState<NotificationItem | null>(null);
  const [isSocketConnected, setIsSocketConnected] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!token || !user) {
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
      setIsSocketConnected(false);
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws?token=${token}`;

    let socket: WebSocket;
    let reconnectTimeout: NodeJS.Timeout;

    const connect = () => {
      socket = new WebSocket(wsUrl);
      socketRef.current = socket;

      socket.onopen = () => {
        setIsSocketConnected(true);
      };

      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'presence_change') {
            setOnlineUsers((prev) => {
              const updated = new Set(prev);
              if (data.isOnline) {
                updated.add(data.userId);
              } else {
                updated.delete(data.userId);
              }
              return updated;
            });
          } else if (data.type === 'new_message') {
            setLastMessage(data.message);
            refreshMe();
          } else if (data.type === 'new_notification') {
            setLastNotification(data.notification);
            refreshMe();
          }
        } catch (err) {
          console.error('[WS] Failed to parse event:', err);
        }
      };

      socket.onclose = () => {
        setIsSocketConnected(false);
        // Auto-reconnect after 3 seconds
        reconnectTimeout = setTimeout(connect, 3000);
      };

      socket.onerror = (err) => {
        console.warn('[WS] Socket encountered error:', err);
        socket.close();
      };
    };

    connect();

    return () => {
      clearTimeout(reconnectTimeout);
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [token, user, refreshMe]);

  const sendMessageToSocket = (payload: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(payload));
    }
  };

  return (
    <SocketContext.Provider
      value={{
        onlineUsers,
        lastMessage,
        lastNotification,
        isSocketConnected,
        sendMessageToSocket
      }}
    >
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
}
