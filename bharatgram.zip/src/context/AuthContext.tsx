import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User } from '../types';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithPhoneNumber,
  ConfirmationResult,
  RecaptchaVerifier,
  GoogleAuthProvider,
  signInWithPopup,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { auth, formatFirebaseAuthError, saveUserProfileToFirestore, getUserProfileFromFirestore } from '../lib/firebase';

declare global {
  interface Window {
    recaptchaVerifier?: RecaptchaVerifier | null;
  }
}

export interface SignupPayload {
  name: string;
  username: string;
  email: string;
  password: string;
  confirmPassword?: string;
  dob?: string;
  profilePhoto?: string;
}

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  token: string | null;
  isLoading: boolean;
  unreadNotifications: number;
  unreadMessages: number;

  // Real Firebase Authentication methods
  firebaseSignupWithEmail: (payload: SignupPayload) => Promise<{ success: boolean; error?: string; user?: User; emailNeedsVerification?: boolean }>;
  firebaseLoginWithEmail: (email: string, pass: string) => Promise<{ success: boolean; error?: string; user?: User; emailVerified?: boolean }>;
  firebaseSendPasswordReset: (email: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  firebaseSendEmailVerification: () => Promise<{ success: boolean; error?: string; message?: string }>;
  firebaseSendPhoneOtp: (phoneNumber: string, containerId?: string) => Promise<{ success: boolean; error?: string; confirmationResult?: ConfirmationResult }>;
  firebaseVerifyPhoneOtp: (confirmationResult: ConfirmationResult, otpCode: string, additionalData?: { name?: string; username?: string }) => Promise<{ success: boolean; error?: string; user?: User }>;
  firebaseGoogleSignIn: () => Promise<{ success: boolean; error?: string; user?: User }>;
  checkEmailVerified: () => Promise<{ verified: boolean; user?: User; error?: string }>;

  // Universal/Compatibility methods for BLUEJO
  login: (identifier: string, pass: string) => Promise<{ success: boolean; error?: string; user?: User }>;
  googleLogin: (profile: { email: string; name: string; avatar?: string; googleId?: string }) => Promise<{ success: boolean; error?: string; user?: User }>;
  initiateSignup: (payload: SignupPayload) => Promise<{ success: boolean; error?: string; demoOtp?: string; message?: string }>;
  verifyOtp: (email: string, otp: string) => Promise<{ success: boolean; error?: string; user?: User; message?: string }>;
  resendOtp: (email: string, type?: 'signup' | 'forgot_password') => Promise<{ success: boolean; error?: string; demoOtp?: string; message?: string }>;
  forgotPassword: (email: string) => Promise<{ success: boolean; error?: string; demoOtp?: string; message?: string }>;
  resetPassword: (payload: { email: string; otp: string; newPassword: string; confirmPassword?: string }) => Promise<{ success: boolean; error?: string; message?: string }>;
  quickLogin: (username: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, username: string, email: string, pass: string, dob?: string, profilePhoto?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  logoutAllDevices: () => Promise<{ success: boolean; error?: string; message?: string }>;
  updateUser: (data: Partial<User>) => Promise<{ success: boolean; error?: string; user?: User }>;
  refreshMe: () => Promise<void>;
  decrementUnreadMessages: () => void;
  decrementUnreadNotifications: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('bluejo_token'));
  const [isLoading, setIsLoading] = useState(true);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);

  // Sync Firebase User with BLUEJO backend to obtain JWT & User profile
  const syncFirebaseUserWithBackend = async (
    fbUser: FirebaseUser,
    additional?: { name?: string; username?: string; dob?: string; profilePhoto?: string }
  ): Promise<{ success: boolean; user?: User; token?: string; error?: string }> => {
    try {
      // 1. Save profile information directly to Firestore (/users/{uid})
      await saveUserProfileToFirestore(fbUser, {
        name: additional?.name,
        username: additional?.username,
        dob: additional?.dob,
        profilePhoto: additional?.profilePhoto
      }).catch((firestoreErr) => {
        console.warn('Firestore user profile save note:', firestoreErr);
      });

      const payload = {
        firebaseUid: fbUser.uid,
        email: fbUser.email || '',
        phoneNumber: fbUser.phoneNumber || '',
        name: additional?.name || fbUser.displayName || '',
        username: additional?.username || '',
        profilePhoto: additional?.profilePhoto || fbUser.photoURL || '',
        dob: additional?.dob || '',
        isEmailVerified: fbUser.emailVerified,
        isPhoneVerified: Boolean(fbUser.phoneNumber)
      };

      const res = await fetch('/api/auth/firebase-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to sync Firebase session with BLUEJO.' };
      }

      if (data.token) {
        localStorage.setItem('bluejo_token', data.token);
        setToken(data.token);
        setUser(data.user);
      }

      return { success: true, user: data.user, token: data.token };
    } catch (err: any) {
      console.error('Firebase backend sync error:', err);
      return { success: false, error: err.message || 'Network sync error.' };
    }
  };

  const refreshMe = useCallback(async () => {
    const currentToken = localStorage.getItem('bluejo_token');
    if (!currentToken) {
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${currentToken}`
        }
      });
      const data = await res.json();
      if (data.success && data.user) {
        setUser(data.user);
        setUnreadNotifications(data.unreadNotifications || 0);
        setUnreadMessages(data.unreadMessages || 0);
      } else {
        localStorage.removeItem('bluejo_token');
        setToken(null);
        setUser(null);
      }
    } catch (err) {
      console.error('Failed to verify BLUEJO session:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Monitor Firebase Auth state change
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser && !localStorage.getItem('bluejo_token')) {
        await syncFirebaseUserWithBackend(fbUser);
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    refreshMe();
  }, [refreshMe]);

  // 1. Firebase Email + Password Signup
  const firebaseSignupWithEmail = async (payload: SignupPayload) => {
    try {
      // Create user in Firebase Auth
      const userCred = await createUserWithEmailAndPassword(auth, payload.email, payload.password);
      const fbUser = userCred.user;

      // Update Firebase Profile with Name and Photo
      await updateProfile(fbUser, {
        displayName: payload.name,
        photoURL: payload.profilePhoto || undefined
      });

      // Send real email verification
      await sendEmailVerification(fbUser);

      // Sync with BLUEJO backend
      const syncResult = await syncFirebaseUserWithBackend(fbUser, {
        name: payload.name,
        username: payload.username,
        dob: payload.dob,
        profilePhoto: payload.profilePhoto
      });

      if (!syncResult.success) {
        return { success: false, error: syncResult.error };
      }

      await refreshMe();
      return {
        success: true,
        user: syncResult.user,
        emailNeedsVerification: !fbUser.emailVerified
      };
    } catch (err: any) {
      console.error('Firebase Email Signup error:', err);
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 2. Firebase Email + Password Login
  const firebaseLoginWithEmail = async (email: string, pass: string) => {
    try {
      const userCred = await signInWithEmailAndPassword(auth, email, pass);
      const fbUser = userCred.user;

      // Sync with BLUEJO backend
      const syncResult = await syncFirebaseUserWithBackend(fbUser);
      if (!syncResult.success) {
        return { success: false, error: syncResult.error };
      }

      await refreshMe();
      return {
        success: true,
        user: syncResult.user,
        emailVerified: fbUser.emailVerified
      };
    } catch (err: any) {
      console.error('Firebase Email Login error:', err);
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 3. Firebase Password Reset Email
  const firebaseSendPasswordReset = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email.trim());
      return {
        success: true,
        message: `Password reset email sent to ${email}. Please check your inbox (and spam folder) to reset your password.`
      };
    } catch (err: any) {
      console.error('Firebase Password Reset error:', err);
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 4. Firebase Resend Email Verification
  const firebaseSendEmailVerification = async () => {
    try {
      if (!auth.currentUser) {
        return { success: false, error: 'No active session. Please log in first.' };
      }
      await sendEmailVerification(auth.currentUser);
      return {
        success: true,
        message: 'A fresh verification link has been sent to your email.'
      };
    } catch (err: any) {
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 5. Firebase Phone Authentication - Send SMS OTP
  const firebaseSendPhoneOtp = async (phoneNumber: string, containerId = 'recaptcha-container') => {
    try {
      // Ensure recaptcha container exists in DOM
      let element = document.getElementById(containerId);
      if (!element) {
        element = document.getElementById('recaptcha-container');
      }
      if (!element) {
        element = document.createElement('div');
        element.id = 'recaptcha-container';
        document.body.appendChild(element);
      }

      // Safely clear any previously initialized recaptcha widget
      if (window.recaptchaVerifier) {
        try {
          window.recaptchaVerifier.clear();
        } catch (e) {
          console.warn('reCAPTCHA clear note:', e);
        }
        window.recaptchaVerifier = null;
      }
      element.innerHTML = '';

      // Initialize fresh RecaptchaVerifier and render before sending SMS
      window.recaptchaVerifier = new RecaptchaVerifier(auth, element, {
        size: 'invisible',
        callback: () => {
          // reCAPTCHA solved
        },
        'expired-callback': () => {
          console.warn('reCAPTCHA expired. Resetting verifier.');
        }
      });

      await window.recaptchaVerifier.render();

      // Wrap SMS dispatch in a 25-second timeout to guarantee it never hangs indefinitely
      const smsPromise = signInWithPhoneNumber(auth, phoneNumber, window.recaptchaVerifier);
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(
          () => reject(new Error('SMS request timed out. Please verify Phone provider is enabled in your Firebase Console.')),
          25000
        );
      });

      const confirmationResult = await Promise.race([smsPromise, timeoutPromise]);
      return { success: true, confirmationResult };
    } catch (err: any) {
      console.error('Firebase Phone Auth send OTP error:', err);
      // Clean up verifier on error so next attempt starts clean
      if (window.recaptchaVerifier) {
        try {
          window.recaptchaVerifier.clear();
        } catch (e) {}
        window.recaptchaVerifier = null;
      }
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 6. Firebase Phone Authentication - Verify OTP
  const firebaseVerifyPhoneOtp = async (
    confirmationResult: ConfirmationResult,
    otpCode: string,
    additionalData?: { name?: string; username?: string }
  ) => {
    try {
      const userCred = await confirmationResult.confirm(otpCode);
      const fbUser = userCred.user;

      if (additionalData?.name) {
        await updateProfile(fbUser, { displayName: additionalData.name }).catch(() => {});
      }

      // Sync with BLUEJO backend and save in Firestore
      const syncResult = await syncFirebaseUserWithBackend(fbUser, additionalData);
      if (!syncResult.success) {
        return { success: false, error: syncResult.error };
      }

      await refreshMe();
      return { success: true, user: syncResult.user };
    } catch (err: any) {
      console.error('Firebase Phone Auth verify OTP error:', err);
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 7. Firebase Google Sign-In
  const firebaseGoogleSignIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      const fbUser = result.user;

      const syncResult = await syncFirebaseUserWithBackend(fbUser);
      if (!syncResult.success) {
        return { success: false, error: syncResult.error };
      }

      await refreshMe();
      return { success: true, user: syncResult.user };
    } catch (err: any) {
      console.error('Firebase Google Sign-In error:', err);
      return { success: false, error: formatFirebaseAuthError(err) };
    }
  };

  // 8. Check Email Verification Status
  const checkEmailVerified = async () => {
    try {
      if (!auth.currentUser) {
        return { verified: false, error: 'No active session found. Please sign in.' };
      }
      await auth.currentUser.reload();
      const verified = Boolean(auth.currentUser.emailVerified);
      if (verified) {
        await saveUserProfileToFirestore(auth.currentUser);
        const syncRes = await syncFirebaseUserWithBackend(auth.currentUser);
        await refreshMe();
        return { verified: true, user: syncRes.user };
      }
      return { verified: false };
    } catch (err: any) {
      return { verified: false, error: formatFirebaseAuthError(err) };
    }
  };

  // Compatibility / Universal Login
  const login = async (identifier: string, pass: string) => {
    // If identifier looks like an email, attempt Firebase Email login first
    if (identifier.includes('@')) {
      const fbResult = await firebaseLoginWithEmail(identifier.trim(), pass);
      if (fbResult.success) {
        return fbResult;
      }
    }

    // Fallback to BLUEJO backend credentials login (supports usernames and existing accounts)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password: pass })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Login failed' };
      }

      localStorage.setItem('bluejo_token', data.token);
      setToken(data.token);
      setUser(data.user);
      await refreshMe();
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const googleLogin = async (profile: { email: string; name: string; avatar?: string; googleId?: string }) => {
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Google sign-in failed' };
      }

      localStorage.setItem('bluejo_token', data.token);
      setToken(data.token);
      setUser(data.user);
      await refreshMe();
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during Google sign-in' };
    }
  };

  const initiateSignup = async (payload: SignupPayload) => {
    try {
      // First attempt Firebase Email Signup
      const fbResult = await firebaseSignupWithEmail(payload);
      if (fbResult.success) {
        return {
          success: true,
          message: 'Account created in Firebase! Verification email sent to ' + payload.email
        };
      }

      // If Firebase returns error like email-already-in-use or weak-password, pass it back directly
      if (fbResult.error) {
        return { success: false, error: fbResult.error };
      }

      // Fallback to backend registration initiate if needed
      const res = await fetch('/api/auth/register-initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to initiate signup' };
      }
      return { success: true, demoOtp: data.demoOtp, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const verifyOtp = async (email: string, otp: string) => {
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Verification failed' };
      }

      if (data.token) {
        localStorage.setItem('bluejo_token', data.token);
        setToken(data.token);
        setUser(data.user);
        await refreshMe();
      }
      return { success: true, user: data.user, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const resendOtp = async (email: string, type?: 'signup' | 'forgot_password') => {
    try {
      const res = await fetch('/api/auth/resend-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, type })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to resend code' };
      }
      return { success: true, demoOtp: data.demoOtp, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const forgotPassword = async (email: string) => {
    // Try Firebase password reset email first
    const fbResult = await firebaseSendPasswordReset(email);
    if (fbResult.success) {
      return fbResult;
    }

    // Fallback to backend OTP reset
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to send reset code' };
      }
      return { success: true, demoOtp: data.demoOtp, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const resetPassword = async (payload: { email: string; otp: string; newPassword: string; confirmPassword?: string }) => {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to reset password' };
      }
      if (data.token) {
        localStorage.setItem('bluejo_token', data.token);
        setToken(data.token);
        setUser(data.user);
        await refreshMe();
      }
      return { success: true, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const quickLogin = async (username: string) => {
    return login(username, 'Bharat@123');
  };

  const register = async (name: string, username: string, email: string, pass: string, dob?: string, profilePhoto?: string) => {
    return initiateSignup({ name, username, email, password: pass, dob, profilePhoto });
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth).catch(() => {});
      const currentToken = localStorage.getItem('bluejo_token');
      if (currentToken) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${currentToken}` }
        }).catch(() => {});
      }
    } finally {
      localStorage.removeItem('bluejo_token');
      setToken(null);
      setUser(null);
      setFirebaseUser(null);
      setUnreadNotifications(0);
      setUnreadMessages(0);
    }
  };

  const logoutAllDevices = async () => {
    try {
      await firebaseSignOut(auth).catch(() => {});
      const currentToken = localStorage.getItem('bluejo_token');
      if (currentToken) {
        await fetch('/api/auth/logout-all', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${currentToken}`
          }
        }).catch(() => {});
      }
    } finally {
      localStorage.removeItem('bluejo_token');
      setToken(null);
      setUser(null);
      setFirebaseUser(null);
      setUnreadNotifications(0);
      setUnreadMessages(0);
    }
    return { success: true, message: 'Logged out from all devices.' };
  };

  const updateUser = async (data: Partial<User>) => {
    if (!token) return { success: false, error: 'Authentication required.' };
    try {
      const res = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      if (result.success && result.user) {
        setUser(result.user);
        return { success: true, user: result.user };
      }
      return { success: false, error: result.error || 'Failed to update profile.' };
    } catch (err: any) {
      console.error('Failed to update profile:', err);
      return { success: false, error: err?.message || 'Network error.' };
    }
  };

  const decrementUnreadMessages = () => {
    setUnreadMessages(prev => Math.max(0, prev - 1));
  };

  const decrementUnreadNotifications = () => {
    setUnreadNotifications(0);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        token,
        isLoading,
        unreadNotifications,
        unreadMessages,
        firebaseSignupWithEmail,
        firebaseLoginWithEmail,
        firebaseSendPasswordReset,
        firebaseSendEmailVerification,
        firebaseSendPhoneOtp,
        firebaseVerifyPhoneOtp,
        firebaseGoogleSignIn,
        checkEmailVerified,
        login,
        googleLogin,
        initiateSignup,
        verifyOtp,
        resendOtp,
        forgotPassword,
        resetPassword,
        quickLogin,
        register,
        logout,
        logoutAllDevices,
        updateUser,
        refreshMe,
        decrementUnreadMessages,
        decrementUnreadNotifications
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
