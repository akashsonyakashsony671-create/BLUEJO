import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  setPersistence,
  browserLocalPersistence,
  RecaptchaVerifier,
  ConfirmationResult
} from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, getDocFromServer } from 'firebase/firestore';
import appletConfig from '../../firebase-applet-config.json';

// Allow environment variables to override applet config if provided
export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || appletConfig.apiKey,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || appletConfig.authDomain,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || appletConfig.projectId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || appletConfig.storageBucket,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || appletConfig.messagingSenderId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || appletConfig.appId,
  firestoreDatabaseId: import.meta.env.VITE_FIREBASE_DATABASE_ID || appletConfig.firestoreDatabaseId || '(default)'
};

// Initialize Firebase app singleton
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Firebase Authentication with persistent local session
export const auth = getAuth(app);
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.warn('Firebase persistence warning:', err);
});

// Initialize Firestore
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Test connection as recommended by Firebase skill
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase Firestore is offline or unreachable.');
    }
    return false;
  }
}

// Map Firebase Auth error codes to user-friendly messages
export function formatFirebaseAuthError(error: any): string {
  if (!error) return 'An unexpected authentication error occurred.';
  const code = error.code || '';
  const message = error.message || '';

  // Extract detected error code from error.code or "(auth/...)" in error.message
  let detectedCode = code;
  if (!detectedCode && typeof message === 'string') {
    const match = message.match(/\((auth\/[^)]+)\)/);
    if (match) {
      detectedCode = match[1];
    }
  }

  switch (detectedCode) {
    case 'auth/operation-not-allowed':
      return `Firebase error (auth/operation-not-allowed): This sign-in provider is not enabled in Firebase Console for project 'bluejo-32459'. In Firebase Console > Authentication > Sign-in method, ensure this provider is enabled and your Web API Key matches.`;
    case 'auth/invalid-email':
      return `Firebase error (auth/invalid-email): The email address entered is invalid. Please check your spelling.`;
    case 'auth/user-disabled':
      return `Firebase error (auth/user-disabled): This BLUEJO account has been disabled. Please contact support.`;
    case 'auth/user-not-found':
      return `Firebase error (auth/user-not-found): No BLUEJO account found with this email or identifier.`;
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return `Firebase error (auth/invalid-credential): Incorrect password or credentials. Please try again.`;
    case 'auth/email-already-in-use':
      return `Firebase error (auth/email-already-in-use): An account already exists with this email address. Please log in.`;
    case 'auth/weak-password':
      return `Firebase error (auth/weak-password): Password is too weak. Please use at least 6 characters with a mix of letters and numbers.`;
    case 'auth/invalid-phone-number':
      return `Firebase error (auth/invalid-phone-number): Invalid phone number format. Please enter a valid mobile number with country code (e.g., +91 98765 43210).`;
    case 'auth/missing-phone-number':
      return `Firebase error (auth/missing-phone-number): Phone number is required. Please enter your mobile number.`;
    case 'auth/quota-exceeded':
      return `Firebase error (auth/quota-exceeded): SMS quota exceeded for this Firebase project. Please try again later.`;
    case 'auth/captcha-check-failed':
      return `Firebase error (auth/captcha-check-failed): reCAPTCHA verification failed. Please refresh the page and try again.`;
    case 'auth/invalid-verification-code':
      return `Firebase error (auth/invalid-verification-code): The 6-digit SMS verification code entered is incorrect. Please check and try again.`;
    case 'auth/code-expired':
      return `Firebase error (auth/code-expired): The SMS verification code has expired. Please request a new code.`;
    case 'auth/too-many-requests':
      return `Firebase error (auth/too-many-requests): Too many attempts. Access temporarily blocked for security. Please wait a few minutes before trying again.`;
    case 'auth/requires-recent-login':
      return `Firebase error (auth/requires-recent-login): This action requires re-authentication. Please log in again.`;
    default:
      if (detectedCode) {
        return `Firebase error (${detectedCode}): ${message || 'Authentication failed. Please try again.'}`;
      }
      return message || 'Authentication failed. Please try again.';
  }
}

// Save user profile information directly in Firestore under /users/{uid}
export async function saveUserProfileToFirestore(
  fbUser: {
    uid: string;
    email?: string | null;
    phoneNumber?: string | null;
    displayName?: string | null;
    photoURL?: string | null;
    emailVerified?: boolean;
  },
  additional?: {
    name?: string;
    username?: string;
    dob?: string;
    phoneNumber?: string;
    profilePhoto?: string;
    isPhoneVerified?: boolean;
  }
): Promise<{ success: boolean; error?: string }> {
  try {
    if (!fbUser?.uid) return { success: false, error: 'User UID missing' };

    const userDocRef = doc(db, 'users', fbUser.uid);
    const existingSnap = await getDoc(userDocRef).catch(() => null);
    const existingData = existingSnap?.exists() ? existingSnap.data() : {};

    const fallbackUsername = (fbUser.email ? fbUser.email.split('@')[0] : (fbUser.phoneNumber ? `user_${fbUser.phoneNumber.slice(-4)}` : `user_${fbUser.uid.slice(0, 5)}`))
      .toLowerCase()
      .replace(/[^a-z0-9_.]/g, '');

    const cleanUsername = (additional?.username || existingData?.username || fallbackUsername)
      .toLowerCase()
      .replace(/[^a-z0-9_.]/g, '');

    const now = new Date().toISOString();

    const profileData = {
      uid: fbUser.uid,
      name: additional?.name || existingData?.name || fbUser.displayName || 'BLUEJO Creator',
      username: cleanUsername,
      email: (fbUser.email || existingData?.email || '').toLowerCase(),
      phoneNumber: fbUser.phoneNumber || additional?.phoneNumber || existingData?.phoneNumber || '',
      profilePhoto: additional?.profilePhoto || existingData?.profilePhoto || fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      isEmailVerified: Boolean(fbUser.emailVerified),
      isPhoneVerified: Boolean(fbUser.phoneNumber || additional?.isPhoneVerified || existingData?.isPhoneVerified),
      createdAt: existingData?.createdAt || now,
      updatedAt: now
    };

    await setDoc(userDocRef, profileData, { merge: true });
    return { success: true };
  } catch (err: any) {
    console.error('Error saving profile to Firestore:', err);
    return { success: false, error: err.message };
  }
}

// Retrieve user profile information directly from Firestore
export async function getUserProfileFromFirestore(uid: string): Promise<any | null> {
  try {
    if (!uid) return null;
    const userDocRef = doc(db, 'users', uid);
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      return snap.data();
    }
    return null;
  } catch (err) {
    console.warn('Could not read user profile from Firestore:', err);
    return null;
  }
}

