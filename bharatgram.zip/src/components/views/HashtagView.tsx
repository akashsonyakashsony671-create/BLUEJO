import React, { useState, useEffect } from 'react';
import { Post, Reel } from '../../types';
import { ArrowLeft, Film, Heart, MessageCircle } from 'lucide-react';

interface HashtagViewProps {
  hashtag: string;
  onBack: () => void;
  onNavigateToPost: (postId: string) => void;
}

export const HashtagView: React.FC<HashtagViewProps> = ({
  hashtag,
  onBack,
  onNavigateToPost
}) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [reels, setReels] = useState<Reel[]>([]);
  const [postCount, setPostCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'posts' | 'reels'>('posts');

  useEffect(() => {
    const fetchHashtagData = async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/search/hashtag/${encodeURIComponent(hashtag)}`);
        const data = await res.json();
        if (data.success) {
          setPosts(data.posts || []);
          setReels(data.reels || []);
          setPostCount(data.postCount || 0);
        }
      } catch (err) {
        console.error('Failed to load hashtag:', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchHashtagData();
  }, [hashtag]);

  return (
    <div className="w-full max-w-4xl mx-auto py-4 px-2 sm:px-4">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onBack}
          className="p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-1">
            <span className="text-orange-600">#</span>
            <span>{hashtag}</span>
          </h2>
          <p className="text-xs text-slate-500 font-medium">{postCount} posts & reels</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-5">
        <button
          onClick={() => setActiveTab('posts')}
          className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'posts'
              ? 'border-orange-600 text-orange-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Posts ({posts.length})
        </button>
        <button
          onClick={() => setActiveTab('reels')}
          className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'reels'
              ? 'border-orange-600 text-orange-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Reels ({reels.length})
        </button>
      </div>

      {/* Grid Content */}
      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <div className="w-8 h-8 border-3 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : activeTab === 'posts' ? (
        posts.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">No posts with #{hashtag} yet</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
            {posts.map((post) => (
              <div
                key={post._id}
                onClick={() => onNavigateToPost(post._id)}
                className="group relative aspect-square bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-xs"
              >
                <img
                  src={post.mediaUrl}
                  alt={post.caption || 'Hashtag item'}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
                  <div className="flex items-center gap-1 font-bold text-xs">
                    <Heart className="w-4 h-4 fill-white" />
                    <span>{post.likesCount}</span>
                  </div>
                  <div className="flex items-center gap-1 font-bold text-xs">
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>{post.commentsCount}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : reels.length === 0 ? (
        <div className="py-12 text-center text-xs text-slate-400">No reels with #{hashtag} yet</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
          {reels.map((reel) => (
            <div
              key={reel._id}
              className="relative aspect-[9/16] bg-slate-900 rounded-2xl overflow-hidden cursor-pointer group"
            >
              <video src={reel.videoUrl} className="w-full h-full object-cover" />
              <div className="absolute top-2 right-2 p-1 rounded-md bg-black/60 text-white">
                <Film className="w-4 h-4" />
              </div>
              <div className="absolute bottom-2 left-2 right-2 text-white drop-shadow-sm text-[11px] font-medium truncate">
                {reel.caption}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
