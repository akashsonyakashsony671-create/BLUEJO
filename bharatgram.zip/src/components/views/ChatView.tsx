import React, { useState, useEffect, useRef } from 'react';
import { Conversation, Message, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import { useLanguage } from '../../context/LanguageContext';
import { VerifiedBadge } from '../common/Badge';
import {
  Send,
  Image as ImageIcon,
  ArrowLeft,
  Circle,
  MessageSquare,
  Search,
  Check,
  CheckCheck
} from 'lucide-react';

interface ChatViewProps {
  initialUserId?: string;
  onNavigateToUser: (username: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  initialUserId,
  onNavigateToUser
}) => {
  const { user, token, decrementUnreadMessages } = useAuth();
  const { onlineUsers, lastMessage, sendMessageToSocket } = useSocket();
  const { t } = useLanguage();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [isLoadingConversations, setIsLoadingConversations] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [searchUserQuery, setSearchUserQuery] = useState('');
  const [userSearchResults, setUserSearchResults] = useState<User[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Load conversations
  const fetchConversations = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/conversations', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success && data.conversations) {
        setConversations(data.conversations);

        // If initialUserId provided, auto-select or create conversation
        if (initialUserId && !activeConversation) {
          const existing = data.conversations.find((c: Conversation) => c.otherUser?._id === initialUserId);
          if (existing) {
            setActiveConversation(existing);
          } else {
            startChatWithUser(initialUserId);
          }
        }
      }
    } catch (err) {
      console.error('Failed to load conversations:', err);
    } finally {
      setIsLoadingConversations(false);
    }
  };

  useEffect(() => {
    fetchConversations();
  }, [token, initialUserId]);

  // When active conversation changes, load its message history
  useEffect(() => {
    if (!activeConversation || !token) return;

    const fetchMessages = async () => {
      setIsLoadingMessages(true);
      try {
        const res = await fetch(`/api/messages/${activeConversation._id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.success && data.messages) {
          setMessages(data.messages);
          decrementUnreadMessages();
          setTimeout(() => {
            messagesEndRef.current?.scrollIntoView({ behavior: 'auto' });
          }, 100);
        }
      } catch (err) {
        console.error('Failed to load messages:', err);
      } finally {
        setIsLoadingMessages(false);
      }
    };
    fetchMessages();
  }, [activeConversation?._id, token]);

  // Reactive message updates from WebSocket
  useEffect(() => {
    if (!lastMessage) return;
    if (activeConversation && lastMessage.conversationId === activeConversation._id) {
      setMessages(prev => {
        if (prev.some(m => m._id === lastMessage._id)) return prev;
        return [...prev, lastMessage];
      });
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    }

    // Refresh conversation list to show last message preview
    setConversations(prev =>
      prev.map(c => {
        if (c._id === lastMessage.conversationId) {
          return {
            ...c,
            lastMessage: lastMessage.text,
            lastMessageAt: lastMessage.createdAt
          };
        }
        return c;
      })
    );
  }, [lastMessage, activeConversation]);

  const startChatWithUser = async (targetId: string) => {
    if (!token) return;
    try {
      const res = await fetch('/api/conversations/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId: targetId })
      });
      const data = await res.json();
      if (data.success && data.conversation) {
        setActiveConversation(data.conversation);
        fetchConversations();
        setUserSearchResults([]);
        setSearchUserQuery('');
      }
    } catch (err) {
      console.error('Failed to start chat:', err);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent, mediaUrl?: string) => {
    if (e) e.preventDefault();
    if ((!messageText.trim() && !mediaUrl) || !activeConversation || !token || !user) return;

    const otherUserId = activeConversation.otherUser?._id;
    if (!otherUserId) return;

    const textToSend = messageText.trim();
    setMessageText('');

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          conversationId: activeConversation._id,
          receiverId: otherUserId,
          text: textToSend,
          mediaUrl
        })
      });

      const data = await res.json();
      if (data.success && data.message) {
        setMessages(prev => [...prev, data.message]);
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 50);
      }
    } catch (err) {
      console.error('Failed to send message:', err);
    }
  };

  // User search for new chat
  useEffect(() => {
    if (!searchUserQuery.trim()) {
      setUserSearchResults([]);
      return;
    }
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(searchUserQuery.trim())}`);
        const data = await res.json();
        if (data.success && data.users) {
          setUserSearchResults(data.users.filter((u: User) => u._id !== user?._id));
        }
      } catch (err) {
        console.error(err);
      }
    }, 250);
    return () => clearTimeout(t);
  }, [searchUserQuery, user?._id]);

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && token) {
      const file = e.target.files[0];
      const formData = new FormData();
      formData.append('media', file);
      try {
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: formData
        });
        const data = await res.json();
        if (data.success && data.url) {
          handleSendMessage(undefined, data.url);
        }
      } catch (err) {
        console.error('Failed to upload image:', err);
      }
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto h-[calc(100vh-80px)] p-2 sm:p-4">
      <div className="w-full h-full bg-white border border-slate-200 rounded-3xl shadow-md overflow-hidden flex flex-col md:flex-row">
        {/* Left Pane: Conversation List */}
        <div
          className={`w-full md:w-80 border-r border-slate-200 flex flex-col ${
            activeConversation ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Header */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-orange-600" />
              <span>{t('messages')}</span>
            </h2>
          </div>

          {/* Search Indian Creators */}
          <div className="p-3 border-b border-slate-100 relative">
            <div className="flex items-center gap-2 bg-slate-100 rounded-xl px-3 py-2 text-xs">
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search Indian creators to chat..."
                value={searchUserQuery}
                onChange={(e) => setSearchUserQuery(e.target.value)}
                className="w-full bg-transparent outline-hidden text-slate-800 placeholder-slate-400"
              />
            </div>

            {/* Autocomplete for starting new chat */}
            {userSearchResults.length > 0 && (
              <div className="absolute top-full left-3 right-3 mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-20 max-h-48 overflow-y-auto p-1">
                {userSearchResults.map((u) => (
                  <div
                    key={u._id}
                    onClick={() => startChatWithUser(u._id)}
                    className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-orange-50 cursor-pointer"
                  >
                    <img
                      src={u.profilePhoto}
                      alt={u.username}
                      className="w-7 h-7 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-slate-800 truncate">{u.name}</div>
                      <div className="text-[10px] text-slate-400 truncate">@{u.username}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Conversations Scroll List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {isLoadingConversations ? (
              <div className="flex items-center justify-center h-32">
                <div className="w-6 h-6 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : conversations.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs">
                {t('noMessagesYet')}. Search for creators above to chat!
              </div>
            ) : (
              conversations.map((conv) => {
                const isSelected = activeConversation?._id === conv._id;
                const isOnline = conv.otherUser && onlineUsers.has(conv.otherUser._id);

                return (
                  <div
                    key={conv._id}
                    onClick={() => setActiveConversation(conv)}
                    className={`flex items-center gap-3 p-3.5 cursor-pointer transition-colors ${
                      isSelected ? 'bg-orange-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="relative flex-shrink-0">
                      <img
                        src={
                          conv.otherUser?.profilePhoto ||
                          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                        }
                        alt={conv.otherUser?.username || 'User'}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover border border-slate-200"
                      />
                      {isOnline && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-xs text-slate-900 truncate">
                            {conv.otherUser?.name || 'User'}
                          </span>
                          {conv.otherUser?.isVerified && <VerifiedBadge size="sm" />}
                        </div>
                        {conv.lastMessageAt && (
                          <span className="text-[10px] text-slate-400">
                            {new Date(conv.lastMessageAt).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">
                        {conv.lastMessage || 'Started a conversation'}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Pane: Active Chat Messages */}
        <div
          className={`flex-1 flex flex-col bg-slate-50/50 ${
            !activeConversation ? 'hidden md:flex' : 'flex'
          }`}
        >
          {activeConversation ? (
            <>
              {/* Chat Top Bar */}
              <div className="p-3.5 bg-white border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setActiveConversation(null)}
                    className="md:hidden p-1.5 rounded-full hover:bg-slate-100 text-slate-600"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>

                  <img
                    src={activeConversation.otherUser?.profilePhoto}
                    alt={activeConversation.otherUser?.username}
                    referrerPolicy="no-referrer"
                    onClick={() => {
                      if (activeConversation.otherUser?.username) {
                        onNavigateToUser(activeConversation.otherUser.username);
                      }
                    }}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 cursor-pointer"
                  />

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span
                        onClick={() => {
                          if (activeConversation.otherUser?.username) {
                            onNavigateToUser(activeConversation.otherUser.username);
                          }
                        }}
                        className="font-bold text-xs sm:text-sm text-slate-900 hover:underline cursor-pointer"
                      >
                        {activeConversation.otherUser?.name}
                      </span>
                      {activeConversation.otherUser?.isVerified && <VerifiedBadge size="sm" />}
                    </div>

                    <div className="text-[11px] text-slate-500 flex items-center gap-1">
                      {activeConversation.otherUser &&
                      onlineUsers.has(activeConversation.otherUser._id) ? (
                        <span className="text-emerald-600 font-semibold flex items-center gap-1">
                          <Circle className="w-2 h-2 fill-emerald-500 text-emerald-500" />
                          {t('online')}
                        </span>
                      ) : (
                        <span>@{activeConversation.otherUser?.username}</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Message List */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {isLoadingMessages ? (
                  <div className="flex items-center justify-center h-32">
                    <div className="w-6 h-6 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="py-12 text-center text-xs text-slate-400">
                    No messages yet. Send a greeting to start chatting!
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isMine = msg.senderId === user?._id;
                    return (
                      <div
                        key={msg._id}
                        className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[75%] rounded-2xl p-3 shadow-2xs ${
                            isMine
                              ? 'bg-orange-600 text-white rounded-br-xs'
                              : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                          }`}
                        >
                          {msg.mediaUrl && (
                            <img
                              src={msg.mediaUrl}
                              alt="Attachment"
                              referrerPolicy="no-referrer"
                              className="w-full max-h-60 rounded-xl object-cover mb-1.5 cursor-pointer"
                              onClick={() => window.open(msg.mediaUrl, '_blank')}
                            />
                          )}

                          {msg.text && (
                            <p className="text-xs sm:text-sm leading-relaxed break-words">
                              {msg.text}
                            </p>
                          )}

                          <div
                            className={`flex items-center justify-end gap-1 text-[9px] mt-1 ${
                              isMine ? 'text-white/70' : 'text-slate-400'
                            }`}
                          >
                            <span>
                              {new Date(msg.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                            {isMine && <CheckCheck className="w-3 h-3" />}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input Box */}
              <form
                onSubmit={(e) => handleSendMessage(e)}
                className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
              >
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageSelect}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="p-2 text-slate-400 hover:text-orange-600 rounded-full hover:bg-slate-100 transition-colors"
                  title="Share image"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>

                <input
                  type="text"
                  placeholder={t('typeMessage')}
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  className="flex-1 text-xs sm:text-sm bg-slate-100 border border-transparent focus:border-orange-500 rounded-full px-4 py-2.5 outline-hidden transition-all"
                />

                <button
                  type="submit"
                  disabled={!messageText.trim()}
                  className="p-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white rounded-full transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mb-3">
                <MessageSquare className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-slate-700 text-sm">Your Messages</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Select a conversation or start a new chat with any creator on BLUEJO.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
