import React, { useState, useEffect } from 'react';
import { Post, Reel, User } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { VerifiedBadge } from '../common/Badge';
import { Search, Sparkles, Film, Heart, MessageCircle, TrendingUp } from 'lucide-react';

interface ExploreViewProps {
  onNavigateToPost: (postId: string) => void;
  onNavigateToUser: (username: string) => void;
  onNavigateToHashtag: (tag: string) => void;
}

export const ExploreView: React.FC<ExploreViewProps> = ({
  onNavigateToPost,
  onNavigateToUser,
  onNavigateToHashtag
}) => {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ users: User[]; hashtags: any[] }>({
    users: [],
    hashtags: []
  });
  const [isSearching, setIsSearching] = useState(false);
  const [trendingTags, setTrendingTags] = useState<{ tag: string; count: number }[]>([]);
  const [explorePosts, setExplorePosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch explore posts and trending hashtags
  useEffect(() => {
    const loadExploreData = async () => {
      try {
        const [postsRes, tagsRes] = await Promise.all([
          fetch('/api/posts'),
          fetch('/api/search/trending-hashtags')
        ]);
        const postsData = await postsRes.json();
        const tagsData = await tagsRes.json();

        if (postsData.success) setExplorePosts(postsData.posts);
        if (tagsData.success) setTrendingTags(tagsData.trending);
      } catch (err) {
        console.error('Failed to load explore data:', err);
      } finally {
        setIsLoading(false);
      }
    };
    loadExploreData();
  }, []);

  // Search autocomplete
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults({ users: [], hashtags: [] });
      setIsSearching(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`);
        const data = await res.json();
        if (data.success) {
          setSearchResults({ users: data.users || [], hashtags: data.hashtags || [] });
        }
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  return (
    <div className="w-full max-w-4xl mx-auto py-4 px-2 sm:px-4">
      {/* Search Input Bar */}
      <div className="relative mb-6">
        <div className="flex items-center gap-3 bg-white border border-slate-200/90 rounded-2xl px-4 py-3 shadow-xs focus-within:border-orange-500 focus-within:ring-2 focus-within:ring-orange-100 transition-all">
          <Search className="w-5 h-5 text-slate-400 flex-shrink-0" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 text-xs sm:text-sm bg-transparent outline-hidden text-slate-800 placeholder-slate-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              Clear
            </button>
          )}
        </div>

        {/* Search Results Dropdown */}
        {searchQuery.trim() && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-slate-200 z-30 overflow-hidden max-h-96 overflow-y-auto animate-in fade-in-50">
            {isSearching ? (
              <div className="p-4 text-center text-xs text-slate-400">Searching BLUEJO...</div>
            ) : searchResults.users.length === 0 && searchResults.hashtags.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-400">No results found for "{searchQuery}"</div>
            ) : (
              <div className="p-2 space-y-1">
                {/* Users list */}
                {searchResults.users.map((u) => (
                  <div
                    key={u._id}
                    onClick={() => onNavigateToUser(u.username)}
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-orange-50/60 cursor-pointer transition-colors"
                  >
                    <img
                      src={u.profilePhoto}
                      alt={u.username}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover border border-slate-200"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="font-bold text-xs text-slate-900 truncate">{u.name}</span>
                        {u.isVerified && <VerifiedBadge size="sm" />}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">@{u.username}</div>
                    </div>
                  </div>
                ))}

                {/* Hashtags list */}
                {searchResults.hashtags.map((h) => (
                  <div
                    key={h.tag}
                    onClick={() => onNavigateToHashtag(h.tag)}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-orange-50/60 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold text-xs">
                        #
                      </div>
                      <div className="font-bold text-xs text-slate-800">#{h.tag}</div>
                    </div>
                    <span className="text-[11px] text-slate-400">{h.count} posts</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Trending Indian Hashtags Pills */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2.5">
          <TrendingUp className="w-4 h-4 text-orange-600" />
          <span>{t('trendingInIndia')}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {trendingTags.map((item) => (
            <button
              key={item.tag}
              onClick={() => onNavigateToHashtag(item.tag)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white hover:bg-orange-50 border border-slate-200 hover:border-orange-300 text-xs font-semibold text-slate-700 hover:text-orange-600 transition-all shadow-2xs"
            >
              <span className="text-orange-600 font-bold">#</span>
              <span>{item.tag}</span>
              <span className="text-[10px] text-slate-400 font-normal ml-0.5">({item.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Explore Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
        {explorePosts.map((post) => (
          <div
            key={post._id}
            onClick={() => onNavigateToPost(post._id)}
            className="group relative aspect-square bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-xs hover:shadow-md transition-shadow"
          >
            {post.mediaType === 'video' ? (
              <video
                src={post.mediaUrl}
                muted
                playsInline
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src={post.mediaUrl}
                alt={post.caption || 'Explore post'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            )}

            {/* Video Badge */}
            {post.mediaType === 'video' && (
              <div className="absolute top-2.5 right-2.5 p-1 rounded-md bg-black/60 text-white backdrop-blur-xs">
                <Film className="w-4 h-4" />
              </div>
            )}

            {/* Hover overlay with likes and comments */}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
              <div className="flex items-center gap-1 font-bold text-xs">
                <Heart className="w-4 h-4 fill-white" />
                <span>{post.likesCount}</span>
              </div>
              <div className="flex items-center gap-1 font-bold text-xs">
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>{post.commentsCount}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
