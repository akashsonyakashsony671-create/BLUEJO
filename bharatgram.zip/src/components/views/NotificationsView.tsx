import React, { useState, useEffect } from 'react';
import { NotificationItem } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { VerifiedBadge } from '../common/Badge';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  Check,
  X,
  CheckCheck
} from 'lucide-react';

interface NotificationsViewProps {
  onNavigateToUser: (username: string) => void;
  onNavigateToPost: (postId: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onNavigateToUser,
  onNavigateToPost
}) => {
  const { token, decrementUnreadNotifications } = useAuth();
  const { t } = useLanguage();

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'likes' | 'comments' | 'follows'>('all');
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotifications = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success && data.notifications) {
        setNotifications(data.notifications);
        decrementUnreadNotifications();
      }
    } catch (err) {
      console.error('Failed to load notifications:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [token]);

  const handleMarkAllRead = async () => {
    if (!token) return;
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    try {
      await fetch('/api/notifications/read-all', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleFollowRequest = async (senderId: string, action: 'accept' | 'reject') => {
    if (!token) return;
    try {
      await fetch(`/api/users/follow-requests/${senderId}/${action}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      // Remove from notifications list
      setNotifications(prev => prev.filter(n => !(n.senderId === senderId && n.type === 'follow_request')));
    } catch (err) {
      console.error('Failed to respond to follow request:', err);
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'likes') return n.type === 'like_post' || n.type === 'like_reel';
    if (filter === 'comments') return n.type === 'comment' || n.type === 'reply';
    if (filter === 'follows') return n.type === 'follow' || n.type === 'follow_request';
    return true;
  });

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like_post':
      case 'like_reel':
        return <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />;
      case 'comment':
      case 'reply':
        return <MessageCircle className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />;
      case 'follow':
      case 'follow_request':
        return <UserPlus className="w-3.5 h-3.5 text-blue-500" />;
      default:
        return <Bell className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  const getMessageText = (item: NotificationItem) => {
    switch (item.type) {
      case 'like_post':
        return 'liked your post.';
      case 'like_reel':
        return 'liked your reel.';
      case 'comment':
        return 'commented on your post.';
      case 'reply':
        return 'replied to your comment.';
      case 'follow':
        return 'started following you.';
      case 'follow_request':
        return 'requested to follow your private account.';
      default:
        return 'interacted with your content.';
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto py-4 px-2 sm:px-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Bell className="w-5 h-5 text-orange-600" />
          <span>{t('notifications')}</span>
        </h2>

        {notifications.some(n => !n.isRead) && (
          <button
            onClick={handleMarkAllRead}
            className="flex items-center gap-1 text-xs font-semibold text-orange-600 hover:text-orange-700 transition-colors"
          >
            <CheckCheck className="w-4 h-4" />
            <span>Mark all as read</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 mb-5 overflow-x-auto no-scrollbar">
        {(['all', 'likes', 'comments', 'follows'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold capitalize transition-colors ${
              filter === tab
                ? 'bg-orange-600 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* List */}
      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <div className="w-7 h-7 border-3 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : filteredNotifications.length === 0 ? (
        <div className="py-16 text-center text-slate-400">
          <Bell className="w-10 h-10 mx-auto mb-2 opacity-40" />
          <p className="text-xs font-bold text-slate-600">{t('noNotificationsYet')}</p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs divide-y divide-slate-100 overflow-hidden">
          {filteredNotifications.map((n) => (
            <div
              key={n._id}
              className={`p-3.5 sm:p-4 flex items-center justify-between gap-3 transition-colors ${
                !n.isRead ? 'bg-orange-50/40' : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="relative flex-shrink-0">
                  <img
                    src={n.sender?.profilePhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                    alt={n.sender?.username || 'User'}
                    referrerPolicy="no-referrer"
                    onClick={() => n.sender && onNavigateToUser(n.sender.username)}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 cursor-pointer"
                  />
                  <div className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-white shadow-2xs">
                    {getIcon(n.type)}
                  </div>
                </div>

                <div className="flex-1 min-w-0 text-xs text-slate-800">
                  <span
                    onClick={() => n.sender && onNavigateToUser(n.sender.username)}
                    className="font-bold text-slate-900 mr-1 hover:underline cursor-pointer"
                  >
                    {n.sender?.username}
                  </span>
                  {n.sender?.isVerified && <VerifiedBadge size="sm" />}
                  <span className="ml-1 text-slate-700">{getMessageText(n)}</span>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {new Date(n.createdAt).toLocaleDateString([], {
                      month: 'short',
                      day: 'numeric'
                    })}
                  </div>
                </div>
              </div>

              {/* Action: Accept/Reject if follow request, or view post */}
              {n.type === 'follow_request' ? (
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => handleFollowRequest(n.senderId, 'accept')}
                    className="p-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors"
                    title="Accept"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleFollowRequest(n.senderId, 'reject')}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                    title="Decline"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : n.targetId && (n.type === 'like_post' || n.type === 'comment') ? (
                <button
                  onClick={() => onNavigateToPost(n.targetId!)}
                  className="text-xs font-semibold text-orange-600 hover:underline flex-shrink-0"
                >
                  View
                </button>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
