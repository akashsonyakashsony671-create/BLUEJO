import React, { useState, useEffect, useMemo } from 'react';
import { User, Post, Reel } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { VerifiedBadge, PrivateBadge } from '../common/Badge';
import {
  Grid3X3,
  Film,
  Bookmark,
  MapPin,
  Globe,
  Settings,
  UserPlus,
  UserCheck,
  Clock,
  MessageSquare,
  Share2,
  Lock,
  Sparkles,
  Heart,
  Calendar,
  Eye,
  Search,
  X,
  Edit3,
  ChevronRight,
  ExternalLink,
  CheckCircle2,
  Copy,
  Music2,
  Trophy,
  ShieldCheck
} from 'lucide-react';

interface ProfileViewProps {
  username: string;
  initialTab?: 'posts' | 'reels' | 'saved' | 'about';
  onNavigateToPost: (postId: string) => void;
  onNavigateToUser: (username: string) => void;
  onStartChat: (userId: string) => void;
  onOpenSettings: () => void;
  onOpenEditProfile: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  username,
  initialTab = 'posts',
  onNavigateToPost,
  onNavigateToUser,
  onStartChat,
  onOpenSettings,
  onOpenEditProfile
}) => {
  const { user: currentUser, token } = useAuth();
  const { t } = useLanguage();

  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [reels, setReels] = useState<Reel[]>([]);
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [isPrivateHidden, setIsPrivateHidden] = useState(false);
  const [activeTab, setActiveTab] = useState<'posts' | 'reels' | 'saved' | 'about'>(initialTab);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Follow state
  const [isFollowing, setIsFollowing] = useState(false);
  const [isFollowPending, setIsFollowPending] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [isFollowActionLoading, setIsFollowActionLoading] = useState(false);

  // Followers / Following Modal
  const [followModalType, setFollowModalType] = useState<'followers' | 'following' | null>(null);
  const [followListUsers, setFollowListUsers] = useState<User[]>([]);
  const [followSearchQuery, setFollowSearchQuery] = useState('');
  const [isLoadingFollowList, setIsLoadingFollowList] = useState(false);

  // Toast Notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const fetchProfile = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const headers: Record<string, string> = {};
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await fetch(`/api/users/profile/${encodeURIComponent(username)}`, { headers });
      const data = await res.json();

      if (data.success && data.user) {
        setProfileUser(data.user);
        setPosts(data.posts || []);
        setReels(data.reels || []);
        setSavedPosts(data.savedPosts || []);
        setIsPrivateHidden(Boolean(data.isPrivateHidden));
        setIsFollowing(Boolean(data.user.isFollowing));
        setIsFollowPending(Boolean(data.user.isFollowPending));
        setFollowersCount(data.user.followersCount || 0);
        setFollowingCount(data.user.followingCount || 0);
      } else {
        setErrorMessage(data.error || 'User not found on BLUEJO');
      }
    } catch (err: any) {
      console.error('Failed to load profile:', err);
      setErrorMessage('Could not connect to BLUEJO server.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (username) {
      fetchProfile();
    }
  }, [username, token]);

  const isMe = profileUser?.isMe || (currentUser && profileUser && currentUser._id === profileUser._id);

  const handleToggleFollow = async () => {
    if (!token) {
      showToast('Please sign in to follow creators.');
      return;
    }
    if (!profileUser || isMe) return;

    setIsFollowActionLoading(true);
    const prevFollowing = isFollowing;
    const prevPending = isFollowPending;
    const prevFollowersCount = followersCount;

    // Optimistic UI update
    if (prevFollowing) {
      setIsFollowing(false);
      setIsFollowPending(false);
      setFollowersCount(Math.max(0, prevFollowersCount - 1));
    } else if (prevPending) {
      setIsFollowPending(false);
    } else {
      if (profileUser.isPrivate) {
        setIsFollowPending(true);
      } else {
        setIsFollowing(true);
        setFollowersCount(prevFollowersCount + 1);
      }
    }

    try {
      const res = await fetch(`/api/users/${profileUser.username}/follow`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId: profileUser._id })
      });
      const data = await res.json();

      if (data.success) {
        setIsFollowing(Boolean(data.following || data.isFollowing));
        setIsFollowPending(Boolean(data.status === 'requested' || data.isPending));
        if (typeof data.followersCount === 'number') {
          setFollowersCount(data.followersCount);
        }
        if (data.status === 'accepted') {
          showToast(`Now following @${profileUser.username}`);
        } else if (data.status === 'requested') {
          showToast('Follow request sent.');
        } else {
          showToast(`Unfollowed @${profileUser.username}`);
        }
      } else {
        // Revert on failure
        setIsFollowing(prevFollowing);
        setIsFollowPending(prevPending);
        setFollowersCount(prevFollowersCount);
        showToast(data.error || 'Failed to update follow status');
      }
    } catch (err) {
      setIsFollowing(prevFollowing);
      setIsFollowPending(prevPending);
      setFollowersCount(prevFollowersCount);
      showToast('Network error while updating follow');
    } finally {
      setIsFollowActionLoading(false);
    }
  };

  const openFollowListModal = async (type: 'followers' | 'following') => {
    if (!profileUser) return;
    setFollowModalType(type);
    setFollowSearchQuery('');
    setIsLoadingFollowList(true);
    try {
      const headers: Record<string, string> = {};
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await fetch(`/api/users/${profileUser.username}/${type}`, { headers });
      const data = await res.json();
      if (data.success && (data.users || data[type])) {
        setFollowListUsers(data.users || data[type]);
      } else {
        setFollowListUsers([]);
      }
    } catch (err) {
      console.error('Failed to load list:', err);
      setFollowListUsers([]);
    } finally {
      setIsLoadingFollowList(false);
    }
  };

  const handleCopyProfileLink = () => {
    const url = `${window.location.origin}/profile/${profileUser?.username || username}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url);
      showToast('Profile link copied to clipboard!');
    } else {
      showToast(url);
    }
  };

  // Filter follow list
  const filteredFollowUsers = useMemo(() => {
    if (!followSearchQuery.trim()) return followListUsers;
    const q = followSearchQuery.toLowerCase();
    return followListUsers.filter(
      u => u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)
    );
  }, [followListUsers, followSearchQuery]);

  // Formatted join date
  const joinedDateText = useMemo(() => {
    if (!profileUser?.createdAt) return '2026';
    try {
      const d = new Date(profileUser.createdAt);
      return d.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
    } catch {
      return '2026';
    }
  }, [profileUser]);

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-3 sm:px-6 py-4">
        {/* Skeleton header */}
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden mb-6 animate-pulse">
          <div className="h-28 sm:h-36 w-full bg-slate-100 border-b border-slate-200/60" />
          <div className="p-5 sm:p-8 pt-0">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 -mt-12 sm:-mt-14 mb-6">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-slate-200 border-4 border-white shrink-0" />
              <div className="space-y-2 flex-1 pt-2 sm:pt-14 text-center sm:text-left">
                <div className="h-6 bg-slate-200 rounded-md w-48 mx-auto sm:mx-0" />
                <div className="h-4 bg-slate-100 rounded-md w-32 mx-auto sm:mx-0" />
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2 pt-4 border-t border-slate-100">
              <div className="h-14 bg-slate-50 rounded-2xl" />
              <div className="h-14 bg-slate-50 rounded-2xl" />
              <div className="h-14 bg-slate-50 rounded-2xl" />
              <div className="h-14 bg-slate-50 rounded-2xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (errorMessage || !profileUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center mx-auto mb-4 border border-orange-200">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">User Not Found</h2>
        <p className="text-xs text-slate-500 mb-6">
          The user <span className="font-semibold text-slate-700">@{username}</span> does not exist or has been suspended.
        </p>
        <button
          onClick={() => onNavigateToUser('aarav_tech')}
          className="px-5 py-2.5 rounded-xl bg-orange-600 text-white font-semibold text-xs shadow-md shadow-orange-600/20 hover:bg-orange-700 transition-all cursor-pointer"
        >
          Explore Popular Creators
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-4 pb-20 select-none">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 backdrop-blur-md text-white px-4 py-2.5 rounded-2xl shadow-xl border border-white/10 text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          {toastMessage}
        </div>
      )}

      {/* Clean, Premium Original BLUEJO Profile Header Container */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden mb-6">
        {/* Subtle Neutral Header Zone matching existing website aesthetic */}
        <div className="relative h-28 sm:h-36 w-full bg-slate-100/80 border-b border-slate-200/70 overflow-hidden">
          {/* Delicate subtle monochrome geometric micro-texture */}
          <div
            className="absolute inset-0 opacity-[0.035] pointer-events-none"
            style={{
              backgroundImage: `radial-gradient(#0f172a 1px, transparent 1px)`,
              backgroundSize: '16px 16px'
            }}
          />

          {/* Soft neutral shading */}
          <div className="absolute inset-0 bg-gradient-to-b from-slate-200/35 via-transparent to-slate-100/90 pointer-events-none" />

          {/* Top Header Quick Action Buttons */}
          <div className="absolute top-3 right-3 sm:top-4 sm:right-4 flex items-center gap-2 z-10">
            <button
              onClick={handleCopyProfileLink}
              className="px-3 py-1.5 rounded-full bg-white/95 hover:bg-white text-slate-700 hover:text-slate-900 text-[11px] font-semibold border border-slate-200 shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
              title="Copy direct profile link"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Share</span>
            </button>

            {isMe ? (
              <button
                onClick={onOpenSettings}
                className="p-1.5 sm:p-2 rounded-full bg-white/95 hover:bg-white text-slate-700 hover:text-slate-900 border border-slate-200 shadow-2xs transition-all cursor-pointer"
                title="Account Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => onStartChat(profileUser._id)}
                className="px-3.5 py-1.5 rounded-full bg-orange-600 hover:bg-orange-700 text-white font-bold text-[11px] shadow-sm shadow-orange-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Namaste / Chat</span>
              </button>
            )}
          </div>

          {/* Subtle Member Badge Bottom Left */}
          <div className="absolute bottom-2.5 left-4 sm:bottom-3 sm:left-6 text-slate-500 text-[11px] font-semibold tracking-wide flex items-center gap-1.5">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>BLUEJO Member</span>
          </div>
        </div>

        {/* Profile Details & Metric Stats */}
        <div className="px-5 sm:px-8 pb-6 pt-0">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            {/* Avatar and Identity */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 text-center sm:text-left -mt-12 sm:-mt-14">
              {/* Avatar with Clean Double Ring */}
              <div className="relative shrink-0">
                <div className="p-1 rounded-full bg-white shadow-md border-2 border-slate-200/90">
                  <img
                    src={profileUser.profilePhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                    alt={profileUser.name}
                    referrerPolicy="no-referrer"
                    className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover bg-slate-100"
                  />
                </div>
                {profileUser.isVerified && (
                  <div
                    className="absolute bottom-1 right-1 p-1 rounded-full bg-blue-600 shadow-md text-white ring-2 ring-white"
                    title="BLUEJO Verified Creator"
                  >
                    <ShieldCheck className="w-4 h-4 fill-white text-blue-600" />
                  </div>
                )}
              </div>

              {/* User details */}
              <div className="flex-1 min-w-0 pt-1 sm:pt-4">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {profileUser.name}
                  </h1>
                  {profileUser.isPrivate && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200">
                      <Lock className="w-2.5 h-2.5" /> Private
                    </span>
                  )}
                </div>

                {/* Handle with quick copy */}
                <div className="flex items-center justify-center sm:justify-start gap-2 mb-3">
                  <span className="text-xs sm:text-sm font-bold text-orange-600">
                    @{profileUser.username}
                  </span>
                  <button
                    onClick={handleCopyProfileLink}
                    className="p-1 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
                    title="Copy profile link"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                </div>

                {/* Bio with hashtag highlights */}
                {profileUser.bio && (
                  <p className="text-xs sm:text-[13px] text-slate-700 leading-relaxed max-w-xl mb-4 font-normal whitespace-pre-line">
                    {profileUser.bio.split(' ').map((word, i) => {
                      if (word.startsWith('#')) {
                        return (
                          <span key={i} className="text-orange-600 font-semibold hover:underline cursor-pointer">
                            {word}{' '}
                          </span>
                        );
                      }
                      if (word.startsWith('@')) {
                        return (
                          <span
                            key={i}
                            onClick={() => onNavigateToUser(word.slice(1))}
                            className="text-amber-700 font-semibold hover:underline cursor-pointer"
                          >
                            {word}{' '}
                          </span>
                        );
                      }
                      return word + ' ';
                    })}
                  </p>
                )}

                {/* Rich Meta Pill Tags */}
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-slate-600">
                  {profileUser.location && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-50 border border-slate-200/80 text-slate-800 font-medium text-[11px]">
                      <MapPin className="w-3.5 h-3.5 text-orange-600 shrink-0" />
                      <span>{profileUser.location}</span>
                    </span>
                  )}

                  {profileUser.website && (
                    <a
                      href={profileUser.website.startsWith('http') ? profileUser.website : `https://${profileUser.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/80 text-slate-800 font-medium text-[11px] transition-colors"
                    >
                      <Globe className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span className="truncate max-w-[150px]">
                        {profileUser.website.replace(/^https?:\/\//, '')}
                      </span>
                      <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                    </a>
                  )}

                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-slate-50 border border-slate-200/80 text-slate-500 text-[11px]">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>Joined {joinedDateText}</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Action Button Section */}
            <div className="flex items-center justify-center md:justify-end gap-2.5 shrink-0 pt-2 md:pt-4">
              {isMe ? (
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={onOpenEditProfile}
                    className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-sm shadow-orange-600/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Profile</span>
                  </button>

                  <button
                    onClick={onOpenSettings}
                    className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
                    title="Settings"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2.5 w-full sm:w-auto">
                  <button
                    onClick={handleToggleFollow}
                    disabled={isFollowActionLoading}
                    className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-xs ${
                      isFollowing
                        ? 'bg-slate-100 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 border border-slate-200 text-slate-800'
                        : isFollowPending
                        ? 'bg-amber-50 border border-amber-300 text-amber-800'
                        : 'bg-orange-600 hover:bg-orange-700 text-white shadow-sm shadow-orange-600/20'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4 text-emerald-600" />
                        <span>Following</span>
                      </>
                    ) : isFollowPending ? (
                      <>
                        <Clock className="w-4 h-4 text-amber-600" />
                        <span>Requested</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => onStartChat(profileUser._id)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-orange-50 hover:border-orange-200 text-slate-700 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-orange-600" />
                    <span className="hidden sm:inline">Message</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Original BLUEJO Metric Stat Bar */}
          <div className="grid grid-cols-4 gap-2 sm:gap-4 mt-6 pt-6 border-t border-slate-100">
            {/* Posts Count */}
            <div
              onClick={() => setActiveTab('posts')}
              className="flex flex-col items-center justify-center p-2.5 sm:p-3.5 rounded-2xl bg-slate-50/80 hover:bg-slate-100/70 border border-slate-200/70 hover:border-slate-300 transition-all cursor-pointer group"
            >
              <span className="text-base sm:text-xl font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                {profileUser.postCount || posts.length}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase tracking-wider mt-0.5">
                Posts
              </span>
            </div>

            {/* Followers Count */}
            <div
              onClick={() => openFollowListModal('followers')}
              className="flex flex-col items-center justify-center p-2.5 sm:p-3.5 rounded-2xl bg-slate-50/80 hover:bg-slate-100/70 border border-slate-200/70 hover:border-slate-300 transition-all cursor-pointer group"
            >
              <span className="text-base sm:text-xl font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                {followersCount}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase tracking-wider mt-0.5 flex items-center gap-1">
                <span>Followers</span>
                <ChevronRight className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </span>
            </div>

            {/* Following Count */}
            <div
              onClick={() => openFollowListModal('following')}
              className="flex flex-col items-center justify-center p-2.5 sm:p-3.5 rounded-2xl bg-slate-50/80 hover:bg-slate-100/70 border border-slate-200/70 hover:border-slate-300 transition-all cursor-pointer group"
            >
              <span className="text-base sm:text-xl font-black text-slate-900 group-hover:text-orange-600 transition-colors">
                {followingCount}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase tracking-wider mt-0.5 flex items-center gap-1">
                <span>Following</span>
                <ChevronRight className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </span>
            </div>

            {/* Creator Rank */}
            <div
              className="flex flex-col items-center justify-center p-2.5 sm:p-3.5 rounded-2xl bg-slate-50/80 border border-slate-200/70 hover:bg-amber-50/40 hover:border-amber-200 transition-all cursor-default group"
              title={`Creator Rank #${profileUser.creatorRank ?? 1} on BLUEJO`}
            >
              <div className="flex items-center gap-1 sm:gap-1.5">
                <Trophy className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500 fill-amber-500/20 group-hover:scale-110 transition-transform" />
                <span className="text-base sm:text-xl font-black text-slate-900 tracking-tight">
                  #{profileUser.creatorRank ?? 1}
                </span>
              </div>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase tracking-wider mt-0.5 text-center">
                Creator Rank
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content Navigation Segmented Ribbon */}
      <div className="flex items-center justify-center gap-2 mb-6">
        <div className="flex items-center p-1 bg-slate-200/70 rounded-2xl border border-slate-300/40 backdrop-blur-xs max-w-md w-full justify-between">
          <button
            onClick={() => setActiveTab('posts')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'posts'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Grid3X3 className="w-3.5 h-3.5" />
            <span>Posts</span>
            <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-500">
              {posts.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('reels')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'reels'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Reels</span>
            <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-500">
              {reels.length}
            </span>
          </button>

          {isMe && (
            <button
              onClick={() => setActiveTab('saved')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'saved'
                  ? 'bg-white text-orange-600 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>Saved</span>
              <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-500">
                {savedPosts.length}
              </span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('about')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'about'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>About</span>
          </button>
        </div>
      </div>

      {/* Private Profile Lockdown State */}
      {isPrivateHidden ? (
        <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center shadow-sm max-w-lg mx-auto my-6">
          <div className="w-16 h-16 rounded-full bg-orange-50 border border-orange-200 text-orange-600 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-1">
            This BLUEJO Account is Private
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed mb-6">
            Follow @{profileUser.username} to see their published stories, photos, and creative clips.
          </p>
          <button
            onClick={handleToggleFollow}
            disabled={isFollowActionLoading}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 text-white font-bold text-xs shadow-md shadow-orange-600/20 hover:from-orange-700 hover:to-amber-700 transition-all cursor-pointer"
          >
            {isFollowPending ? 'Follow Request Pending' : 'Request to Follow'}
          </button>
        </div>
      ) : (
        /* Tab Content Panels */
        <>
          {/* TAB 1: POSTS */}
          {activeTab === 'posts' && (
            <div>
              {posts.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-md mx-auto">
                  <div className="w-16 h-16 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center mx-auto mb-3 border border-orange-100">
                    <Grid3X3 className="w-7 h-7" />
                  </div>
                  <h3 className="font-bold text-sm text-slate-800 mb-1">No Posts Yet</h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    {isMe
                      ? 'Share your first photo or thought with India’s vibrant community!'
                      : `@${profileUser.username} hasn't shared any posts yet.`}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
                  {posts.map((post) => (
                    <div
                      key={post._id}
                      onClick={() => onNavigateToPost(post._id)}
                      className="group relative aspect-square bg-slate-100 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer border border-slate-200/80 shadow-xs transition-all hover:shadow-md"
                    >
                      <img
                        src={post.mediaUrl}
                        alt={post.caption || 'BLUEJO Post'}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />

                      {/* Location Chip Badge on Post Card */}
                      {post.location && (
                        <div className="absolute top-2 left-2 z-10 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-white text-[10px] font-medium flex items-center gap-1">
                          <MapPin className="w-2.5 h-2.5 text-orange-400" />
                          <span className="truncate max-w-[90px]">{post.location.split(',')[0]}</span>
                        </div>
                      )}

                      {/* Interactive Hover Overlay with Likes and Comments */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col justify-end p-3 text-white">
                        <p className="text-xs font-medium line-clamp-2 mb-2 drop-shadow-sm">
                          {post.caption || 'View post details'}
                        </p>
                        <div className="flex items-center gap-4 text-xs font-bold">
                          <span className="flex items-center gap-1.5">
                            <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
                            {post.likesCount || 0}
                          </span>
                          <span className="flex items-center gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5 fill-white text-white" />
                            {post.commentsCount || 0}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: REELS & VIDEOS */}
          {activeTab === 'reels' && (
            <div>
              {reels.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-md mx-auto">
                  <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3 border border-amber-100">
                    <Film className="w-7 h-7" />
                  </div>
                  <h3 className="font-bold text-sm text-slate-800 mb-1">No Reels Yet</h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    {isMe
                      ? 'Upload short creative videos, clips, or stories to BLUEJO Reels.'
                      : `@${profileUser.username} hasn't published any reels yet.`}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
                  {reels.map((reel) => (
                    <div
                      key={reel._id}
                      onClick={() => onNavigateToPost(reel._id)}
                      className="group relative aspect-[9/16] bg-slate-950 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer border border-slate-800 shadow-md"
                    >
                      <video
                        src={reel.videoUrl}
                        preload="metadata"
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />

                      {/* Top Reel indicator */}
                      <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1">
                        <Film className="w-3 h-3 text-orange-400" />
                        <span>Reel</span>
                      </div>

                      {/* Audio track tag */}
                      {reel.audioTitle && (
                        <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-white text-[9px] font-medium flex items-center gap-1 max-w-[110px] truncate">
                          <Music2 className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                          <span className="truncate">{reel.audioTitle}</span>
                        </div>
                      )}

                      {/* Bottom caption & metrics */}
                      <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-3 text-white">
                        <p className="text-[11px] font-medium line-clamp-2 mb-1.5 drop-shadow-sm">
                          {reel.caption}
                        </p>
                        <div className="flex items-center justify-between text-[10px] font-bold text-slate-300">
                          <span className="flex items-center gap-1">
                            <Heart className="w-3 h-3 fill-rose-500 text-rose-500" />
                            {reel.likesCount || 0}
                          </span>
                          <span className="flex items-center gap-1 text-slate-300">
                            <Eye className="w-3 h-3 text-white" />
                            {reel.viewsCount || 108}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SAVED CONTENT (Account Owner Only) */}
          {activeTab === 'saved' && isMe && (
            <div>
              <div className="p-3 bg-amber-50/80 border border-amber-200/80 rounded-2xl mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-900">
                  <Lock className="w-3.5 h-3.5 text-amber-600" />
                  <span>Private Bookmarks — Only you can see what you have saved</span>
                </div>
                <span className="text-[11px] font-bold text-amber-800">{savedPosts.length} items</span>
              </div>

              {savedPosts.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-md mx-auto">
                  <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3 border border-amber-100">
                    <Bookmark className="w-7 h-7" />
                  </div>
                  <h3 className="font-bold text-sm text-slate-800 mb-1">No Saved Posts</h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Save posts you want to revisit anytime by tapping the bookmark icon under any post.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
                  {savedPosts.map((post) => (
                    <div
                      key={post._id}
                      onClick={() => onNavigateToPost(post._id)}
                      className="group relative aspect-square bg-slate-100 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer border border-slate-200/80 shadow-xs hover:shadow-md transition-all"
                    >
                      <img
                        src={post.mediaUrl}
                        alt={post.caption || 'Saved post'}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute top-2 right-2 p-1.5 rounded-full bg-black/60 text-white backdrop-blur-md">
                        <Bookmark className="w-3 h-3 fill-white" />
                      </div>
                      <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-3 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                        <p className="text-[11px] font-medium line-clamp-2">{post.caption}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ABOUT & COMMUNITY */}
          {activeTab === 'about' && (
            <div className="max-w-2xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-orange-600" />
                  About This Creator
                </h3>
                <div className="space-y-3 divide-y divide-slate-100 text-xs">
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Username Handle</span>
                    <span className="font-bold text-slate-900">@{profileUser.username}</span>
                  </div>
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Full Name</span>
                    <span className="font-bold text-slate-900">{profileUser.name}</span>
                  </div>
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Verification Status</span>
                    <span className="inline-flex items-center gap-1 font-bold text-emerald-600">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Verified Citizen 🇮🇳
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Account Privacy</span>
                    <span className="font-bold text-slate-900">
                      {profileUser.isPrivate ? 'Private Account' : 'Public Account'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Native Location</span>
                    <span className="font-bold text-slate-900">
                      {profileUser.location || 'India'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Joined BLUEJO</span>
                    <span className="font-bold text-slate-900">{joinedDateText}</span>
                  </div>
                  <div className="flex justify-between items-center py-2.5">
                    <span className="text-slate-500 font-medium">Creator Standing</span>
                    <span className="inline-flex items-center gap-1.5 font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                      <Trophy className="w-3.5 h-3.5 text-amber-600" />
                      Rank #{profileUser.creatorRank ?? 1}
                    </span>
                  </div>
                </div>
              </div>

              {/* Creator badges */}
              <div className="p-4 rounded-2xl bg-orange-50/60 border border-orange-200/70">
                <div className="text-xs font-bold text-orange-950 mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-orange-600" />
                  Pioneer Community Badges
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-blue-200 text-blue-900 font-bold text-[11px] shadow-2xs">
                    ✨ BLUEJO Creator
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-orange-200 text-orange-900 font-bold text-[11px] shadow-2xs">
                    🌟 Early Adopter
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-orange-200 text-orange-900 font-bold text-[11px] shadow-2xs">
                    🤝 Verified Identity
                  </span>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Followers / Following List Modal */}
      {followModalType && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in zoom-in-95 p-5">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => openFollowListModal('followers')}
                  className={`text-xs sm:text-sm font-black capitalize transition-colors pb-1 border-b-2 cursor-pointer ${
                    followModalType === 'followers'
                      ? 'border-orange-600 text-orange-600'
                      : 'border-transparent text-slate-400 hover:text-slate-700'
                  }`}
                >
                  Followers ({followersCount})
                </button>
                <button
                  onClick={() => openFollowListModal('following')}
                  className={`text-xs sm:text-sm font-black capitalize transition-colors pb-1 border-b-2 cursor-pointer ${
                    followModalType === 'following'
                      ? 'border-orange-600 text-orange-600'
                      : 'border-transparent text-slate-400 hover:text-slate-700'
                  }`}
                >
                  Following ({followingCount})
                </button>
              </div>

              <button
                onClick={() => setFollowModalType(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search filter within list */}
            <div className="mt-3 relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={`Search ${followModalType}...`}
                value={followSearchQuery}
                onChange={(e) => setFollowSearchQuery(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-2 outline-hidden focus:border-orange-500 focus:bg-white transition-all"
              />
            </div>

            {/* Users List */}
            <div className="max-h-80 overflow-y-auto mt-3 divide-y divide-slate-100 pr-1">
              {isLoadingFollowList ? (
                <div className="py-12 flex flex-col items-center justify-center gap-2 text-xs text-slate-400">
                  <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  <span>Loading BLUEJO creators...</span>
                </div>
              ) : filteredFollowUsers.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  {followSearchQuery ? 'No matching users found.' : `No ${followModalType} yet.`}
                </div>
              ) : (
                filteredFollowUsers.map((u) => (
                  <div
                    key={u._id}
                    className="flex items-center justify-between gap-3 py-2.5 px-2 hover:bg-slate-50 rounded-xl transition-colors"
                  >
                    <div
                      onClick={() => {
                        setFollowModalType(null);
                        onNavigateToUser(u.username);
                      }}
                      className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                    >
                      <img
                        src={u.profilePhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                        alt={u.name}
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-slate-900 truncate flex items-center gap-1">
                          <span>{u.name}</span>
                          {u.isVerified && <VerifiedBadge size="sm" />}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">@{u.username}</div>
                      </div>
                    </div>

                    {/* Quick profile button */}
                    <button
                      onClick={() => {
                        setFollowModalType(null);
                        onNavigateToUser(u.username);
                      }}
                      className="px-3 py-1 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-orange-50 hover:text-orange-700 text-slate-700 transition-colors shrink-0 cursor-pointer"
                    >
                      View
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
