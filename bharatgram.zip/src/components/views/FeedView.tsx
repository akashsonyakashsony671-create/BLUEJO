import React, { useState, useEffect } from 'react';
import { Post, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { StoriesBar } from '../feed/StoriesBar';
import { PostCard } from '../feed/PostCard';
import { VerifiedBadge } from '../common/Badge';
import { Sparkles, TrendingUp, UserPlus, UserCheck, RefreshCw } from 'lucide-react';

interface FeedViewProps {
  onOpenStory: (groupIndex: number) => void;
  onAddStory: () => void;
  onOpenComments: (post: Post) => void;
  onOpenShare: (post: Post) => void;
  onOpenReport: (targetId: string, targetType: 'post') => void;
  onNavigateToUser: (username: string) => void;
  onNavigateToHashtag: (tag: string) => void;
  refreshTrigger: number;
}

export const FeedView: React.FC<FeedViewProps> = ({
  onOpenStory,
  onAddStory,
  onOpenComments,
  onOpenShare,
  onOpenReport,
  onNavigateToUser,
  onNavigateToHashtag,
  refreshTrigger
}) => {
  const { user, token } = useAuth();
  const { t } = useLanguage();

  const [posts, setPosts] = useState<Post[]>([]);
  const [suggestedUsers, setSuggestedUsers] = useState<User[]>([]);
  const [trendingTags, setTrendingTags] = useState<{ tag: string; count: number }[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchFeed = async () => {
    try {
      const headers: any = {};
      if (token) headers.Authorization = `Bearer ${token}`;

      const [postsRes, usersRes, tagsRes] = await Promise.all([
        fetch('/api/posts', { headers }),
        fetch('/api/users/suggested', { headers }),
        fetch('/api/search/trending-hashtags')
      ]);

      const postsData = await postsRes.json();
      const usersData = await usersRes.json();
      const tagsData = await tagsRes.json();

      if (postsData.success) setPosts(postsData.posts || []);
      if (usersData.success) setSuggestedUsers(usersData.users || []);
      if (tagsData.success) setTrendingTags(tagsData.trending || []);
    } catch (err) {
      console.error('Failed to load feed:', err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchFeed();
  }, [token, refreshTrigger]);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    fetchFeed();
  };

  const handlePostDeleted = (deletedPostId: string) => {
    setPosts(prev => prev.filter(p => p._id !== deletedPostId));
  };

  const handleToggleFollowSuggested = async (suggestedUser: User) => {
    if (!token) return;

    setSuggestedUsers(prev =>
      prev.map(u => {
        if (u._id === suggestedUser._id) {
          const next = !u.isFollowing;
          return {
            ...u,
            isFollowing: next,
            followersCount: next ? u.followersCount + 1 : Math.max(0, u.followersCount - 1)
          };
        }
        return u;
      })
    );

    try {
      await fetch(`/api/users/${suggestedUser.username}/follow`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (err) {
      console.error('Follow error:', err);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto py-4 px-2 sm:px-4 flex items-start gap-8 justify-center">
      {/* Central Main Feed Column */}
      <div className="w-full max-w-xl flex-1 min-w-0">
        {/* Stories Horizontal Bar */}
        <StoriesBar
          onOpenStory={onOpenStory}
          onAddStory={onAddStory}
          refreshTrigger={refreshTrigger}
        />

        {/* Refresh Feed Bar */}
        <div className="flex items-center justify-between px-2 mb-3 text-xs text-slate-500">
          <span className="font-semibold text-slate-700">Latest from India 🇮🇳</span>
          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-1 hover:text-orange-600 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-orange-600' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

        {/* Posts Feed */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-9 h-9 border-3 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-500 font-semibold">Connecting to BLUEJO...</p>
          </div>
        ) : posts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center shadow-xs">
            <Sparkles className="w-10 h-10 text-blue-500 mx-auto mb-2" />
            <h3 className="font-bold text-sm text-slate-800">{t('noPostsYet')}</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Follow more creators or be the first to share a moment with the community!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <PostCard
                key={post._id}
                post={post}
                onOpenComments={onOpenComments}
                onOpenShare={onOpenShare}
                onOpenReport={onOpenReport}
                onNavigateToUser={onNavigateToUser}
                onNavigateToHashtag={onNavigateToHashtag}
                onPostDeleted={handlePostDeleted}
              />
            ))}
          </div>
        )}
      </div>

      {/* Right Desktop Suggestions Column */}
      <div className="hidden lg:block w-80 sticky top-[77px] space-y-5 flex-shrink-0">
        {/* Suggested Creators */}
        {suggestedUsers.length > 0 && (
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-800">{t('suggestedForYou')}</span>
            </div>

            <div className="space-y-3">
              {suggestedUsers.slice(0, 5).map((sUser) => (
                <div key={sUser._id} className="flex items-center justify-between gap-2.5">
                  <div
                    onClick={() => onNavigateToUser(sUser.username)}
                    className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
                  >
                    <img
                      src={sUser.profilePhoto}
                      alt={sUser.username}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-full object-cover border border-slate-200"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="font-bold text-xs text-slate-900 truncate group-hover:text-orange-600 transition-colors">
                          {sUser.name}
                        </span>
                        {sUser.isVerified && <VerifiedBadge size="sm" />}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">@{sUser.username}</div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleToggleFollowSuggested(sUser)}
                    className={`text-xs font-bold px-3 py-1 rounded-full transition-colors flex-shrink-0 ${
                      sUser.isFollowing
                        ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        : 'bg-orange-600 hover:bg-orange-700 text-white shadow-2xs'
                    }`}
                  >
                    {sUser.isFollowing ? 'Following' : 'Follow'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Trending in India */}
        {trendingTags.length > 0 && (
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 mb-3">
              <TrendingUp className="w-4 h-4 text-orange-600" />
              <span>{t('trendingInIndia')}</span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {trendingTags.slice(0, 8).map((tag) => (
                <button
                  key={tag.tag}
                  onClick={() => onNavigateToHashtag(tag.tag)}
                  className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-orange-50 text-slate-700 hover:text-orange-600 text-xs font-medium border border-transparent hover:border-orange-200 transition-all"
                >
                  #{tag.tag}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="px-2 text-[11px] text-slate-400 leading-relaxed">
          <p>© 2026 BLUEJO • Connect • Create • Share</p>
          <p className="mt-1">Privacy • Safety • Community Guidelines</p>
        </div>
      </div>
    </div>
  );
};
