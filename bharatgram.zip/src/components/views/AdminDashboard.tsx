import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ReportItem, User } from '../../types';
import { VerifiedBadge } from '../common/Badge';
import {
  ShieldAlert,
  Shield,
  Users,
  Image,
  Film,
  AlertTriangle,
  Trash2,
  CheckCircle,
  Ban,
  BadgeCheck,
  Search
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { user, token } = useAuth();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalPosts: 0,
    totalReels: 0,
    totalStories: 0,
    totalReports: 0,
    pendingReports: 0
  });
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [userFilter, setUserFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'reports' | 'users'>('reports');

  const fetchAdminData = async () => {
    if (!token) return;
    try {
      const [statsRes, reportsRes, usersRes] = await Promise.all([
        fetch('/api/admin/stats', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/reports', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/users', { headers: { Authorization: `Bearer ${token}` } })
      ]);

      const statsData = await statsRes.json();
      const reportsData = await reportsRes.json();
      const usersData = await usersRes.json();

      if (statsData.success) setStats(statsData.stats);
      if (reportsData.success) setReports(reportsData.reports);
      if (usersData.success) setUsers(usersData.users);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token]);

  const handleResolveReport = async (reportId: string, action: 'dismiss' | 'delete_content' | 'suspend_user') => {
    if (!token) return;
    if (!confirm(`Are you sure you want to perform "${action}"?`)) return;

    try {
      const res = await fetch(`/api/admin/reports/${reportId}/resolve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ action })
      });
      const data = await res.json();
      if (data.success) {
        fetchAdminData();
      }
    } catch (err) {
      console.error('Failed to resolve report:', err);
    }
  };

  const handleToggleVerified = async (targetUserId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/users/${targetUserId}/toggle-verified`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setUsers(prev =>
          prev.map(u => (u._id === targetUserId ? { ...u, isVerified: data.isVerified } : u))
        );
      }
    } catch (err) {
      console.error('Failed to toggle verified:', err);
    }
  };

  const handleToggleSuspend = async (targetUserId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/users/${targetUserId}/toggle-suspend`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setUsers(prev =>
          prev.map(u => (u._id === targetUserId ? { ...u, isSuspended: data.isSuspended } : u))
        );
      }
    } catch (err) {
      console.error('Failed to toggle suspend:', err);
    }
  };

  if (!user?.isAdmin) {
    return (
      <div className="py-24 text-center text-slate-500">
        <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto mb-2" />
        <h3 className="font-bold text-sm text-slate-800">Admin Access Required</h3>
        <p className="text-xs text-slate-400 mt-1">
          Sign in with an administrator account (e.g. @bluejo) to access the moderation panel.
        </p>
      </div>
    );
  }

  const filteredUsers = users.filter(
    u =>
      u.name.toLowerCase().includes(userFilter.toLowerCase()) ||
      u.username.toLowerCase().includes(userFilter.toLowerCase())
  );

  return (
    <div className="w-full max-w-5xl mx-auto py-6 px-3 sm:px-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-wide text-slate-900 leading-tight uppercase">
              BLUEJO Administration & Moderation
            </h1>
            <p className="text-xs text-slate-500 font-medium">Platform Health & Safety Center</p>
          </div>
        </div>

        <button
          onClick={fetchAdminData}
          className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600"
        >
          Refresh Data
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center gap-3">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900">{stats.totalUsers}</div>
            <div className="text-xs text-slate-500 font-medium">Total Creators</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center gap-3">
          <div className="p-3 bg-amber-100 text-amber-600 rounded-xl">
            <Image className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900">{stats.totalPosts}</div>
            <div className="text-xs text-slate-500 font-medium">Feed Posts</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center gap-3">
          <div className="p-3 bg-purple-100 text-purple-600 rounded-xl">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900">{stats.totalReels}</div>
            <div className="text-xs text-slate-500 font-medium">Reels Published</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center gap-3">
          <div className="p-3 bg-rose-100 text-rose-600 rounded-xl">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900">{stats.pendingReports}</div>
            <div className="text-xs text-slate-500 font-medium">Pending Reports</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 mb-5">
        <button
          onClick={() => setActiveTab('reports')}
          className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'reports'
              ? 'border-orange-600 text-orange-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Moderation Queue ({reports.filter(r => r.status === 'pending').length})
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'users'
              ? 'border-orange-600 text-orange-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Manage Creators ({users.length})
        </button>
      </div>

      {/* Tab: Reports */}
      {activeTab === 'reports' ? (
        reports.length === 0 ? (
          <div className="py-16 text-center bg-white border border-slate-200 rounded-3xl p-6">
            <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
            <h4 className="font-bold text-sm text-slate-800">All Clear!</h4>
            <p className="text-xs text-slate-400 mt-1">No pending reports in the moderation queue.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {reports.map((report) => (
              <div
                key={report._id}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-100 text-rose-700">
                      {report.targetType}
                    </span>
                    <span className="font-bold text-xs text-slate-900">{report.reason}</span>
                    <span className="text-[11px] text-slate-400">
                      • {new Date(report.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  {report.details && (
                    <p className="text-xs text-slate-600 italic">"{report.details}"</p>
                  )}

                  <div className="text-[11px] text-slate-500">
                    Reported by: <span className="font-semibold">{report.reporter?.username || 'user'}</span>
                    {' • '}
                    Target ID: <span className="font-mono text-[10px]">{report.targetId}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                  <button
                    onClick={() => handleResolveReport(report._id, 'dismiss')}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-600 transition-colors"
                  >
                    Dismiss
                  </button>

                  <button
                    onClick={() => handleResolveReport(report._id, 'delete_content')}
                    className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Content</span>
                  </button>

                  <button
                    onClick={() => handleResolveReport(report._id, 'suspend_user')}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>Suspend User</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* Tab: Users Management */
        <div className="space-y-4">
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-2xl px-4 py-2.5">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search creators by name or username..."
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
              className="w-full text-xs bg-transparent outline-hidden"
            />
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100 overflow-hidden">
            {filteredUsers.map((u) => (
              <div key={u._id} className="p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={u.profilePhoto}
                    alt={u.username}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-slate-200"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-xs text-slate-900 truncate">{u.name}</span>
                      {u.isVerified && <VerifiedBadge size="sm" />}
                      {u.isSuspended && (
                        <span className="text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.2 rounded-md font-bold">
                          SUSPENDED
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate">
                      @{u.username} • {u.followersCount} followers • {u.email}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => handleToggleVerified(u._id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                      u.isVerified
                        ? 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                        : 'border border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <BadgeCheck className="w-3.5 h-3.5" />
                    <span>{u.isVerified ? 'Verified' : 'Verify'}</span>
                  </button>

                  <button
                    onClick={() => handleToggleSuspend(u._id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                      u.isSuspended
                        ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                        : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                    }`}
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>{u.isSuspended ? 'Unban' : 'Suspend'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
