import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../i18n/languages';
import {
  Settings,
  Shield,
  Globe,
  Lock,
  UserX,
  Key,
  LogOut,
  Check
} from 'lucide-react';

interface SettingsViewProps {
  onLogout: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onLogout }) => {
  const { user, updateUser, token, logoutAllDevices } = useAuth();
  const { currentLanguage, setLanguage, t, languages } = useLanguage();

  const [isPrivate, setIsPrivate] = useState(user?.isPrivate || false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState<{ text: string; isError: boolean } | null>(null);
  const [isUpdatingPrivacy, setIsUpdatingPrivacy] = useState(false);
  const [isLoggingOutAll, setIsLoggingOutAll] = useState(false);
  const [sessionMsg, setSessionMsg] = useState<string>('');

  const handleTogglePrivacy = async () => {
    const nextVal = !isPrivate;
    setIsPrivate(nextVal);
    setIsUpdatingPrivacy(true);
    await updateUser({ isPrivate: nextVal });
    setIsUpdatingPrivacy(false);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oldPassword || !newPassword || !token) {
      setPasswordMsg({ text: 'Please fill in both password fields', isError: true });
      return;
    }

    try {
      const res = await fetch('/api/users/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ oldPassword, newPassword })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setPasswordMsg({ text: 'Password updated successfully!', isError: false });
        setOldPassword('');
        setNewPassword('');
      } else {
        setPasswordMsg({ text: data.error || 'Failed to update password', isError: true });
      }
    } catch (err: any) {
      setPasswordMsg({ text: err.message || 'Error occurred', isError: true });
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto py-6 px-3 sm:px-6">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="w-6 h-6 text-orange-600" />
        <h2 className="text-xl font-bold text-slate-900">{t('settings')}</h2>
      </div>

      <div className="space-y-6">
        {/* Account Privacy */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-orange-100 text-orange-600">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">{t('accountPrivacy')}</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  When enabled, only approved followers can see your photos, reels, and stories.
                </p>
              </div>
            </div>

            <button
              onClick={handleTogglePrivacy}
              disabled={isUpdatingPrivacy}
              className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors duration-200 cursor-pointer ${
                isPrivate ? 'bg-orange-600 justify-end' : 'bg-slate-200 justify-start'
              }`}
            >
              <div className="bg-white w-4 h-4 rounded-full shadow-md" />
            </button>
          </div>
        </div>

        {/* Indian Language Selector */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-amber-100 text-amber-600">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">App Language (भाषा)</h3>
              <p className="text-xs text-slate-500">
                Choose your preferred Indian regional language interface
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`flex items-center justify-between p-3 rounded-2xl border text-xs font-semibold transition-all ${
                  currentLanguage === lang.code
                    ? 'border-orange-500 bg-orange-50 text-orange-700 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span>{lang.nativeLabel}</span>
                {currentLanguage === lang.code && <Check className="w-4 h-4 text-orange-600" />}
              </button>
            ))}
          </div>
        </div>

        {/* Change Password */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-blue-100 text-blue-600">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Change Password</h3>
              <p className="text-xs text-slate-500">Secure your BLUEJO account</p>
            </div>
          </div>

          {passwordMsg && (
            <div
              className={`p-3 rounded-xl text-xs font-medium mb-3 ${
                passwordMsg.isError
                  ? 'bg-rose-50 border border-rose-200 text-rose-700'
                  : 'bg-emerald-50 border border-emerald-200 text-emerald-700'
              }`}
            >
              {passwordMsg.text}
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Current Password
              </label>
              <input
                type="password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-hidden focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                New Password
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-hidden focus:border-blue-500"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              Update Password
            </button>
          </form>
        </div>

        {/* Sessions & Logout Controls */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 rounded-2xl bg-slate-100 text-slate-700">
              <Shield className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Account Security & Sessions</h3>
              <p className="text-xs text-slate-500">Manage active BLUEJO login sessions across all your devices</p>
            </div>
          </div>

          {sessionMsg && (
            <div className="p-3 bg-blue-50 border border-blue-200 text-blue-800 text-xs rounded-xl font-medium">
              {sessionMsg}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
            {/* Regular Single-device Logout */}
            <button
              id="settings-logout-btn"
              type="button"
              onClick={onLogout}
              className="w-full py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4 text-slate-500" />
              <span>Log Out Current Session</span>
            </button>

            {/* Logout From All Devices */}
            <button
              id="settings-logout-all-btn"
              type="button"
              disabled={isLoggingOutAll}
              onClick={async () => {
                if (window.confirm('Are you sure you want to log out from all devices? This will revoke active sessions on all phones, tablets, and computers.')) {
                  setIsLoggingOutAll(true);
                  const res = await logoutAllDevices();
                  setIsLoggingOutAll(false);
                  if (res.success) {
                    setSessionMsg('Logged out from all devices successfully.');
                    setTimeout(() => {
                      onLogout();
                    }, 1000);
                  }
                }
              }}
              className="w-full py-3 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200/80 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-60"
            >
              <LogOut className="w-4 h-4 text-rose-600" />
              <span>{isLoggingOutAll ? 'Revoking sessions...' : 'Log Out from All Devices'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
