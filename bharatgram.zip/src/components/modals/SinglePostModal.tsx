import React, { useState, useEffect } from 'react';
import { Post } from '../../types';
import { PostCard } from '../feed/PostCard';
import { X } from 'lucide-react';

interface SinglePostModalProps {
  postId: string;
  onClose: () => void;
  onOpenComments: (post: Post) => void;
  onOpenShare: (post: Post) => void;
  onOpenReport: (targetId: string, targetType: 'post') => void;
  onNavigateToUser: (username: string) => void;
  onNavigateToHashtag: (tag: string) => void;
}

export const SinglePostModal: React.FC<SinglePostModalProps> = ({
  postId,
  onClose,
  onOpenComments,
  onOpenShare,
  onOpenReport,
  onNavigateToUser,
  onNavigateToHashtag
}) => {
  const [post, setPost] = useState<Post | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/posts/${postId}`)
      .then(res => res.json())
      .then(data => {
        if (data.success && data.post) setPost(data.post);
      })
      .catch(console.error)
      .finally(() => setIsLoading(false));
  }, [postId]);

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto select-none">
      <div className="relative w-full max-w-lg my-auto">
        <button
          onClick={onClose}
          className="absolute -top-10 right-0 p-2 text-white/80 hover:text-white rounded-full bg-white/10 hover:bg-white/20 transition-all cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>

        {isLoading ? (
          <div className="bg-white rounded-3xl p-12 flex items-center justify-center shadow-2xl">
            <div className="w-8 h-8 border-3 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : post ? (
          <div className="animate-in zoom-in-95 duration-150">
            <PostCard
              post={post}
              onOpenComments={onOpenComments}
              onOpenShare={onOpenShare}
              onOpenReport={onOpenReport}
              onNavigateToUser={(u) => {
                onClose();
                onNavigateToUser(u);
              }}
              onNavigateToHashtag={(t) => {
                onClose();
                onNavigateToHashtag(t);
              }}
              onPostDeleted={() => onClose()}
            />
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-8 text-center text-slate-500 shadow-2xl">
            Post not found or has been deleted.
          </div>
        )}
      </div>
    </div>
  );
};
