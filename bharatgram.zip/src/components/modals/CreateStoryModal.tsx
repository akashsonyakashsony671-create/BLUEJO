import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { X, Upload, Clock } from 'lucide-react';

interface CreateStoryModalProps {
  onClose: () => void;
  onStoryCreated: () => void;
}

export const CreateStoryModal: React.FC<CreateStoryModalProps> = ({
  onClose,
  onStoryCreated
}) => {
  const { token } = useAuth();
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [caption, setCaption] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setMediaFile(file);
      setMediaType(file.type.startsWith('video') ? 'video' : 'image');
      setMediaPreview(URL.createObjectURL(file));
      setErrorMsg('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaFile || !token) {
      setErrorMsg('Please select a photo or video for your story');
      return;
    }

    setIsUploading(true);
    setErrorMsg('');

    try {
      const formData = new FormData();
      formData.append('media', mediaFile);
      formData.append('caption', caption);

      const res = await fetch('/api/stories', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to publish story');
      }

      onStoryCreated();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to upload story');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 select-none">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-1.5 font-bold text-sm text-slate-900">
            <span>Add to BLUEJO Story</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
              {errorMsg}
            </div>
          )}

          <div
            onClick={() => fileInputRef.current?.click()}
            className="relative w-full h-72 rounded-2xl border-2 border-dashed border-slate-300 hover:border-orange-500 bg-slate-50 flex items-center justify-center cursor-pointer overflow-hidden"
          >
            {mediaPreview ? (
              mediaType === 'video' ? (
                <video src={mediaPreview} controls className="w-full h-full object-contain bg-black" />
              ) : (
                <img src={mediaPreview} alt="Story Preview" className="w-full h-full object-cover" />
              )
            ) : (
              <div className="flex flex-col items-center text-center p-4">
                <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mb-2">
                  <Upload className="w-6 h-6" />
                </div>
                <div className="text-xs font-bold text-slate-800">Select Photo or Short Video</div>
                <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-orange-500" />
                  <span>Visible to followers for 24 hours</span>
                </div>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>

          <div>
            <input
              type="text"
              placeholder="Add optional story text overlay..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 outline-hidden focus:border-orange-500"
            />
          </div>

          <button
            type="submit"
            disabled={isUploading || !mediaFile}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-600 to-amber-600 text-white text-xs font-bold shadow-md shadow-orange-600/20 disabled:opacity-50 transition-all cursor-pointer"
          >
            {isUploading ? 'Posting Story...' : 'Share to Story (24 hrs)'}
          </button>
        </form>
      </div>
    </div>
  );
};
