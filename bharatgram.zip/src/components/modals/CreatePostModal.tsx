import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import {
  X,
  Upload,
  Image as ImageIcon,
  Film,
  MapPin,
  Lock,
  Globe,
  Sparkles,
  Music
} from 'lucide-react';

interface CreatePostModalProps {
  onClose: () => void;
  onPostCreated: () => void;
}

const POPULAR_INDIAN_TAGS = [
  'IncredibleIndia',
  'TechIndia',
  'CricketFever',
  'IndianFood',
  'Delhi',
  'Mumbai',
  'Bengaluru',
  'FestivalsOfIndia',
  'Startups'
];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  onClose,
  onPostCreated
}) => {
  const { user, token } = useAuth();
  const { t } = useLanguage();

  const [contentType, setContentType] = useState<'post' | 'reel'>('post');
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string>('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [caption, setCaption] = useState('');
  const [location, setLocation] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'private'>('public');
  const [audioTrack, setAudioTrack] = useState('Original Audio - Indian Creators');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setMediaFile(file);

      const isVid = file.type.startsWith('video');
      setMediaType(isVid ? 'video' : 'image');
      if (isVid && contentType === 'post') {
        // Can be post or reel
      }
      setMediaPreview(URL.createObjectURL(file));
      setErrorMsg('');
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setMediaFile(file);
      const isVid = file.type.startsWith('video');
      setMediaType(isVid ? 'video' : 'image');
      setMediaPreview(URL.createObjectURL(file));
      setErrorMsg('');
    }
  };

  const handleAddHashtag = (tag: string) => {
    if (!caption.includes(`#${tag}`)) {
      setCaption(prev => (prev ? `${prev} #${tag}` : `#${tag}`));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaFile || !token) {
      setErrorMsg('Please select a photo or video to upload');
      return;
    }

    setIsUploading(true);
    setErrorMsg('');

    try {
      const formData = new FormData();
      formData.append('media', mediaFile);
      formData.append('caption', caption);
      formData.append('location', location);
      formData.append('visibility', visibility);

      if (contentType === 'reel') {
        formData.append('audioTrack', audioTrack);
      }

      const endpoint = contentType === 'reel' ? '/api/reels' : '/api/posts';

      // Simulate upload progress
      const progressTimer = setInterval(() => {
        setUploadProgress(prev => Math.min(90, prev + 15));
      }, 150);

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        },
        body: formData
      });

      clearInterval(progressTimer);
      setUploadProgress(100);

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to create content');
      }

      onPostCreated();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto animate-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setContentType('post')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                contentType === 'post'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Feed Post
            </button>
            <button
              type="button"
              onClick={() => setContentType('reel')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                contentType === 'reel'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              9:16 Reel
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-medium">
              {errorMsg}
            </div>
          )}

          {/* Media Picker / Drag Drop Box */}
          <div
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className={`relative w-full ${
              contentType === 'reel' ? 'h-64' : 'h-56'
            } rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-colors overflow-hidden ${
              mediaPreview
                ? 'border-transparent bg-slate-900'
                : 'border-slate-300 hover:border-orange-500 bg-slate-50'
            }`}
          >
            {mediaPreview ? (
              mediaType === 'video' ? (
                <video
                  src={mediaPreview}
                  controls
                  className="w-full h-full object-contain"
                />
              ) : (
                <img
                  src={mediaPreview}
                  alt="Preview"
                  className="w-full h-full object-contain"
                />
              )
            ) : (
              <div className="flex flex-col items-center text-center p-4">
                <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mb-2">
                  <Upload className="w-6 h-6" />
                </div>
                <div className="text-xs font-bold text-slate-800">
                  {t('uploadPhotoOrVideo')}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Supports JPG, PNG, WEBP, MP4, MOV
                </div>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>

          {/* Caption Input */}
          <div>
            <textarea
              placeholder={t('captionPlaceholder')}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              rows={3}
              className="w-full text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-2xl p-3 focus:outline-hidden focus:border-orange-500 transition-colors resize-none"
            />
          </div>

          {/* Indian Hashtag Suggestions */}
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-orange-500" />
              <span>Trending Indian Hashtags</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {POPULAR_INDIAN_TAGS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleAddHashtag(tag)}
                  className="text-[11px] px-2.5 py-1 rounded-full bg-slate-100 hover:bg-orange-100 text-slate-700 hover:text-orange-700 transition-colors font-medium"
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>

          {/* Location Field */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-2">
            <MapPin className="w-4 h-4 text-orange-600 flex-shrink-0" />
            <input
              type="text"
              placeholder={t('locationPlaceholder')}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full text-xs bg-transparent outline-hidden"
            />
          </div>

          {/* Reel Audio Track (if reel) */}
          {contentType === 'reel' && (
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl px-3 py-2">
              <Music className="w-4 h-4 text-orange-600 flex-shrink-0" />
              <input
                type="text"
                placeholder="Audio Track (e.g. Desi Beat - New Delhi)"
                value={audioTrack}
                onChange={(e) => setAudioTrack(e.target.value)}
                className="w-full text-xs bg-transparent outline-hidden"
              />
            </div>
          )}

          {/* Visibility */}
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-semibold text-slate-700">Visibility</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setVisibility('public')}
                className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${
                  visibility === 'public'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Globe className="w-3 h-3" />
                Public
              </button>
              <button
                type="button"
                onClick={() => setVisibility('private')}
                className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${
                  visibility === 'private'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Lock className="w-3 h-3" />
                Followers Only
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          {isUploading && (
            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
              <div
                className="bg-orange-600 h-full transition-all duration-150"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isUploading || !mediaFile}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 disabled:opacity-50 text-white text-xs sm:text-sm font-bold shadow-md shadow-orange-600/20 transition-all cursor-pointer"
          >
            {isUploading
              ? `Publishing (${uploadProgress}%)...`
              : contentType === 'reel'
              ? 'Publish Reel 🇮🇳'
              : 'Share Post 🇮🇳'}
          </button>
        </form>
      </div>
    </div>
  );
};
