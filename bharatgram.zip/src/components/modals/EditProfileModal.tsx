import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { X, Camera, Lock, Globe, MapPin, AtSign, User as UserIcon, Check, Sparkles } from 'lucide-react';

interface EditProfileModalProps {
  onClose: () => void;
  onProfileUpdated: (newUsername?: string) => void;
}

const PRESET_AVATARS = [
  { label: 'Aarav (Tech)', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80' },
  { label: 'Priya (Travel)', url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80' },
  { label: 'Kabir (Chef)', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80' },
  { label: 'Ananya (Art)', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80' },
  { label: 'Rohit (Sports)', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80' },
  { label: 'Official BLUEJO', url: 'https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=400&auto=format&fit=crop&q=80' }
];

const POPULAR_LOCATIONS = [
  'Bengaluru, Karnataka',
  'Mumbai, Maharashtra',
  'New Delhi, Delhi',
  'Jaipur, Rajasthan',
  'Hyderabad, Telangana',
  'Kolkata, West Bengal',
  'Chennai, Tamil Nadu',
  'Pune, Maharashtra'
];

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  onClose,
  onProfileUpdated
}) => {
  const { user, updateUser, token } = useAuth();
  const { t } = useLanguage();

  const [name, setName] = useState(user?.name || '');
  const [username, setUsername] = useState(user?.username || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [website, setWebsite] = useState(user?.website || '');
  const [location, setLocation] = useState(user?.location || '');
  const [isPrivate, setIsPrivate] = useState(user?.isPrivate || false);
  const [profilePhoto, setProfilePhoto] = useState(user?.profilePhoto || '');
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPresets, setShowPresets] = useState(false);

  const photoInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && token) {
      const file = e.target.files[0];
      const formData = new FormData();
      formData.append('media', file);
      setIsUploadingPhoto(true);
      setErrorMsg('');
      try {
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: formData
        });
        const data = await res.json();
        if (data.success && data.url) {
          setProfilePhoto(data.url);
        } else {
          setErrorMsg(data.error || 'Failed to upload photo');
        }
      } catch (err: any) {
        console.error('Failed to upload photo:', err);
        setErrorMsg('Network error while uploading photo');
      } finally {
        setIsUploadingPhoto(false);
      }
    }
  };

  const handleUsernameChange = (val: string) => {
    const cleaned = val.toLowerCase().replace(/[^a-z0-9_.]/g, '');
    setUsername(cleaned);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Display name cannot be empty.');
      return;
    }
    if (username.trim().length < 3) {
      setErrorMsg('Username must be at least 3 characters.');
      return;
    }

    setIsSaving(true);
    setErrorMsg('');

    const res = await updateUser({
      name: name.trim(),
      username: username.trim(),
      bio: bio.trim(),
      website: website.trim(),
      location: location.trim(),
      isPrivate,
      profilePhoto
    });

    setIsSaving(false);
    if (res.success) {
      onProfileUpdated(username.trim());
      onClose();
    } else {
      setErrorMsg(res.error || 'Failed to update profile');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 select-none overflow-y-auto">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in zoom-in-95 p-5 sm:p-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-orange-600" />
              {t('editProfile')}
            </h3>
            <p className="text-[11px] text-slate-500">Update your public BLUEJO identity</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              {errorMsg}
            </div>
          )}

          {/* Avatar Section */}
          <div className="flex flex-col items-center gap-2 pb-2">
            <div className="relative group">
              <img
                src={profilePhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                alt={name}
                referrerPolicy="no-referrer"
                className="w-24 h-24 rounded-full object-cover ring-4 ring-orange-100 shadow-md"
              />
              <button
                type="button"
                onClick={() => photoInputRef.current?.click()}
                disabled={isUploadingPhoto}
                className="absolute bottom-0 right-0 p-2 bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-full ring-2 ring-white shadow-md hover:scale-105 active:scale-95 transition-transform cursor-pointer"
                title="Upload custom photo"
              >
                {isUploadingPhoto ? (
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Camera className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <div className="flex items-center gap-3 mt-1">
              <button
                type="button"
                onClick={() => photoInputRef.current?.click()}
                className="text-xs text-orange-600 font-semibold hover:underline cursor-pointer"
              >
                Upload Photo
              </button>
              <span className="text-slate-300">•</span>
              <button
                type="button"
                onClick={() => setShowPresets(!showPresets)}
                className="text-xs text-slate-600 font-medium hover:text-slate-900 flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3 text-amber-500" />
                {showPresets ? 'Hide Avatars' : 'Choose Avatar'}
              </button>
            </div>

            {/* Presets Tray */}
            {showPresets && (
              <div className="w-full mt-2 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="text-[11px] font-semibold text-slate-600 mb-2">Select an authentic Indian avatar:</div>
                <div className="grid grid-cols-6 gap-2">
                  {PRESET_AVATARS.map((preset) => (
                    <button
                      key={preset.url}
                      type="button"
                      onClick={() => setProfilePhoto(preset.url)}
                      className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                        profilePhoto === preset.url ? 'border-orange-600 ring-2 ring-orange-200 scale-105' : 'border-transparent hover:border-slate-300'
                      }`}
                      title={preset.label}
                    >
                      <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" />
                      {profilePhoto === preset.url && (
                        <div className="absolute inset-0 bg-orange-600/30 flex items-center justify-center text-white">
                          <Check className="w-3.5 h-3.5 drop-shadow" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Display Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={name}
                maxLength={60}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your Full Name"
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-hidden focus:border-orange-500 focus:bg-white transition-all font-medium"
              />
            </div>

            {/* Username / Handle */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username (@handle) <span className="text-rose-500">*</span>
              </label>
              <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus-within:border-orange-500 focus-within:bg-white transition-all">
                <AtSign className="w-3.5 h-3.5 text-slate-400 mr-1.5 shrink-0" />
                <input
                  type="text"
                  value={username}
                  maxLength={30}
                  onChange={(e) => handleUsernameChange(e.target.value)}
                  placeholder="username"
                  className="w-full text-xs bg-transparent outline-hidden font-medium text-slate-800"
                />
              </div>
              <div className="text-[10px] text-slate-400 mt-1">Unique URL: /profile/{username || '...'}</div>
            </div>
          </div>

          {/* Bio */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">Bio</label>
              <span className="text-[10px] text-slate-400">{bio.length}/300</span>
            </div>
            <textarea
              rows={3}
              value={bio}
              maxLength={300}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell other Indian creators about yourself, interests, tech stacks, or stories..."
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 outline-hidden focus:border-orange-500 focus:bg-white transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Location & Website */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Location</label>
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus-within:border-orange-500 focus-within:bg-white transition-all">
                <MapPin className="w-3.5 h-3.5 text-orange-600 shrink-0" />
                <input
                  type="text"
                  placeholder="e.g. Bengaluru, Karnataka"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full text-xs bg-transparent outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Website / Portfolio</label>
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus-within:border-orange-500 focus-within:bg-white transition-all">
                <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <input
                  type="text"
                  placeholder="https://yourlink.in"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  className="w-full text-xs bg-transparent outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Quick Location suggestions */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[10px] font-medium text-slate-400">Quick set:</span>
            {POPULAR_LOCATIONS.slice(0, 4).map((city) => (
              <button
                key={city}
                type="button"
                onClick={() => setLocation(city)}
                className="text-[10px] bg-slate-100 hover:bg-orange-50 hover:text-orange-700 text-slate-600 px-2 py-0.5 rounded-md transition-colors cursor-pointer"
              >
                {city.split(',')[0]}
              </button>
            ))}
          </div>

          {/* Privacy Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-800">{t('privateAccount')}</div>
                <div className="text-[10px] text-slate-500">Only approved followers can see your posts and reels</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={isPrivate}
                onChange={(e) => setIsPrivate(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-10 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 rounded-xl shadow-md shadow-orange-600/20 active:scale-95 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Saving Changes...
                </>
              ) : (
                'Save Profile'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
