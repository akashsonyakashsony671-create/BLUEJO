import React, { useState, useEffect, useRef } from 'react';
import { Post, Reel, Comment } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { VerifiedBadge } from '../common/Badge';
import { X, Heart, Send, Trash2, Smile } from 'lucide-react';

interface CommentDrawerProps {
  target: Post | Reel;
  targetType: 'post' | 'reel';
  onClose: () => void;
  onCommentsUpdated?: () => void;
  onNavigateToUser: (username: string) => void;
}

const INDIAN_REACTION_EMOJIS = ['🇮🇳', '❤️', '🔥', '👏', '🙏', '😍', '🏏', '✨', '🙌'];

export const CommentDrawer: React.FC<CommentDrawerProps> = ({
  target,
  targetType,
  onClose,
  onCommentsUpdated,
  onNavigateToUser
}) => {
  const { user, token } = useAuth();
  const { t } = useLanguage();

  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [newCommentText, setNewCommentText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const commentsEndRef = useRef<HTMLDivElement>(null);

  const fetchComments = async () => {
    try {
      const endpoint =
        targetType === 'post'
          ? `/api/posts/${target._id}/comments`
          : `/api/reels/${target._id}/comments`;
      const res = await fetch(endpoint);
      const data = await res.json();
      if (data.success && data.comments) {
        setComments(data.comments);
      }
    } catch (err) {
      console.error('Failed to load comments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [target._id, targetType]);

  const handleSendComment = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newCommentText.trim() || !token || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const endpoint =
        targetType === 'post'
          ? `/api/posts/${target._id}/comments`
          : `/api/reels/${target._id}/comments`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ text: newCommentText.trim() })
      });

      const data = await res.json();
      if (data.success && data.comment) {
        setComments(prev => [...prev, data.comment]);
        setNewCommentText('');
        if (onCommentsUpdated) onCommentsUpdated();
        setTimeout(() => {
          commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    } catch (err) {
      console.error('Failed to post comment:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLikeComment = async (commentId: string) => {
    if (!token) return;

    setComments(prev =>
      prev.map(c => {
        if (c._id === commentId) {
          const liked = !c.isLikedByMe;
          return {
            ...c,
            isLikedByMe: liked,
            likesCount: liked ? c.likesCount + 1 : Math.max(0, c.likesCount - 1)
          };
        }
        return c;
      })
    );

    try {
      await fetch(`/api/comments/${commentId}/like`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (err) {
      console.error('Failed to like comment:', err);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!token) return;
    if (!confirm('Delete this comment?')) return;

    try {
      const res = await fetch(`/api/comments/${commentId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setComments(prev => prev.filter(c => c._id !== commentId));
        if (onCommentsUpdated) onCommentsUpdated();
      }
    } catch (err) {
      console.error('Failed to delete comment:', err);
    }
  };

  const addEmoji = (emoji: string) => {
    setNewCommentText(prev => prev + emoji);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center select-none">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 h-[75vh] max-h-[650px] flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 duration-200">
        {/* Drawer Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="text-sm font-bold text-slate-900">
            Comments ({comments.length})
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-40">
              <div className="w-7 h-7 border-3 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-slate-400 text-center">
              <Smile className="w-10 h-10 mb-2 opacity-50" />
              <div className="text-xs font-bold text-slate-600">No comments yet</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Start the conversation!</div>
            </div>
          ) : (
            comments.map((comment) => {
              const isMine = user?._id === comment.userId;
              return (
                <div key={comment._id} className="flex items-start justify-between gap-3 group">
                  <div className="flex items-start gap-2.5 flex-1 min-w-0">
                    <img
                      src={
                        comment.author?.profilePhoto ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                      }
                      alt={comment.author?.username || 'user'}
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded-full object-cover cursor-pointer flex-shrink-0"
                      onClick={() => {
                        if (comment.author?.username) onNavigateToUser(comment.author.username);
                      }}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          onClick={() => {
                            if (comment.author?.username) onNavigateToUser(comment.author.username);
                          }}
                          className="font-bold text-xs text-slate-900 hover:underline cursor-pointer"
                        >
                          {comment.author?.username || 'user'}
                        </span>
                        {comment.author?.isVerified && <VerifiedBadge size="sm" />}
                        <span className="text-[10px] text-slate-400">
                          {new Date(comment.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                      <p className="text-xs text-slate-800 mt-0.5 break-words">
                        {comment.text}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 flex-shrink-0 pt-1">
                    {isMine && (
                      <button
                        onClick={() => handleDeleteComment(comment._id)}
                        className="text-slate-300 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100"
                        title="Delete comment"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => handleLikeComment(comment._id)}
                      className="flex flex-col items-center text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <Heart
                        className={`w-3.5 h-3.5 ${
                          comment.isLikedByMe ? 'text-rose-500 fill-rose-500' : ''
                        }`}
                      />
                      {comment.likesCount > 0 && (
                        <span className="text-[9px] font-bold text-slate-500">
                          {comment.likesCount}
                        </span>
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          )}
          <div ref={commentsEndRef} />
        </div>

        {/* Quick Indian Emojis Bar */}
        <div className="px-4 py-1.5 border-t border-slate-100 flex items-center gap-2 overflow-x-auto no-scrollbar bg-slate-50/70">
          {INDIAN_REACTION_EMOJIS.map((emoji) => (
            <button
              key={emoji}
              onClick={() => addEmoji(emoji)}
              className="text-base hover:scale-125 transition-transform p-1 cursor-pointer"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Comment Input */}
        {user ? (
          <form
            onSubmit={handleSendComment}
            className="p-3 border-t border-slate-200 flex items-center gap-2 bg-white"
          >
            <input
              type="text"
              placeholder={t('addComment')}
              value={newCommentText}
              onChange={(e) => setNewCommentText(e.target.value)}
              className="flex-1 text-xs bg-slate-100 hover:bg-slate-150 focus:bg-white border border-transparent focus:border-orange-500 rounded-full px-4 py-2.5 outline-hidden transition-all"
            />
            <button
              type="submit"
              disabled={!newCommentText.trim() || isSubmitting}
              className="p-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white rounded-full transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <div className="p-3 text-center text-xs text-slate-500 border-t border-slate-100 bg-slate-50">
            Log in to comment on BLUEJO.
          </div>
        )}
      </div>
    </div>
  );
};
