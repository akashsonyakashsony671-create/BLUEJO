import React, { useState, useEffect, useRef } from 'react';
import { useAuth, SignupPayload } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { Logo } from '../common/Logo';
import { ConfirmationResult } from 'firebase/auth';
import {
  X,
  ArrowRight,
  Sparkles,
  Lock,
  Mail,
  User,
  Calendar,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Camera,
  RefreshCw,
  KeyRound,
  ShieldCheck,
  ChevronLeft,
  Smartphone,
  Globe,
  ExternalLink
} from 'lucide-react';

export type AuthScreenMode =
  | 'welcome'
  | 'login'
  | 'signup'
  | 'phone_auth'
  | 'phone_otp'
  | 'email_verification_sent'
  | 'forgot_password'
  | 'reset_password'
  | 'google_select';

interface AuthModalProps {
  onClose: () => void;
  initialMode?: 'login' | 'signup' | 'welcome' | 'phone_auth';
  onSuccess?: () => void;
}

const COUNTRY_CODES = [
  { code: '+91', name: 'India', flag: '🇮🇳' },
  { code: '+1', name: 'USA / Canada', flag: '🇺🇸' },
  { code: '+44', name: 'UK', flag: '🇬🇧' },
  { code: '+971', name: 'UAE', flag: '🇦🇪' },
  { code: '+65', name: 'Singapore', flag: '🇸🇬' },
  { code: '+61', name: 'Australia', flag: '🇦🇺' },
  { code: '+49', name: 'Germany', flag: '🇩🇪' },
  { code: '+966', name: 'Saudi Arabia', flag: '🇸🇦' },
  { code: '+977', name: 'Nepal', flag: '🇳🇵' },
  { code: '+880', name: 'Bangladesh', flag: '🇧🇩' }
];

export const AuthModal: React.FC<AuthModalProps> = ({
  onClose,
  initialMode = 'welcome',
  onSuccess
}) => {
  const {
    firebaseSignupWithEmail,
    firebaseLoginWithEmail,
    firebaseSendPasswordReset,
    firebaseSendEmailVerification,
    firebaseSendPhoneOtp,
    firebaseVerifyPhoneOtp,
    firebaseGoogleSignIn,
    checkEmailVerified,
    login,
    googleLogin,
    quickLogin
  } = useAuth();
  const { t } = useLanguage();

  const [mode, setMode] = useState<AuthScreenMode>(initialMode);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingText, setLoadingText] = useState<string>('');

  // Form Fields - Login
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Form Fields - Signup
  const [signupName, setSignupName] = useState('');
  const [signupUsername, setSignupUsername] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupDob, setSignupDob] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [signupAvatar, setSignupAvatar] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form Fields - Phone Authentication
  const [selectedCountryCode, setSelectedCountryCode] = useState('+91');
  const [phoneRawNumber, setPhoneRawNumber] = useState('');
  const [phoneUserName, setPhoneUserName] = useState('');
  const [phoneConfirmationResult, setPhoneConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [phoneFormattedNumber, setPhoneFormattedNumber] = useState('');

  // 6-digit OTP fields (for Phone SMS OTP & Legacy verification)
  const [otpDigits, setOtpDigits] = useState(['', '', '', '', '', '']);
  const [otpTimer, setOtpTimer] = useState<number>(60);
  const [canResend, setCanResend] = useState(false);

  // Password Reset / Verification fields
  const [verificationEmail, setVerificationEmail] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [emailResendTimer, setEmailResendTimer] = useState(0);

  // Preset Avatars for Signup
  const presetAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80'
  ];

  // OTP Timer countdown (Phone OTP)
  useEffect(() => {
    let interval: any = null;
    if (mode === 'phone_otp' && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    } else if (otpTimer === 0) {
      setCanResend(true);
    }
    return () => clearInterval(interval);
  }, [mode, otpTimer]);

  // Email resend timer countdown
  useEffect(() => {
    let interval: any = null;
    if (emailResendTimer > 0) {
      interval = setInterval(() => {
        setEmailResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [emailResendTimer]);

  const handleFinishAuth = () => {
    if (onSuccess) onSuccess();
    onClose();
  };

  const goTo = (newMode: AuthScreenMode) => {
    setErrorMsg('');
    setSuccessMsg('');
    setMode(newMode);
  };

  // Photo upload handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setErrorMsg('Image size should be less than 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          setSignupAvatar(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // 1. Submit Login (Firebase Email or Username)
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim() || !loginPassword) {
      setErrorMsg('Please enter your email or username, and password.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Signing in securely...');
    setErrorMsg('');

    try {
      if (loginIdentifier.includes('@')) {
        // Real Firebase Email + Password sign-in
        const res = await firebaseLoginWithEmail(loginIdentifier.trim(), loginPassword);
        if (res.success) {
          if (res.emailVerified === false) {
            setSuccessMsg('Signed in! Note: Email verification pending. You can request a new link if needed.');
          } else {
            setSuccessMsg('Signed in successfully!');
          }
          setTimeout(() => handleFinishAuth(), 600);
        } else {
          setErrorMsg(res.error || 'Invalid email or password.');
        }
      } else {
        // Username sign-in via BLUEJO backend
        const res = await login(loginIdentifier.trim(), loginPassword);
        if (res.success) {
          setSuccessMsg('Welcome back!');
          setTimeout(() => handleFinishAuth(), 600);
        } else {
          setErrorMsg(res.error || 'Invalid username or password.');
        }
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Submit Signup (Real Firebase Email + Password Signup + Verification Link)
  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!signupName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }

    if (!signupUsername.trim() || signupUsername.trim().length < 3) {
      setErrorMsg('Username must be at least 3 characters.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(signupEmail.trim())) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    if (!signupDob) {
      setErrorMsg('Please enter your date of birth.');
      return;
    }

    const bDate = new Date(signupDob);
    const ageDiff = Date.now() - bDate.getTime();
    const age = Math.abs(new Date(ageDiff).getUTCFullYear() - 1970);
    if (age < 13) {
      setErrorMsg('You must be at least 13 years old to join BLUEJO.');
      return;
    }

    if (signupPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }

    if (signupPassword !== signupConfirmPassword) {
      setErrorMsg('Passwords do not match. Please verify.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Creating Firebase account...');

    try {
      const payload: SignupPayload = {
        name: signupName.trim(),
        username: signupUsername.trim().toLowerCase(),
        email: signupEmail.trim().toLowerCase(),
        password: signupPassword,
        confirmPassword: signupConfirmPassword,
        dob: signupDob,
        profilePhoto: signupAvatar
      };

      const res = await firebaseSignupWithEmail(payload);

      if (res.success) {
        setVerificationEmail(signupEmail.trim().toLowerCase());
        setEmailResendTimer(60);
        goTo('email_verification_sent');
      } else {
        setErrorMsg(res.error || 'Signup failed. Please try again.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error creating account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Send SMS OTP for Firebase Phone Auth
  const handleSendPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanDigits = phoneRawNumber.replace(/[^0-9]/g, '');
    if (cleanDigits.length < 6) {
      setErrorMsg('Please enter a valid mobile phone number.');
      return;
    }

    const fullPhoneNumber = `${selectedCountryCode}${cleanDigits}`;
    setPhoneFormattedNumber(fullPhoneNumber);

    setIsLoading(true);
    setLoadingText('Sending SMS verification code...');

    try {
      const res = await firebaseSendPhoneOtp(fullPhoneNumber, 'recaptcha-container');
      if (res.success && res.confirmationResult) {
        setPhoneConfirmationResult(res.confirmationResult);
        setOtpDigits(['', '', '', '', '', '']);
        setOtpTimer(60);
        setCanResend(false);
        goTo('phone_otp');
      } else {
        setErrorMsg(res.error || 'Failed to send SMS OTP. Please verify your phone number.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to send SMS code. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Handle Phone OTP input digits
  const handleOtpInput = (val: string, index: number) => {
    const clean = val.replace(/[^0-9]/g, '');
    const newDigits = [...otpDigits];

    if (clean.length > 1) {
      const splitDigits = clean.slice(0, 6).split('');
      for (let i = 0; i < 6; i++) {
        newDigits[i] = splitDigits[i] || '';
      }
      setOtpDigits(newDigits);
      const nextFocus = Math.min(splitDigits.length, 5);
      const el = document.getElementById(`otp-input-${nextFocus}`);
      el?.focus();
      return;
    }

    newDigits[index] = clean;
    setOtpDigits(newDigits);

    if (clean && index < 5) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleOtpKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      const prev = document.getElementById(`otp-input-${index - 1}`);
      prev?.focus();
    }
  };

  // 5. Submit Phone OTP Verification
  const handlePhoneOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const fullOtp = otpDigits.join('');
    if (fullOtp.length < 6) {
      setErrorMsg('Please enter the complete 6-digit SMS verification code.');
      return;
    }

    if (!phoneConfirmationResult) {
      setErrorMsg('Session expired. Please request a new SMS code.');
      goTo('phone_auth');
      return;
    }

    setIsLoading(true);
    setLoadingText('Verifying SMS code...');
    setErrorMsg('');

    try {
      const res = await firebaseVerifyPhoneOtp(phoneConfirmationResult, fullOtp, {
        name: phoneUserName.trim() || undefined
      });

      if (res.success) {
        setSuccessMsg('Phone verified successfully! Welcome to BLUEJO.');
        setTimeout(() => {
          handleFinishAuth();
        }, 800);
      } else {
        setErrorMsg(res.error || 'Invalid or expired SMS code. Please check and try again.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Verification failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 6. Resend Phone SMS OTP
  const handleResendPhoneOtp = async () => {
    if (!canResend && otpTimer > 0) return;

    setIsLoading(true);
    setLoadingText('Resending SMS code...');
    setErrorMsg('');

    try {
      const res = await firebaseSendPhoneOtp(phoneFormattedNumber, 'recaptcha-container');
      if (res.success && res.confirmationResult) {
        setPhoneConfirmationResult(res.confirmationResult);
        setOtpTimer(60);
        setCanResend(false);
        setSuccessMsg('A fresh 6-digit SMS verification code has been sent.');
        setTimeout(() => setSuccessMsg(''), 4000);
      } else {
        setErrorMsg(res.error || 'Failed to resend SMS code.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to resend SMS code.');
    } finally {
      setIsLoading(false);
    }
  };

  // 7. Resend Firebase Email Verification
  const handleResendEmailVerification = async () => {
    if (emailResendTimer > 0) return;
    setIsLoading(true);
    setLoadingText('Sending verification email...');
    setErrorMsg('');

    try {
      const res = await firebaseSendEmailVerification();
      if (res.success) {
        setEmailResendTimer(60);
        setSuccessMsg('A new verification email has been sent. Check your inbox!');
        setTimeout(() => setSuccessMsg(''), 5000);
      } else {
        setErrorMsg(res.error || 'Failed to resend verification email.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to resend verification email.');
    } finally {
      setIsLoading(false);
    }
  };

  // 7b. Check Email Verification Status
  const handleCheckEmailVerified = async () => {
    setIsLoading(true);
    setLoadingText('Checking verification status...');
    setErrorMsg('');
    try {
      const res = await checkEmailVerified();
      if (res.verified) {
        setSuccessMsg('Email successfully verified! Welcome to BLUEJO.');
        setTimeout(() => {
          handleFinishAuth();
        }, 1000);
      } else {
        setErrorMsg('Email verification not detected yet. Please click the link in your inbox and try again.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to check verification status.');
    } finally {
      setIsLoading(false);
    }
  };

  // 8. Firebase Password Reset Submit
  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) {
      setErrorMsg('Please enter your registered email address.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Sending password reset email...');
    setErrorMsg('');

    try {
      const res = await firebaseSendPasswordReset(forgotEmail.trim().toLowerCase());
      if (res.success) {
        setSuccessMsg(res.message || 'Password reset link sent to your email.');
      } else {
        setErrorMsg(res.error || 'No account found with this email.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to send reset link.');
    } finally {
      setIsLoading(false);
    }
  };

  // 9. Firebase Google Sign-in
  const handleGoogleSignInClick = async () => {
    setIsLoading(true);
    setLoadingText('Connecting to Google via Firebase...');
    setErrorMsg('');

    try {
      const res = await firebaseGoogleSignIn();
      if (res.success) {
        setSuccessMsg('Signed in with Google!');
        setTimeout(() => handleFinishAuth(), 600);
      } else {
        // Fallback to select screen if popup was blocked
        goTo('google_select');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Google sign-in failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSimulatedGoogleSelect = async (gUser: { name: string; email: string; avatar: string }) => {
    setIsLoading(true);
    setLoadingText('Authenticating with Google...');
    setErrorMsg('');
    try {
      const res = await googleLogin({
        name: gUser.name,
        email: gUser.email,
        avatar: gUser.avatar,
        googleId: `google_${Date.now()}`
      });
      if (res.success) {
        handleFinishAuth();
      } else {
        setErrorMsg(res.error || 'Google sign-in failed.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Google sign-in error.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      id="bluejo-auth-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="bluejo-auth-container"
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200/80 overflow-hidden my-auto animate-in zoom-in-95 duration-200 transition-all"
      >
        {/* Invisible reCAPTCHA container for Phone Auth */}
        <div id="recaptcha-container" className="flex justify-center" />

        {/* Top bar with back button / close */}
        <div className="flex items-center justify-between px-6 pt-5 pb-2">
          {mode !== 'welcome' && (
            <button
              id="auth-back-button"
              type="button"
              onClick={() => {
                if (mode === 'phone_otp') {
                  goTo('phone_auth');
                } else if (mode === 'email_verification_sent') {
                  goTo('login');
                } else if (mode === 'forgot_password') {
                  goTo('login');
                } else {
                  goTo('welcome');
                }
              }}
              className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors cursor-pointer py-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          )}

          <div className="flex-1" />

          <button
            id="auth-close-button"
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Error & Success Alerts */}
        <div className="px-6">
          {errorMsg && (
            <div
              id="auth-error-banner"
              className="p-3.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-2xl font-medium flex items-start gap-2.5 mb-3 animate-in fade-in-50"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{errorMsg}</div>
            </div>
          )}

          {successMsg && (
            <div
              id="auth-success-banner"
              className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-2xl font-medium flex items-start gap-2.5 mb-3 animate-in fade-in-50"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{successMsg}</div>
            </div>
          )}
        </div>

        {/* ============================================================== */}
        {/* VIEW 1: WELCOME SCREEN */}
        {/* ============================================================== */}
        {mode === 'welcome' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center flex flex-col items-center mb-5">
              <div className="p-3 bg-blue-50/80 rounded-3xl border border-blue-100 mb-3 shadow-inner">
                <Logo size="lg" showText={false} />
              </div>
              <h1 className="font-black text-2xl sm:text-3xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Welcome to <span className="text-blue-600">BLUEJO</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1.5 max-w-sm">
                Next-generation social media for creators. Sign in with Firebase Phone SMS or Email.
              </p>
            </div>

            {/* Visual Value Cards */}
            <div className="grid grid-cols-2 gap-2.5 mb-5">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 text-left">
                <div className="w-7 h-7 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs mb-2">
                  📱
                </div>
                <div className="text-xs font-bold text-slate-800">Phone & SMS OTP</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Instant sign in with your mobile number.</div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 text-left">
                <div className="w-7 h-7 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs mb-2">
                  🔥
                </div>
                <div className="text-xs font-bold text-slate-800">Firebase Auth</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Encrypted sessions and verified accounts.</div>
              </div>
            </div>

            {/* Primary Actions */}
            <div className="space-y-2.5">
              {/* Phone OTP Action */}
              <button
                id="welcome-phone-auth-btn"
                type="button"
                onClick={() => goTo('phone_auth')}
                className="w-full py-3.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2.5 cursor-pointer active:scale-[0.99]"
              >
                <Smartphone className="w-4 h-4" />
                <span>Continue with Mobile Phone (SMS OTP)</span>
                <ArrowRight className="w-4 h-4 ml-auto" />
              </button>

              {/* Email Signup Action */}
              <button
                id="welcome-create-account-btn"
                type="button"
                onClick={() => goTo('signup')}
                className="w-full py-3 px-4 rounded-2xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs font-bold border border-slate-200/80 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Mail className="w-4 h-4 text-slate-600" />
                <span>Create Account with Email</span>
              </button>

              {/* Email/Username Login Action */}
              <button
                id="welcome-signin-btn"
                type="button"
                onClick={() => goTo('login')}
                className="w-full py-2.5 px-4 rounded-2xl hover:bg-slate-50 text-slate-600 text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Already have an account? Sign in</span>
              </button>
            </div>

            {/* Google Sign-In Divider */}
            <div className="relative my-5 text-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <span className="relative bg-white px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                or continue with
              </span>
            </div>

            {/* Google Sign-in Button */}
            <button
              id="google-signin-btn"
              type="button"
              disabled={isLoading}
              onClick={handleGoogleSignInClick}
              className="w-full py-3 px-4 rounded-2xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-3 cursor-pointer shadow-xs active:scale-[0.99] disabled:opacity-60"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Quick One-Click Test Accounts */}
            <div className="mt-5 pt-4 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Instant Sandbox Demo Accounts</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    setIsLoading(true);
                    setLoadingText('Logging in as Aarav...');
                    await quickLogin('aarav_tech');
                    setIsLoading(false);
                    handleFinishAuth();
                  }}
                  className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 text-left transition-colors cursor-pointer"
                >
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                    alt="Aarav"
                    className="w-7 h-7 rounded-full object-cover"
                  />
                  <div className="truncate min-w-0">
                    <div className="text-[11px] font-bold text-slate-800 leading-tight truncate">Aarav Sharma</div>
                    <div className="text-[10px] text-slate-500">Demo Creator</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    setIsLoading(true);
                    setLoadingText('Logging in as BLUEJO Admin...');
                    await quickLogin('bluejo');
                    setIsLoading(false);
                    handleFinishAuth();
                  }}
                  className="flex items-center gap-2 p-2 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-100 text-left transition-colors cursor-pointer"
                >
                  <img
                    src="/bluejo-logo.png"
                    alt="BLUEJO"
                    className="w-7 h-7 rounded-full object-contain bg-white p-0.5 border border-blue-300"
                  />
                  <div className="truncate min-w-0">
                    <div className="text-[11px] font-bold text-blue-950 leading-tight">BLUEJO Official</div>
                    <div className="text-[10px] text-blue-700">Admin Account</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 2: PHONE AUTHENTICATION (Real Firebase SMS OTP) */}
        {/* ============================================================== */}
        {mode === 'phone_auth' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 mx-auto flex items-center justify-center mb-3 border border-blue-100">
                <Smartphone className="w-6 h-6" />
              </div>
              <h2 className="font-black text-2xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Mobile Phone Login
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your mobile number to receive a real 6-digit Firebase SMS code
              </p>
            </div>

            <form onSubmit={handleSendPhoneOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Mobile Number <span className="text-rose-500">*</span>
                </label>
                <div className="flex gap-2">
                  {/* Country code selector */}
                  <div className="relative">
                    <select
                      value={selectedCountryCode}
                      onChange={(e) => setSelectedCountryCode(e.target.value)}
                      className="h-full text-xs font-bold bg-slate-50 border border-slate-200 rounded-2xl px-3 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-800 cursor-pointer"
                    >
                      {COUNTRY_CODES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.flag} {c.code} ({c.name})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Phone input */}
                  <div className="relative flex-1">
                    <Smartphone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      id="phone-number-input"
                      type="tel"
                      required
                      placeholder="e.g. 9876543210"
                      value={phoneRawNumber}
                      onChange={(e) => setPhoneRawNumber(e.target.value.replace(/[^0-9]/g, ''))}
                      className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white transition-all text-slate-900"
                    />
                  </div>
                </div>
                <div className="mt-1.5 text-[11px] text-slate-500">
                  Full phone number format: <span className="font-mono font-bold text-blue-600">{selectedCountryCode}{phoneRawNumber || 'XXXXXXXXXX'}</span>
                </div>
              </div>

              {/* Optional Name for new phone user */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Full Name <span className="text-slate-400 font-normal">(optional for new users)</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="phone-username-input"
                    type="text"
                    placeholder="Your Name (e.g. Alex Sharma)"
                    value={phoneUserName}
                    onChange={(e) => setPhoneUserName(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white transition-all text-slate-900"
                  />
                </div>
              </div>

              <button
                id="phone-send-sms-btn"
                type="submit"
                disabled={isLoading || !phoneRawNumber.trim()}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{loadingText || 'Sending SMS code...'}</span>
                  </>
                ) : (
                  <>
                    <span>Send 6-Digit SMS Code</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={() => goTo('login')}
                className="font-bold text-slate-600 hover:text-blue-600 cursor-pointer"
              >
                Sign In with Email or Password
              </button>

              <button
                type="button"
                onClick={() => goTo('signup')}
                className="font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Create New Account
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 3: PHONE SMS OTP VERIFICATION */}
        {/* ============================================================== */}
        {mode === 'phone_otp' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 mx-auto flex items-center justify-center mb-3 border border-blue-100">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h2 className="font-black text-2xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Enter SMS Code
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                We sent a 6-digit SMS verification code to{' '}
                <span className="font-mono font-bold text-slate-800">{phoneFormattedNumber}</span>
              </p>
            </div>

            <form onSubmit={handlePhoneOtpSubmit} className="space-y-6">
              {/* 6-box OTP entry */}
              <div className="flex justify-center gap-2 sm:gap-2.5">
                {otpDigits.map((digit, idx) => (
                  <input
                    key={idx}
                    id={`otp-input-${idx}`}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpInput(e.target.value, idx)}
                    onKeyDown={(e) => handleOtpKeyDown(e, idx)}
                    className="w-11 h-13 sm:w-12 sm:h-14 text-center text-xl font-bold font-mono bg-slate-50 border-2 border-slate-200 rounded-2xl outline-hidden focus:border-blue-600 focus:bg-white text-slate-900 transition-all shadow-inner"
                  />
                ))}
              </div>

              <button
                id="verify-phone-otp-btn"
                type="submit"
                disabled={isLoading || otpDigits.join('').length < 6}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{loadingText || 'Verifying SMS code...'}</span>
                  </>
                ) : (
                  <>
                    <span>Verify & Continue to BLUEJO</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-5 text-center text-xs text-slate-500 flex flex-col items-center gap-2">
              <div>
                Didn't receive the SMS?{' '}
                <button
                  type="button"
                  disabled={!canResend && otpTimer > 0}
                  onClick={handleResendPhoneOtp}
                  className={`font-bold ml-1 cursor-pointer ${
                    canResend ? 'text-blue-600 hover:underline' : 'text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Resend SMS {!canResend && `(${otpTimer}s)`}
                </button>
              </div>

              <button
                type="button"
                onClick={() => goTo('phone_auth')}
                className="text-[11px] text-slate-400 hover:text-slate-600 underline cursor-pointer"
              >
                Edit phone number
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 4: LOGIN FORM (Email or Username) */}
        {/* ============================================================== */}
        {mode === 'login' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center mb-6">
              <h2 className="font-black text-2xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Sign In to <span className="text-blue-600">BLUEJO</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your registered email or username and password
              </p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Email or Username
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="login-identifier-input"
                    type="text"
                    required
                    placeholder="e.g. user@example.com or aarav_tech"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white transition-all text-slate-900"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700">Password</label>
                  <button
                    id="forgot-password-link"
                    type="button"
                    onClick={() => {
                      setForgotEmail(loginIdentifier.includes('@') ? loginIdentifier : '');
                      goTo('forgot_password');
                    }}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="login-password-input"
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-10 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white transition-all text-slate-900"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5"
                    aria-label={showLoginPassword ? 'Hide password' : 'Show password'}
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                id="login-submit-btn"
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{loadingText || 'Signing in securely...'}</span>
                  </>
                ) : (
                  <>
                    <span>Sign In</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => goTo('phone_auth')}
                className="w-full py-2.5 px-3 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50 hover:bg-blue-50/50 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span>Sign in with Mobile Phone instead</span>
              </button>

              <div className="text-center text-xs text-slate-500">
                Don't have a BLUEJO account?{' '}
                <button
                  id="switch-to-signup-btn"
                  type="button"
                  onClick={() => goTo('signup')}
                  className="font-bold text-blue-600 hover:underline cursor-pointer ml-1"
                >
                  Create Account
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 5: SIGN UP FORM (Email + Details) */}
        {/* ============================================================== */}
        {mode === 'signup' && (
          <div className="px-6 pb-8 pt-2 max-h-[80vh] overflow-y-auto">
            <div className="text-center mb-5">
              <h2 className="font-black text-2xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Join <span className="text-blue-600">BLUEJO</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Create your verified profile to start creating and connecting
              </p>
            </div>

            <form onSubmit={handleSignupSubmit} className="space-y-3.5">
              {/* Profile Photo Selector */}
              <div className="flex flex-col items-center mb-2">
                <div className="relative group">
                  <div className="w-18 h-18 rounded-full border-2 border-dashed border-blue-400 bg-blue-50/50 p-1 flex items-center justify-center overflow-hidden">
                    {signupAvatar ? (
                      <img
                        src={signupAvatar}
                        alt="Profile Preview"
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <User className="w-8 h-8 text-blue-400" />
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-0 right-0 p-1.5 bg-blue-600 text-white rounded-full hover:bg-blue-700 shadow-md cursor-pointer transition-transform group-hover:scale-105"
                    aria-label="Upload photo"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />

                {/* Preset Avatars */}
                <div className="flex items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-slate-400 font-semibold mr-1">Or pick:</span>
                  {presetAvatars.map((av, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSignupAvatar(av)}
                      className={`w-6 h-6 rounded-full overflow-hidden border-2 transition-transform cursor-pointer ${
                        signupAvatar === av ? 'border-blue-600 scale-110 shadow-xs' : 'border-slate-200'
                      }`}
                    >
                      <img src={av} alt={`Avatar ${idx}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="signup-name-input"
                    type="text"
                    required
                    placeholder="e.g. Aarav Sharma"
                    value={signupName}
                    onChange={(e) => setSignupName(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                </div>
              </div>

              {/* Username */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Username <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-400">@</span>
                  <input
                    id="signup-username-input"
                    type="text"
                    required
                    placeholder="username (lowercase, letters and numbers)"
                    value={signupUsername}
                    onChange={(e) => setSignupUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_.]/g, ''))}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-8 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="signup-email-input"
                    type="email"
                    required
                    placeholder="user@example.com"
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                </div>
              </div>

              {/* Date of Birth */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Date of Birth <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="signup-dob-input"
                    type="date"
                    required
                    value={signupDob}
                    onChange={(e) => setSignupDob(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password (min 6 chars) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="signup-password-input"
                    type={showSignupPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-10 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSignupPassword(!showSignupPassword)}
                    className="absolute right-3.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showSignupPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Confirm Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="signup-confirm-password-input"
                    type={showSignupPassword ? 'text' : 'password'}
                    required
                    placeholder="Repeat password"
                    value={signupConfirmPassword}
                    onChange={(e) => setSignupConfirmPassword(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                </div>
                {signupPassword && signupConfirmPassword && (
                  <div className="mt-1 text-[11px] flex items-center gap-1 font-semibold">
                    {signupPassword === signupConfirmPassword ? (
                      <span className="text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Passwords match
                      </span>
                    ) : (
                      <span className="text-rose-500">Passwords do not match yet</span>
                    )}
                  </div>
                )}
              </div>

              {/* Submit CTA */}
              <button
                id="signup-submit-btn"
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/25 transition-all cursor-pointer flex items-center justify-center gap-2 mt-4 disabled:opacity-60"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{loadingText || 'Creating account...'}</span>
                  </>
                ) : (
                  <>
                    <span>Create BLUEJO Account</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => goTo('phone_auth')}
                className="w-full py-2.5 px-3 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50 hover:bg-blue-50/50 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span>Or sign up with Mobile Phone</span>
              </button>

              <div className="text-center text-xs text-slate-500">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => goTo('login')}
                  className="font-bold text-blue-600 hover:underline cursor-pointer ml-1"
                >
                  Sign In
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 6: EMAIL VERIFICATION SENT SCREEN */}
        {/* ============================================================== */}
        {mode === 'email_verification_sent' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center mb-6">
              <div className="w-14 h-14 rounded-3xl bg-blue-50 text-blue-600 mx-auto flex items-center justify-center mb-3 border border-blue-100 shadow-inner">
                <Mail className="w-7 h-7" />
              </div>
              <h2 className="font-black text-2xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Verification Email Sent!
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                We've sent a Firebase verification link to{' '}
                <span className="font-bold text-slate-800">{verificationEmail}</span>
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 mb-5 text-left text-xs text-slate-600 space-y-2 leading-relaxed">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Open your email inbox (or spam folder) and click the verification link.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>Your BLUEJO profile has been created and synced with Firebase.</span>
              </div>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                disabled={isLoading}
                onClick={handleCheckEmailVerified}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Checking verification status...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>I've Verified My Email (Check Status)</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleFinishAuth}
                className="w-full py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Continue to BLUEJO Home</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                disabled={isLoading || emailResendTimer > 0}
                onClick={handleResendEmailVerification}
                className="w-full py-2.5 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Resending...</span>
                  </>
                ) : (
                  <span>
                    Resend Verification Email {emailResendTimer > 0 && `(${emailResendTimer}s)`}
                  </span>
                )}
              </button>
            </div>

            <div className="mt-5 text-center text-xs text-slate-400">
              Need to sign in with a different email?{' '}
              <button
                type="button"
                onClick={() => goTo('login')}
                className="font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Sign In
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 7: FORGOT PASSWORD */}
        {/* ============================================================== */}
        {mode === 'forgot_password' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 mx-auto flex items-center justify-center mb-3 border border-amber-100">
                <KeyRound className="w-6 h-6" />
              </div>
              <h2 className="font-black text-2xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Reset Password
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Enter your registered BLUEJO email to receive a Firebase password reset link.
              </p>
            </div>

            <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Your Account Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="user@example.com"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 outline-hidden focus:border-blue-600 focus:bg-white text-slate-900"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Sending reset link...</span>
                  </>
                ) : (
                  <>
                    <span>Send Password Reset Link</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-5 text-center text-xs text-slate-500">
              Remember your password?{' '}
              <button
                type="button"
                onClick={() => goTo('login')}
                className="font-bold text-blue-600 hover:underline cursor-pointer ml-1"
              >
                Return to Login
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 8: GOOGLE ACCOUNT PICKER (Seamless Simulation Fallback) */}
        {/* ============================================================== */}
        {mode === 'google_select' && (
          <div className="px-6 pb-8 pt-2">
            <div className="text-center mb-6">
              <svg className="w-8 h-8 mx-auto mb-2" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <h2 className="font-black text-xl text-slate-900 tracking-tight font-['Outfit',sans-serif]">
                Sign in with Google
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Choose an account to continue to <span className="font-bold text-slate-800">BLUEJO</span>
              </p>
            </div>

            <div className="space-y-2 mb-6">
              {[
                {
                  name: 'Aarav Sharma',
                  email: 'aarav.sharma@gmail.com',
                  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'
                },
                {
                  name: 'Priya Iyer',
                  email: 'priya.iyer@gmail.com',
                  avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80'
                },
                {
                  name: 'Karan Mehra',
                  email: 'karan.mehra@gmail.com',
                  avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80'
                }
              ].map((account, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSimulatedGoogleSelect(account)}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 transition-all text-left cursor-pointer group"
                >
                  <img
                    src={account.avatar}
                    alt={account.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                      {account.name}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate">{account.email}</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>

            <div className="text-center">
              <button
                type="button"
                onClick={() => goTo('welcome')}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 underline cursor-pointer"
              >
                Cancel and return
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
