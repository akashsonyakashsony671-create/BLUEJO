import React, { useState } from 'react';
import { Post, Reel } from '../../types';
import { X, Copy, Check, MessageSquare, Share2 } from 'lucide-react';

interface ShareModalProps {
  target: Post | Reel;
  targetType: 'post' | 'reel';
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  target,
  targetType,
  onClose
}) => {
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/${targetType}/${target._id}`;
  const shareText = `Check out this ${targetType} by @${target.author.username} on BLUEJO: ${target.caption?.slice(0, 50) || ''}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
    window.open(url, '_blank');
  };

  const shareTwitter = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
    window.open(url, '_blank');
  };

  const shareTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'BLUEJO',
          text: shareText,
          url: shareUrl
        });
      } catch (err) {
        // User canceled or failed
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150 p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="text-sm font-bold text-slate-900">Share to...</div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Share buttons */}
        <div className="grid grid-cols-4 gap-3 py-5 text-center">
          <button
            onClick={shareWhatsApp}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-emerald-50 transition-colors"
          >
            <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs">
              <span className="text-xl font-bold">💬</span>
            </div>
            <span className="text-[11px] font-medium text-slate-700">WhatsApp</span>
          </button>

          <button
            onClick={shareTelegram}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-sky-50 transition-colors"
          >
            <div className="w-12 h-12 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-xs">
              <span className="text-xl font-bold">✈️</span>
            </div>
            <span className="text-[11px] font-medium text-slate-700">Telegram</span>
          </button>

          <button
            onClick={shareTwitter}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-slate-100 transition-colors"
          >
            <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-xs">
              <span className="text-xl font-bold">𝕏</span>
            </div>
            <span className="text-[11px] font-medium text-slate-700">X</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-orange-50 transition-colors"
          >
            <div className="w-12 h-12 rounded-full bg-orange-500 text-white flex items-center justify-center shadow-xs">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-medium text-slate-700">More</span>
          </button>
        </div>

        {/* Copy Link Input */}
        <div className="flex items-center gap-2 p-2 bg-slate-50 border border-slate-200 rounded-2xl">
          <input
            type="text"
            readOnly
            value={shareUrl}
            className="flex-1 bg-transparent text-xs text-slate-600 outline-hidden truncate px-2"
          />
          <button
            onClick={handleCopy}
            className="px-3.5 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
