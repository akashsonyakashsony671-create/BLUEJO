import React from 'react';
import { Home, Compass, PlusSquare, Film, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface BottomNavProps {
  currentView: string;
  onNavigate: (view: string, params?: any) => void;
  onOpenCreate: () => void;
  onOpenAuth: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentView,
  onNavigate,
  onOpenCreate,
  onOpenAuth
}) => {
  const { user } = useAuth();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-3 py-2 flex items-center justify-around select-none">
      <button
        onClick={() => onNavigate('feed')}
        className={`p-2 rounded-xl transition-colors ${
          currentView === 'feed' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <Home className="w-6 h-6" />
      </button>

      <button
        onClick={() => onNavigate('explore')}
        className={`p-2 rounded-xl transition-colors ${
          currentView === 'explore' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <Compass className="w-6 h-6" />
      </button>

      {/* Central Create Button with BLUEJO blue-indigo gradient */}
      <button
        onClick={() => {
          if (!user) onOpenAuth();
          else onOpenCreate();
        }}
        className="p-2.5 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/30 active:scale-95 transition-transform"
      >
        <PlusSquare className="w-6 h-6 stroke-[2.5]" />
      </button>

      <button
        onClick={() => onNavigate('reels')}
        className={`p-2 rounded-xl transition-colors ${
          currentView === 'reels' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <Film className="w-6 h-6" />
      </button>

      <button
        onClick={() => {
          if (!user) onOpenAuth();
          else onNavigate('profile', { username: user.username });
        }}
        className={`p-2 rounded-xl transition-colors ${
          currentView === 'profile' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        {user ? (
          <img
            src={user.profilePhoto}
            alt={user.name}
            referrerPolicy="no-referrer"
            className={`w-6 h-6 rounded-full object-cover border ${
              currentView === 'profile' ? 'border-blue-600 ring-2 ring-blue-200' : 'border-slate-300'
            }`}
          />
        ) : (
          <User className="w-6 h-6" />
        )}
      </button>
    </nav>
  );
};
