import React, { useState } from 'react';
import officialLogoAsset from '../../assets/bluejo-logo.png';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  showTagline = false,
  className = '',
  onClick
}) => {
  const [imgSrc, setImgSrc] = useState<string>(officialLogoAsset);
  const [hasFailed, setHasFailed] = useState<boolean>(false);

  // Fallback chain for maximum reliability in dev, preview, and production environments
  const handleError = () => {
    if (imgSrc === officialLogoAsset) {
      setImgSrc('/bluejo-logo.png');
    } else if (imgSrc === '/bluejo-logo.png') {
      setImgSrc('/ChatGPT Image Sep 19, 2026, 07_20_48 PM.png');
    } else if (imgSrc === '/ChatGPT Image Sep 19, 2026, 07_20_48 PM.png') {
      setImgSrc('/bluejo-logo.svg');
    } else if (imgSrc === '/bluejo-logo.svg') {
      setImgSrc('/assets/bluejo-logo.png');
    } else {
      setHasFailed(true);
    }
  };

  // Precise sizing to ensure the logo is clear, readable, sharp and responsive across devices
  const iconDimensions = {
    sm: 'w-8 h-8 min-w-[32px]',
    md: 'w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] sm:min-w-[40px]',
    lg: 'w-12 h-12 sm:w-14 sm:h-14 min-w-[48px] sm:min-w-[56px]',
    xl: 'w-16 h-16 sm:w-20 sm:h-20 min-w-[64px] sm:min-w-[80px]'
  };

  const textSizes = {
    sm: 'text-lg sm:text-xl',
    md: 'text-xl sm:text-2xl',
    lg: 'text-2xl sm:text-3xl',
    xl: 'text-3xl sm:text-4xl'
  };

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 sm:gap-3 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {/* Official BLUEJO Logo Icon */}
      <div className={`relative flex items-center justify-center flex-shrink-0 ${iconDimensions[size]}`}>
        {!hasFailed ? (
          <img
            src={imgSrc}
            alt="BLUEJO Logo"
            className="w-full h-full object-contain aspect-square drop-shadow-xs transition-transform duration-150 group-hover:scale-105"
            style={{ imageRendering: '-webkit-optimize-contrast' }}
            referrerPolicy="no-referrer"
            onError={handleError}
          />
        ) : (
          <svg viewBox="0 0 900 600" className="w-full h-full object-contain" fill="none">
            <defs>
              <linearGradient id="fallbackBGrad" x1="15%" y1="10%" x2="85%" y2="90%">
                <stop offset="0%" stopColor="#00D2FF" />
                <stop offset="20%" stopColor="#0066FF" />
                <stop offset="45%" stopColor="#7928CA" />
                <stop offset="70%" stopColor="#FF007A" />
                <stop offset="100%" stopColor="#FF7A00" />
              </linearGradient>
              <linearGradient id="fallbackRayTop" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FF007A" />
                <stop offset="100%" stopColor="#FF7A00" />
              </linearGradient>
              <linearGradient id="fallbackRayMid" x1="0%" y1="50%" x2="100%" y2="50%">
                <stop offset="0%" stopColor="#7928CA" />
                <stop offset="100%" stopColor="#FF00A0" />
              </linearGradient>
              <linearGradient id="fallbackRayBottom" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FF4500" />
                <stop offset="100%" stopColor="#FFBA00" />
              </linearGradient>
            </defs>
            <path
              d="M 240 85 L 385 85 C 465 85, 525 125, 525 195 C 525 245, 490 275, 440 295 C 515 315, 545 365, 545 425 C 545 500, 480 545, 385 545 L 240 545 C 195 545, 160 510, 160 465 L 160 165 C 160 120, 195 85, 240 85 Z"
              fill="url(#fallbackBGrad)"
            />
            <path
              d="M 280 230 L 410 305 C 422 312, 422 328, 410 335 L 280 410 C 268 417, 255 408, 255 395 L 255 245 C 255 232, 268 223, 280 230 Z"
              fill="#FFFFFF"
            />
            <line x1="565" y1="210" x2="635" y2="135" stroke="url(#fallbackRayTop)" strokeWidth="38" strokeLinecap="round" />
            <line x1="585" y1="315" x2="685" y2="285" stroke="url(#fallbackRayMid)" strokeWidth="38" strokeLinecap="round" />
            <line x1="578" y1="410" x2="648" y2="475" stroke="url(#fallbackRayBottom)" strokeWidth="38" strokeLinecap="round" />
          </svg>
        )}
      </div>

      {/* BLUEJO Brand Name & Optional Tagline */}
      {showText && (
        <div className="flex flex-col justify-center">
          <div className="flex items-center leading-none">
            <span
              className={`font-black tracking-wider font-['Outfit',sans-serif] ${textSizes[size]} text-slate-900 uppercase`}
            >
              BLUEJO
            </span>
          </div>
          {showTagline && (
            <span className="text-[11px] font-semibold text-slate-500 tracking-wider mt-1 uppercase">
              Connect • Create • Share
            </span>
          )}
        </div>
      )}
    </div>
  );
};

