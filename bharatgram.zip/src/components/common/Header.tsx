import React, { useState, useRef, useEffect } from 'react';
import { Logo } from './Logo';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../i18n/languages';
import {
  Bell,
  MessageCircle,
  PlusSquare,
  Globe,
  LogOut,
  User as UserIcon,
  Shield,
  ChevronDown,
  Sparkles,
  Search
} from 'lucide-react';

interface HeaderProps {
  onOpenCreate: () => void;
  onOpenAuth: () => void;
  onNavigate: (view: string, params?: any) => void;
  currentView: string;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCreate,
  onOpenAuth,
  onNavigate,
  currentView
}) => {
  const { user, logout, quickLogin, unreadNotifications, unreadMessages } = useAuth();
  const { currentLanguage, setLanguage, t, languages } = useLanguage();
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const langRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setShowLangMenu(false);
      }
      if (userRef.current && !userRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentLangObj = languages.find(l => l.code === currentLanguage);

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 py-2.5 transition-all">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Single Clickable Brand Area: Logo + BLUEJO Name -> Takes to Home */}
        <button
          id="header-brand-button"
          type="button"
          onClick={() => onNavigate('feed')}
          className="flex items-center gap-2.5 text-left bg-transparent border-0 p-0 cursor-pointer group focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg transition-transform active:scale-95"
          aria-label="BLUEJO Home"
          title="BLUEJO Home"
        >
          <Logo size="md" showText={true} />
        </button>

        {/* Global Search Bar (Hidden on tiny screens, prominent on md+) */}
        <div
          onClick={() => onNavigate('explore')}
          className="hidden sm:flex flex-1 max-w-sm items-center gap-2.5 bg-slate-100/90 hover:bg-slate-100 text-slate-500 rounded-full px-4 py-2 text-sm cursor-pointer border border-transparent hover:border-slate-300 transition-all"
        >
          <Search className="w-4 h-4 text-slate-400" />
          <span className="truncate">{t('searchPlaceholder')}</span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Indian Language Selector */}
          <div className="relative" ref={langRef}>
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 transition-colors border border-slate-200"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-orange-600" />
              <span className="hidden sm:inline">{currentLangObj?.nativeLabel || 'Language'}</span>
              <span className="sm:hidden uppercase">{currentLanguage}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showLangMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in-50 zoom-in-95">
                <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                  Select Language (भाषा)
                </div>
                <div className="max-h-64 overflow-y-auto py-1">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setShowLangMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs transition-colors hover:bg-orange-50 ${
                        currentLanguage === lang.code ? 'bg-orange-50/80 text-orange-600 font-semibold' : 'text-slate-700'
                      }`}
                    >
                      <span className="font-medium">{lang.nativeLabel}</span>
                      <span className="text-slate-400 text-[11px]">{lang.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Create Button */}
          {user && (
            <button
              onClick={onOpenCreate}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-semibold shadow-xs shadow-blue-600/20 transition-all cursor-pointer"
            >
              <PlusSquare className="w-4 h-4" />
              <span>{t('create')}</span>
            </button>
          )}

          {/* Notifications Button */}
          {user && (
            <button
              onClick={() => onNavigate('notifications')}
              className={`relative p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-700 ${
                currentView === 'notifications' ? 'bg-blue-50 text-blue-600' : ''
              }`}
              title={t('notifications')}
            >
              <Bell className="w-5 h-5" />
              {unreadNotifications > 0 && (
                <span className="absolute top-1 right-1 flex items-center justify-center min-w-[16px] h-4 px-1 text-[10px] font-bold text-white bg-rose-600 rounded-full">
                  {unreadNotifications > 9 ? '9+' : unreadNotifications}
                </span>
              )}
            </button>
          )}

          {/* Messages Button */}
          {user && (
            <button
              onClick={() => onNavigate('messages')}
              className={`relative p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-700 ${
                currentView === 'messages' ? 'bg-blue-50 text-blue-600' : ''
              }`}
              title={t('messages')}
            >
              <MessageCircle className="w-5 h-5" />
              {unreadMessages > 0 && (
                <span className="absolute top-1 right-1 flex items-center justify-center min-w-[16px] h-4 px-1 text-[10px] font-bold text-white bg-blue-600 rounded-full animate-pulse">
                  {unreadMessages > 9 ? '9+' : unreadMessages}
                </span>
              )}
            </button>
          )}

          {/* User Profile or Login */}
          {user ? (
            <div className="relative" ref={userRef}>
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-blue-200 transition-all"
              >
                <img
                  src={user.profilePhoto}
                  alt={user.name}
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover border border-slate-200"
                />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in-50 zoom-in-95">
                  <div className="px-4 py-2.5 border-b border-slate-100">
                    <div className="font-bold text-slate-900 text-sm">{user.name}</div>
                    <div className="text-xs text-slate-500 font-medium">@{user.username}</div>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onNavigate('profile', { username: user.username });
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50"
                    >
                      <UserIcon className="w-4 h-4 text-slate-400" />
                      <span>{t('profile')}</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onNavigate('settings');
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50"
                    >
                      <Shield className="w-4 h-4 text-slate-400" />
                      <span>{t('settings')}</span>
                    </button>

                    {user.isAdmin && (
                      <button
                        onClick={() => {
                          setShowUserMenu(false);
                          onNavigate('admin');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-blue-600 font-semibold hover:bg-blue-50"
                      >
                        <Shield className="w-4 h-4 text-blue-600" />
                        <span>{t('admin')}</span>
                      </button>
                    )}
                  </div>

                  {/* Switch test accounts for reviewer testing */}
                  <div className="border-t border-slate-100 px-4 py-2 bg-slate-50/50">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-blue-600" />
                      <span>Quick Test Profiles</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {['aarav_tech', 'priya_wanderlust', 'bluejo'].map((acc) => (
                        <button
                          key={acc}
                          onClick={async () => {
                            await quickLogin(acc);
                            setShowUserMenu(false);
                          }}
                          className={`text-[10px] px-2 py-0.5 rounded-md border text-slate-600 hover:bg-blue-100 hover:text-blue-900 transition-colors ${
                            user.username === acc ? 'bg-blue-100 text-blue-700 font-bold border-blue-300' : 'bg-white border-slate-200'
                          }`}
                        >
                          @{acc}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="border-t border-slate-100 pt-1">
                    <button
                      onClick={() => {
                        logout();
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 font-medium"
                    >
                      <LogOut className="w-4 h-4 text-rose-600" />
                      <span>{t('logout')}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-4 py-1.5 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-all shadow-sm"
            >
              {t('login')}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
