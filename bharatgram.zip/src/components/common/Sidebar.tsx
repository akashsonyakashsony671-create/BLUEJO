import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import {
  Home,
  Compass,
  Film,
  PlusSquare,
  MessageCircle,
  Bell,
  User,
  Settings,
  ShieldAlert,
  Bookmark
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string, params?: any) => void;
  onOpenCreate: () => void;
  onOpenAuth: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  onOpenCreate,
  onOpenAuth
}) => {
  const { user, unreadNotifications, unreadMessages } = useAuth();
  const { t } = useLanguage();

  const navItems = [
    { id: 'feed', label: t('home'), icon: Home },
    { id: 'explore', label: t('explore'), icon: Compass },
    { id: 'reels', label: t('reels'), icon: Film },
    { id: 'create', label: t('create'), icon: PlusSquare, action: onOpenCreate },
    {
      id: 'messages',
      label: t('messages'),
      icon: MessageCircle,
      badge: unreadMessages,
      requiresAuth: true
    },
    {
      id: 'notifications',
      label: t('notifications'),
      icon: Bell,
      badge: unreadNotifications,
      requiresAuth: true
    },
    {
      id: 'saved',
      label: t('saved'),
      icon: Bookmark,
      requiresAuth: true
    },
    {
      id: 'profile',
      label: t('profile'),
      icon: User,
      requiresAuth: true,
      params: { username: user?.username }
    },
    {
      id: 'settings',
      label: t('settings'),
      icon: Settings,
      requiresAuth: true
    }
  ];

  if (user?.isAdmin) {
    navItems.push({
      id: 'admin',
      label: t('admin'),
      icon: ShieldAlert,
      requiresAuth: true
    });
  }

  return (
    <aside className="w-64 h-[calc(100vh-61px)] sticky top-[61px] border-r border-slate-200/80 bg-white/80 backdrop-blur-sm p-4 hidden md:flex flex-col justify-between select-none">
      <div className="space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.requiresAuth && !user) {
                  onOpenAuth();
                  return;
                }
                if (item.action) {
                  item.action();
                } else {
                  onNavigate(item.id, item.params);
                }
              }}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-2xl text-sm font-semibold transition-all group ${
                isActive
                  ? 'bg-blue-50 text-blue-600 font-bold'
                  : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <Icon
                  className={`w-5 h-5 transition-transform group-hover:scale-105 ${
                    isActive ? 'text-blue-600 stroke-[2.5]' : 'text-slate-500'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              {Boolean(item.badge && item.badge > 0) && (
                <span className="flex items-center justify-center min-w-[18px] h-[18px] px-1.5 text-[10px] font-bold text-white bg-blue-600 rounded-full">
                  {item.badge! > 9 ? '9+' : item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* User Card or Login Promo */}
      {user ? (
        <div
          onClick={() => onNavigate('profile', { username: user.username })}
          className="p-3 rounded-2xl bg-slate-50 hover:bg-blue-50/50 border border-slate-200/80 flex items-center gap-3 cursor-pointer transition-colors"
        >
          <img
            src={user.profilePhoto}
            alt={user.name}
            referrerPolicy="no-referrer"
            className="w-10 h-10 rounded-full object-cover border border-slate-200"
          />
          <div className="flex-1 min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">{user.name}</div>
            <div className="text-[11px] text-slate-500 truncate">@{user.username}</div>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10 border border-blue-200/50 text-center">
          <div className="text-xs font-black tracking-wide text-slate-900 mb-1 uppercase">Join BLUEJO</div>
          <div className="text-[11px] text-slate-600 mb-3">Connect, create and share with top creators.</div>
          <button
            onClick={onOpenAuth}
            className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors"
          >
            {t('login')} / {t('signup')}
          </button>
        </div>
      )}
    </aside>
  );
};
