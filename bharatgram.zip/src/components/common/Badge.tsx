import React from 'react';
import { Check, Lock } from 'lucide-react';

export const VerifiedBadge: React.FC<{ size?: 'sm' | 'md' }> = ({ size = 'sm' }) => {
  const dim = size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';
  const iconDim = size === 'sm' ? 'w-2 h-2' : 'w-2.5 h-2.5';
  return (
    <span
      title="Verified Indian Creator"
      className={`inline-flex items-center justify-center rounded-full bg-blue-600 text-white ${dim} shadow-xs flex-shrink-0`}
    >
      <Check className={`${iconDim} stroke-[3]`} />
    </span>
  );
};

export const PrivateBadge: React.FC<{ size?: 'sm' | 'md' }> = ({ size = 'sm' }) => {
  const dim = size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';
  const iconDim = size === 'sm' ? 'w-2 h-2' : 'w-2.5 h-2.5';
  return (
    <span
      title="Private Account"
      className={`inline-flex items-center justify-center rounded-full bg-slate-200 text-slate-700 ${dim} flex-shrink-0`}
    >
      <Lock className={`${iconDim} stroke-[2.5]`} />
    </span>
  );
};
