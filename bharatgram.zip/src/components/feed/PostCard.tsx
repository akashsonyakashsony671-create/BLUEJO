import React, { useState, useRef } from 'react';
import { Post } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { VerifiedBadge } from '../common/Badge';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  MapPin,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Trash2,
  Flag,
  Copy,
  Check
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  onOpenComments: (post: Post) => void;
  onOpenShare: (post: Post) => void;
  onOpenReport: (targetId: string, targetType: 'post') => void;
  onNavigateToUser: (username: string) => void;
  onNavigateToHashtag: (tag: string) => void;
  onPostDeleted?: (postId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({
  post: initialPost,
  onOpenComments,
  onOpenShare,
  onOpenReport,
  onNavigateToUser,
  onNavigateToHashtag,
  onPostDeleted
}) => {
  const { user, token } = useAuth();
  const { t } = useLanguage();

  const [post, setPost] = useState<Post>(initialPost);
  const [isLiked, setIsLiked] = useState(initialPost.isLikedByMe);
  const [likesCount, setLikesCount] = useState(initialPost.likesCount);
  const [isSaved, setIsSaved] = useState(initialPost.isSavedByMe);
  const [showHeartPop, setShowHeartPop] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Video playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);

  const isAuthor = user?._id === post.userId;

  // Toggle Like with backend call
  const handleToggleLike = async () => {
    if (!token) return;

    const nextLiked = !isLiked;
    setIsLiked(nextLiked);
    setLikesCount(prev => (nextLiked ? prev + 1 : Math.max(0, prev - 1)));

    try {
      const res = await fetch(`/api/posts/${post._id}/like`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setIsLiked(data.liked);
        setLikesCount(data.likesCount);
      }
    } catch (err) {
      console.error('Failed to like post:', err);
    }
  };

  // Double-tap to like with heart animation
  const lastTapRef = useRef<number>(0);
  const handleMediaTap = () => {
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      if (!isLiked) {
        handleToggleLike();
      }
      setShowHeartPop(true);
      setTimeout(() => setShowHeartPop(false), 800);
    }
    lastTapRef.current = now;
  };

  // Toggle Save with backend call
  const handleToggleSave = async () => {
    if (!token) return;
    const nextSaved = !isSaved;
    setIsSaved(nextSaved);

    try {
      const res = await fetch(`/api/posts/${post._id}/save`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setIsSaved(data.saved);
      }
    } catch (err) {
      console.error('Failed to save post:', err);
    }
  };

  // Submit quick inline comment
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !token || isSubmittingComment) return;

    setIsSubmittingComment(true);
    try {
      const res = await fetch(`/api/posts/${post._id}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ text: newComment.trim() })
      });
      const data = await res.json();
      if (data.success && data.comment) {
        setPost(prev => ({
          ...prev,
          commentsCount: prev.commentsCount + 1,
          commentsPreview: [...(prev.commentsPreview || []), data.comment]
        }));
        setNewComment('');
      }
    } catch (err) {
      console.error('Failed to add comment:', err);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleDeletePost = async () => {
    if (!token || !isAuthor) return;
    if (!confirm('Are you sure you want to delete this post?')) return;

    try {
      const res = await fetch(`/api/posts/${post._id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        if (onPostDeleted) onPostDeleted(post._id);
      }
    } catch (err) {
      console.error('Failed to delete post:', err);
    }
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/post/${post._id}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => {
      setCopiedLink(false);
      setShowMenu(false);
    }, 1500);
  };

  const formatTimeAgo = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffSec < 60) return 'just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h`;
    return `${Math.floor(diffSec / 86400)}d`;
  };

  return (
    <article className="w-full bg-white border border-slate-200/90 rounded-2xl mb-6 shadow-xs overflow-hidden transition-all hover:border-slate-300">
      {/* Post Header */}
      <div className="flex items-center justify-between p-3 sm:p-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateToUser(post.author.username)}
            className="flex-shrink-0 cursor-pointer"
          >
            <img
              src={post.author.profilePhoto}
              alt={post.author.username}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover border border-slate-200"
            />
          </button>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onNavigateToUser(post.author.username)}
                className="font-bold text-xs sm:text-sm text-slate-900 hover:text-orange-600 transition-colors text-left"
              >
                {post.author.name}
              </button>
              {post.author.isVerified && <VerifiedBadge size="sm" />}
              <span className="text-slate-400 text-xs">•</span>
              <span className="text-slate-500 text-xs">{formatTimeAgo(post.createdAt)}</span>
            </div>

            {post.location && (
              <div className="flex items-center gap-1 text-[11px] text-slate-500 font-medium mt-0.5">
                <MapPin className="w-3 h-3 text-orange-600 flex-shrink-0" />
                <span className="truncate max-w-[200px]">{post.location}</span>
              </div>
            )}
          </div>
        </div>

        {/* Options Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-1.5 text-slate-500 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>

          {showMenu && (
            <div className="absolute right-0 mt-1 w-44 bg-white rounded-2xl shadow-xl border border-slate-200 py-1.5 z-30 animate-in fade-in-50 zoom-in-95">
              <button
                onClick={handleCopyLink}
                className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-400" />}
                <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenShare(post);
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50"
              >
                <Share2 className="w-4 h-4 text-slate-400" />
                <span>{t('share')}</span>
              </button>

              {isAuthor ? (
                <button
                  onClick={() => {
                    setShowMenu(false);
                    handleDeletePost();
                  }}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-rose-600 hover:bg-rose-50"
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  <span>Delete Post</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setShowMenu(false);
                    onOpenReport(post._id, 'post');
                  }}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-amber-600 hover:bg-amber-50"
                >
                  <Flag className="w-4 h-4 text-amber-600" />
                  <span>{t('report')}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Media Viewport */}
      <div
        className="relative w-full aspect-square sm:aspect-[4/5] bg-slate-950 flex items-center justify-center overflow-hidden cursor-pointer select-none"
        onClick={handleMediaTap}
      >
        {post.mediaType === 'video' ? (
          <>
            <video
              ref={videoRef}
              src={post.mediaUrl}
              loop
              muted={isMuted}
              playsInline
              className="w-full h-full object-cover"
              onClick={(e) => {
                e.stopPropagation();
                if (videoRef.current) {
                  if (isPlaying) {
                    videoRef.current.pause();
                    setIsPlaying(false);
                  } else {
                    videoRef.current.play();
                    setIsPlaying(true);
                  }
                }
              }}
            />
            {/* Video Play/Pause Overlay */}
            {!isPlaying && (
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center pointer-events-none">
                <div className="w-14 h-14 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center text-white">
                  <Play className="w-7 h-7 fill-white ml-1" />
                </div>
              </div>
            )}

            {/* Video Mute/Unmute Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsMuted(!isMuted);
              }}
              className="absolute bottom-3 right-3 p-2 bg-black/60 hover:bg-black/80 text-white rounded-full backdrop-blur-sm transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </>
        ) : (
          <img
            src={post.mediaUrl}
            alt={post.caption || 'Post image'}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-300"
          />
        )}

        {/* Double Tap Heart Explosion Animation */}
        {showHeartPop && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none animate-in zoom-in-50 duration-200">
            <Heart className="w-24 h-24 text-rose-500 fill-rose-500 drop-shadow-xl animate-pulse" />
          </div>
        )}
      </div>

      {/* Post Actions Bar */}
      <div className="p-3 sm:px-4 sm:pt-3 sm:pb-2">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-4">
            {/* Like Button */}
            <button
              onClick={handleToggleLike}
              className="flex items-center gap-1.5 group cursor-pointer"
              title={isLiked ? 'Unlike' : 'Like'}
            >
              <Heart
                className={`w-6 h-6 transition-all group-active:scale-125 ${
                  isLiked ? 'text-rose-500 fill-rose-500' : 'text-slate-700 hover:text-rose-500'
                }`}
              />
            </button>

            {/* Comment Button */}
            <button
              onClick={() => onOpenComments(post)}
              className="flex items-center gap-1.5 group text-slate-700 hover:text-orange-600 transition-colors cursor-pointer"
              title={t('comment')}
            >
              <MessageCircle className="w-6 h-6 group-active:scale-110" />
            </button>

            {/* Share Button */}
            <button
              onClick={() => onOpenShare(post)}
              className="flex items-center gap-1.5 group text-slate-700 hover:text-blue-600 transition-colors cursor-pointer"
              title={t('share')}
            >
              <Share2 className="w-5 h-5 group-active:scale-110" />
            </button>
          </div>

          {/* Bookmark / Save Button */}
          <button
            onClick={handleToggleSave}
            className="text-slate-700 hover:text-orange-600 transition-colors cursor-pointer"
            title={isSaved ? 'Saved' : 'Save'}
          >
            <Bookmark
              className={`w-6 h-6 transition-all ${
                isSaved ? 'text-orange-600 fill-orange-600' : 'text-slate-700'
              }`}
            />
          </button>
        </div>

        {/* Likes Count */}
        <div className="text-xs sm:text-sm font-bold text-slate-900 mb-1.5">
          {likesCount.toLocaleString()} {likesCount === 1 ? 'like' : 'likes'}
        </div>

        {/* Caption with Hashtags */}
        {post.caption && (
          <div className="text-xs sm:text-sm text-slate-800 leading-relaxed mb-1.5">
            <button
              onClick={() => onNavigateToUser(post.author.username)}
              className="font-bold text-slate-900 mr-2 hover:underline"
            >
              {post.author.username}
            </button>
            <span>{post.caption}</span>
          </div>
        )}

        {/* Clickable Hashtags */}
        {post.hashtags && post.hashtags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-2">
            {post.hashtags.map((tag) => (
              <button
                key={tag}
                onClick={() => onNavigateToHashtag(tag)}
                className="text-[11px] font-semibold text-orange-600 hover:text-orange-700 hover:underline"
              >
                #{tag}
              </button>
            ))}
          </div>
        )}

        {/* View all comments button */}
        {post.commentsCount > 0 && (
          <button
            onClick={() => onOpenComments(post)}
            className="text-xs text-slate-500 hover:text-slate-700 font-medium mb-2 block cursor-pointer"
          >
            View all {post.commentsCount} comments
          </button>
        )}

        {/* Inline comment preview */}
        {post.commentsPreview && post.commentsPreview.length > 0 && (
          <div className="space-y-1 mb-2">
            {post.commentsPreview.slice(-2).map((c) => (
              <div key={c._id} className="text-xs text-slate-700 truncate">
                <span className="font-bold text-slate-900 mr-1.5">
                  {c.author?.username || 'user'}
                </span>
                <span>{c.text}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Add Comment Form */}
      {user && (
        <form
          onSubmit={handleAddComment}
          className="border-t border-slate-100 px-4 py-2.5 flex items-center gap-2 bg-slate-50/40"
        >
          <input
            type="text"
            placeholder={t('addComment')}
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="flex-1 bg-transparent text-xs text-slate-800 placeholder-slate-400 outline-hidden"
          />
          <button
            type="submit"
            disabled={!newComment.trim() || isSubmittingComment}
            className="text-xs font-bold text-orange-600 hover:text-orange-700 disabled:opacity-30 transition-opacity cursor-pointer"
          >
            {t('post')}
          </button>
        </form>
      )}
    </article>
  );
};
