import React, { useState, useEffect, useRef } from 'react';
import { StoryGroup } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { X, ChevronLeft, ChevronRight, Eye, Trash2, Send } from 'lucide-react';

interface StoryViewerProps {
  initialGroupIndex: number;
  onClose: () => void;
  onStoryDeleted?: () => void;
}

export const StoryViewer: React.FC<StoryViewerProps> = ({
  initialGroupIndex,
  onClose,
  onStoryDeleted
}) => {
  const { user, token } = useAuth();
  const [storyGroups, setStoryGroups] = useState<StoryGroup[]>([]);
  const [currentGroupIdx, setCurrentGroupIdx] = useState(initialGroupIndex);
  const [currentStoryIdx, setCurrentStoryIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [sentReply, setSentReply] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetch('/api/stories')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.storyGroups) {
          setStoryGroups(data.storyGroups);
        }
      });
  }, []);

  const currentGroup = storyGroups[currentGroupIdx];
  const currentStory = currentGroup?.stories[currentStoryIdx];

  // Record view on backend
  useEffect(() => {
    if (currentStory && token) {
      fetch(`/api/stories/${currentStory._id}/view`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        }
      }).catch(console.error);
    }
  }, [currentStory, token]);

  // Story progress timer (5 seconds per photo story)
  useEffect(() => {
    if (isPaused || !currentStory) return;

    const interval = 50; // ms
    const step = 100 / (5000 / interval);

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNextStory();
          return 0;
        }
        return prev + step;
      });
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentGroupIdx, currentStoryIdx, isPaused, currentStory]);

  const handleNextStory = () => {
    setProgress(0);
    if (!currentGroup) return;

    if (currentStoryIdx < currentGroup.stories.length - 1) {
      setCurrentStoryIdx(prev => prev + 1);
    } else {
      // Advance to next user's story group
      if (currentGroupIdx < storyGroups.length - 1) {
        setCurrentGroupIdx(prev => prev + 1);
        setCurrentStoryIdx(0);
      } else {
        onClose();
      }
    }
  };

  const handlePrevStory = () => {
    setProgress(0);
    if (currentStoryIdx > 0) {
      setCurrentStoryIdx(prev => prev - 1);
    } else {
      // Go to previous user's story group
      if (currentGroupIdx > 0) {
        setCurrentGroupIdx(prev => prev - 1);
        const prevGroup = storyGroups[currentGroupIdx - 1];
        setCurrentStoryIdx(prevGroup ? prevGroup.stories.length - 1 : 0);
      }
    }
  };

  const handleDeleteStory = async () => {
    if (!currentStory || !token) return;
    if (!confirm('Are you sure you want to delete this story?')) return;

    try {
      const res = await fetch(`/api/stories/${currentStory._id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        if (onStoryDeleted) onStoryDeleted();
        handleNextStory();
      }
    } catch (err) {
      console.error('Failed to delete story:', err);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !user || !token || !currentGroup) return;

    try {
      // Start or find conversation with story author
      const convRes = await fetch('/api/conversations/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId: currentGroup.userId })
      });
      const convData = await convRes.json();

      if (convData.success && convData.conversation) {
        await fetch('/api/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            conversationId: convData.conversation._id,
            receiverId: currentGroup.userId,
            text: `Replied to story: "${replyText.trim()}"`
          })
        });

        setSentReply(true);
        setReplyText('');
        setTimeout(() => setSentReply(false), 2000);
      }
    } catch (err) {
      console.error('Failed to reply to story:', err);
    }
  };

  if (!currentGroup || !currentStory) {
    return null;
  }

  const isMyStory = user?._id === currentGroup.userId;

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center select-none backdrop-blur-md">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-50 p-2 text-white/80 hover:text-white rounded-full bg-white/10 hover:bg-white/20 transition-all cursor-pointer"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Story Card Container */}
      <div
        className="relative w-full max-w-sm h-full max-h-[88vh] bg-slate-900 sm:rounded-3xl overflow-hidden flex flex-col justify-between shadow-2xl"
        onMouseDown={() => setIsPaused(true)}
        onMouseUp={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {/* Top Progress Bars */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center gap-1.5">
          {currentGroup.stories.map((story, i) => (
            <div key={story._id} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-white transition-all duration-75 ease-linear"
                style={{
                  width:
                    i < currentStoryIdx
                      ? '100%'
                      : i === currentStoryIdx
                      ? `${progress}%`
                      : '0%'
                }}
              />
            </div>
          ))}
        </div>

        {/* Story Author Header */}
        <div className="absolute top-7 left-3 right-3 z-30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <img
              src={currentGroup.author.profilePhoto}
              alt={currentGroup.author.username}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-white/50"
            />
            <div className="text-white drop-shadow-md">
              <div className="text-xs font-bold leading-none">{currentGroup.author.name}</div>
              <div className="text-[11px] text-white/80 font-medium leading-tight">
                @{currentGroup.author.username}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-white">
            {isMyStory ? (
              <div className="flex items-center gap-2 bg-black/40 px-2.5 py-1 rounded-full text-xs">
                <Eye className="w-3.5 h-3.5" />
                <span>{currentStory.viewsCount || 0}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteStory();
                  }}
                  className="ml-1 text-rose-400 hover:text-rose-300"
                  title="Delete Story"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : null}
          </div>
        </div>

        {/* Media Display */}
        <div className="relative w-full h-full flex items-center justify-center bg-black">
          {currentStory.mediaType === 'video' ? (
            <video
              src={currentStory.mediaUrl}
              autoPlay
              playsInline
              className="w-full h-full object-contain"
            />
          ) : (
            <img
              src={currentStory.mediaUrl}
              alt="Story"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          )}

          {/* Caption Overlay if present */}
          {currentStory.caption && (
            <div className="absolute bottom-16 left-4 right-4 z-20 text-center">
              <div className="inline-block bg-black/60 backdrop-blur-sm text-white text-xs sm:text-sm px-4 py-2 rounded-2xl max-w-full">
                {currentStory.caption}
              </div>
            </div>
          )}

          {/* Left / Right tap navigation targets */}
          <div
            className="absolute left-0 top-16 bottom-16 w-1/3 z-20 cursor-pointer"
            onClick={handlePrevStory}
          />
          <div
            className="absolute right-0 top-16 bottom-16 w-1/3 z-20 cursor-pointer"
            onClick={handleNextStory}
          />
        </div>

        {/* Bottom Reply Bar for non-owners */}
        {!isMyStory && user && (
          <div className="relative z-30 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent">
            {sentReply ? (
              <div className="text-center text-emerald-400 text-xs py-2 font-semibold">
                ✓ Reply sent to @{currentGroup.author.username}!
              </div>
            ) : (
              <form onSubmit={handleSendReply} className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder={`Reply to @${currentGroup.author.username}...`}
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="flex-1 bg-white/20 hover:bg-white/30 focus:bg-white/30 text-white placeholder-white/70 text-xs px-4 py-2.5 rounded-full outline-hidden border border-white/20 backdrop-blur-sm"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim()}
                  className="p-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white rounded-full transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        )}
      </div>

      {/* Side arrow navigation for desktop */}
      <button
        onClick={handlePrevStory}
        className="hidden md:flex absolute left-8 top-1/2 -translate-y-1/2 p-3 text-white/70 hover:text-white rounded-full bg-white/10 hover:bg-white/20 transition-all cursor-pointer"
      >
        <ChevronLeft className="w-7 h-7" />
      </button>
      <button
        onClick={handleNextStory}
        className="hidden md:flex absolute right-8 top-1/2 -translate-y-1/2 p-3 text-white/70 hover:text-white rounded-full bg-white/10 hover:bg-white/20 transition-all cursor-pointer"
      >
        <ChevronRight className="w-7 h-7" />
      </button>
    </div>
  );
};
