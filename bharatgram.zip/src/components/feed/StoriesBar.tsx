import React, { useState, useEffect } from 'react';
import { StoryGroup } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { Plus } from 'lucide-react';

interface StoriesBarProps {
  onOpenStory: (groupIndex: number) => void;
  onAddStory: () => void;
  refreshTrigger?: number;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({
  onOpenStory,
  onAddStory,
  refreshTrigger = 0
}) => {
  const { user } = useAuth();
  const [storyGroups, setStoryGroups] = useState<StoryGroup[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchStories = async () => {
    try {
      const res = await fetch('/api/stories');
      const data = await res.json();
      if (data.success && data.storyGroups) {
        setStoryGroups(data.storyGroups);
      }
    } catch (err) {
      console.error('Failed to load stories:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStories();
  }, [refreshTrigger]);

  const myGroup = storyGroups.find(g => g.userId === user?._id);
  const otherGroups = storyGroups.filter(g => g.userId !== user?._id);

  return (
    <div className="w-full bg-white border border-slate-200/80 rounded-2xl p-3 sm:p-4 mb-5 shadow-xs overflow-hidden">
      <div className="flex items-center gap-3 sm:gap-4 overflow-x-auto no-scrollbar py-1">
        {/* Your Story Button */}
        <div className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group">
          <div className="relative">
            <div
              onClick={() => {
                if (myGroup && myGroup.stories.length > 0) {
                  onOpenStory(0);
                } else {
                  onAddStory();
                }
              }}
              className={`w-15 h-15 rounded-full p-0.5 transition-transform group-hover:scale-105 ${
                myGroup && myGroup.stories.length > 0
                  ? 'bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500'
                  : 'border-2 border-dashed border-slate-300'
              }`}
            >
              <img
                src={
                  user?.profilePhoto ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                }
                alt="Your story"
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover border-2 border-white"
              />
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onAddStory();
              }}
              title="Add Story"
              className="absolute bottom-0 right-0 w-5 h-5 bg-orange-600 hover:bg-orange-700 text-white rounded-full flex items-center justify-center border-2 border-white shadow-xs"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </button>
          </div>
          <span className="text-[11px] font-semibold text-slate-700 max-w-[64px] truncate">
            {myGroup ? 'Your Story' : 'Add Story'}
          </span>
        </div>

        {/* Other Creators' Stories */}
        {otherGroups.map((group, idx) => {
          const indexInAll = storyGroups.indexOf(group);
          return (
            <div
              key={group.userId}
              onClick={() => onOpenStory(indexInAll)}
              className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group"
            >
              <div
                className={`w-15 h-15 rounded-full p-0.5 transition-transform group-hover:scale-105 ${
                  group.hasUnviewed
                    ? 'bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 ring-2 ring-orange-100'
                    : 'bg-slate-200'
                }`}
              >
                <img
                  src={group.author.profilePhoto}
                  alt={group.author.username}
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover border-2 border-white"
                />
              </div>
              <span className="text-[11px] font-medium text-slate-600 max-w-[68px] truncate">
                {group.author.username}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
