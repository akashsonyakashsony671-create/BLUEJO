import React, { useState, useRef, useEffect } from 'react';
import { Reel } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { VerifiedBadge } from '../common/Badge';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Volume2,
  VolumeX,
  Music,
  UserPlus,
  UserCheck
} from 'lucide-react';

interface ReelPlayerProps {
  reel: Reel;
  isActive: boolean;
  onOpenComments: (reel: Reel) => void;
  onOpenShare: (reel: Reel) => void;
  onNavigateToUser: (username: string) => void;
  onNavigateToHashtag: (tag: string) => void;
}

export const ReelPlayer: React.FC<ReelPlayerProps> = ({
  reel: initialReel,
  isActive,
  onOpenComments,
  onOpenShare,
  onNavigateToUser,
  onNavigateToHashtag
}) => {
  const { user, token } = useAuth();
  const [reel, setReel] = useState<Reel>(initialReel);
  const [isLiked, setIsLiked] = useState(initialReel.isLikedByMe);
  const [likesCount, setLikesCount] = useState(initialReel.likesCount);
  const [isSaved, setIsSaved] = useState(initialReel.isSavedByMe);
  const [isFollowing, setIsFollowing] = useState(initialReel.isFollowingAuthor);
  const [isMuted, setIsMuted] = useState(true);
  const [showHeartPop, setShowHeartPop] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  // Play / Pause video based on screen intersection
  useEffect(() => {
    if (!videoRef.current) return;
    if (isActive) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {
        // Autoplay policy might require muted
        setIsMuted(true);
        videoRef.current?.play().catch(() => {});
      });

      // Record view count
      if (token) {
        fetch(`/api/reels/${reel._id}/view`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` }
        }).catch(console.error);
      }
    } else {
      videoRef.current.pause();
    }
  }, [isActive, reel._id, token]);

  const handleToggleLike = async () => {
    if (!token) return;
    const nextLiked = !isLiked;
    setIsLiked(nextLiked);
    setLikesCount(prev => (nextLiked ? prev + 1 : Math.max(0, prev - 1)));

    try {
      const res = await fetch(`/api/reels/${reel._id}/like`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setIsLiked(data.liked);
        setLikesCount(data.likesCount);
      }
    } catch (err) {
      console.error('Failed to like reel:', err);
    }
  };

  const lastTapRef = useRef<number>(0);
  const handleDoubleTap = () => {
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      if (!isLiked) handleToggleLike();
      setShowHeartPop(true);
      setTimeout(() => setShowHeartPop(false), 800);
    } else {
      // Single tap toggles mute
      setIsMuted(!isMuted);
    }
    lastTapRef.current = now;
  };

  const handleToggleSave = async () => {
    if (!token) return;
    const nextSaved = !isSaved;
    setIsSaved(nextSaved);

    try {
      const res = await fetch(`/api/reels/${reel._id}/save`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setIsSaved(data.saved);
      }
    } catch (err) {
      console.error('Failed to save reel:', err);
    }
  };

  const handleToggleFollow = async () => {
    if (!token || !user) return;
    const nextFollowing = !isFollowing;
    setIsFollowing(nextFollowing);

    try {
      await fetch(`/api/users/${reel.author.username}/follow`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (err) {
      console.error('Failed to follow creator:', err);
    }
  };

  const isMe = user?._id === reel.userId;

  return (
    <div
      className="relative w-full h-full max-w-sm mx-auto bg-black rounded-3xl overflow-hidden shadow-2xl flex items-center justify-center select-none"
      onClick={handleDoubleTap}
    >
      {/* Video Content */}
      <video
        ref={videoRef}
        src={reel.videoUrl}
        loop
        playsInline
        muted={isMuted}
        className="w-full h-full object-cover"
      />

      {/* Double tap heart explosion */}
      {showHeartPop && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
          <Heart className="w-28 h-28 text-rose-500 fill-rose-500 drop-shadow-2xl animate-pulse" />
        </div>
      )}

      {/* Volume indicator */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsMuted(!isMuted);
        }}
        className="absolute top-4 right-4 z-30 p-2.5 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-sm text-white transition-colors"
      >
        {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
      </button>

      {/* Action Bar on the Right */}
      <div className="absolute right-3 bottom-16 z-30 flex flex-col items-center gap-5 text-white">
        {/* Like */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleToggleLike();
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-sm group-active:scale-125 transition-transform">
            <Heart
              className={`w-7 h-7 ${
                isLiked ? 'text-rose-500 fill-rose-500' : 'text-white'
              }`}
            />
          </div>
          <span className="text-xs font-bold drop-shadow-md">
            {likesCount > 0 ? likesCount.toLocaleString() : '0'}
          </span>
        </button>

        {/* Comment */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onOpenComments(reel);
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-sm group-active:scale-125 transition-transform">
            <MessageCircle className="w-7 h-7 text-white" />
          </div>
          <span className="text-xs font-bold drop-shadow-md">
            {reel.commentsCount || 0}
          </span>
        </button>

        {/* Share */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onOpenShare(reel);
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-sm group-active:scale-125 transition-transform">
            <Share2 className="w-6 h-6 text-white" />
          </div>
          <span className="text-xs font-medium drop-shadow-md">Share</span>
        </button>

        {/* Save */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleToggleSave();
          }}
          className="flex flex-col items-center gap-1 group cursor-pointer"
        >
          <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-sm group-active:scale-125 transition-transform">
            <Bookmark
              className={`w-6 h-6 ${
                isSaved ? 'text-orange-500 fill-orange-500' : 'text-white'
              }`}
            />
          </div>
          <span className="text-xs font-medium drop-shadow-md">Save</span>
        </button>
      </div>

      {/* Bottom Creator Info & Audio */}
      <div className="absolute left-3 right-16 bottom-4 z-30 text-white drop-shadow-lg space-y-2">
        {/* Creator Info */}
        <div className="flex items-center gap-2.5">
          <img
            src={reel.author.profilePhoto}
            alt={reel.author.username}
            referrerPolicy="no-referrer"
            onClick={(e) => {
              e.stopPropagation();
              onNavigateToUser(reel.author.username);
            }}
            className="w-10 h-10 rounded-full object-cover border-2 border-white cursor-pointer"
          />
          <div className="flex items-center gap-1.5 flex-wrap">
            <span
              onClick={(e) => {
                e.stopPropagation();
                onNavigateToUser(reel.author.username);
              }}
              className="font-bold text-sm hover:underline cursor-pointer"
            >
              {reel.author.name}
            </span>
            {reel.author.isVerified && <VerifiedBadge size="sm" />}

            {!isMe && user && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggleFollow();
                }}
                className={`ml-2 text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 transition-all ${
                  isFollowing
                    ? 'bg-white/20 text-white hover:bg-white/30'
                    : 'bg-orange-600 text-white hover:bg-orange-700 shadow-xs'
                }`}
              >
                {isFollowing ? (
                  <>
                    <UserCheck className="w-3 h-3" />
                    <span>Following</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-3 h-3" />
                    <span>Follow</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Caption */}
        {reel.caption && (
          <p className="text-xs text-white/95 leading-relaxed line-clamp-2">
            {reel.caption}
          </p>
        )}

        {/* Hashtags */}
        {reel.hashtags && reel.hashtags.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {reel.hashtags.map((tag) => (
              <button
                key={tag}
                onClick={(e) => {
                  e.stopPropagation();
                  onNavigateToHashtag(tag);
                }}
                className="text-[11px] font-semibold text-orange-300 hover:text-orange-200"
              >
                #{tag}
              </button>
            ))}
          </div>
        )}

        {/* Indian Audio Track */}
        {reel.audioTrack && (
          <div className="flex items-center gap-1.5 text-[11px] text-white/80 font-medium">
            <Music className="w-3.5 h-3.5 animate-spin" />
            <span className="truncate">{reel.audioTrack}</span>
          </div>
        )}
      </div>
    </div>
  );
};
