import React, { useState, useEffect, useRef } from 'react';
import { Reel } from '../../types';
import { ReelPlayer } from './ReelPlayer';
import { ChevronUp, ChevronDown, Sparkles } from 'lucide-react';

interface ReelsFeedProps {
  onOpenComments: (reel: Reel) => void;
  onOpenShare: (reel: Reel) => void;
  onNavigateToUser: (username: string) => void;
  onNavigateToHashtag: (tag: string) => void;
}

export const ReelsFeed: React.FC<ReelsFeedProps> = ({
  onOpenComments,
  onOpenShare,
  onNavigateToUser,
  onNavigateToHashtag
}) => {
  const [reels, setReels] = useState<Reel[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchReels = async () => {
      try {
        const res = await fetch('/api/reels');
        const data = await res.json();
        if (data.success && data.reels) {
          setReels(data.reels);
        }
      } catch (err) {
        console.error('Failed to load reels:', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchReels();
  }, []);

  const handleNext = () => {
    if (activeIndex < reels.length - 1) {
      setActiveIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setActiveIndex(prev => prev - 1);
    }
  };

  // Keyboard arrow navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') handleNext();
      if (e.key === 'ArrowUp') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, reels.length]);

  if (isLoading) {
    return (
      <div className="h-[calc(100vh-140px)] flex flex-col items-center justify-center gap-3">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs font-semibold text-slate-500">Loading BLUEJO Reels...</p>
      </div>
    );
  }

  if (reels.length === 0) {
    return (
      <div className="h-[calc(100vh-140px)] flex flex-col items-center justify-center p-6 text-center">
        <Sparkles className="w-12 h-12 text-blue-400 mb-2" />
        <h3 className="text-base font-bold text-slate-800">No Reels Yet</h3>
        <p className="text-xs text-slate-500 max-w-xs mt-1">
          Be the first creator to share a 9:16 vertical video reel on BLUEJO!
        </p>
      </div>
    );
  }

  return (
    <div className="relative h-[calc(100vh-120px)] sm:h-[calc(100vh-80px)] w-full flex items-center justify-center p-2 sm:p-4">
      {/* Active Reel */}
      <div className="w-full h-full max-h-[820px] max-w-sm">
        <ReelPlayer
          reel={reels[activeIndex]}
          isActive={true}
          onOpenComments={onOpenComments}
          onOpenShare={onOpenShare}
          onNavigateToUser={onNavigateToUser}
          onNavigateToHashtag={onNavigateToHashtag}
        />
      </div>

      {/* Vertical Navigation Buttons for Desktop */}
      <div className="hidden md:flex flex-col gap-3 ml-4">
        <button
          onClick={handlePrev}
          disabled={activeIndex === 0}
          className="p-3 rounded-full bg-white shadow-md border border-slate-200 text-slate-700 hover:text-orange-600 disabled:opacity-30 transition-all cursor-pointer"
          title="Previous Reel"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
        <button
          onClick={handleNext}
          disabled={activeIndex === reels.length - 1}
          className="p-3 rounded-full bg-white shadow-md border border-slate-200 text-slate-700 hover:text-orange-600 disabled:opacity-30 transition-all cursor-pointer"
          title="Next Reel"
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
